import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { ru, type Dict } from "./ru";
import { kg } from "./kg";

export type Lang = "ru" | "kg";

const dicts: Record<Lang, Dict> = { ru, kg };

type LangContextType = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: Dict;
};

const LangContext = createContext<LangContextType>({
  lang: "ru",
  setLang: () => {},
  t: ru,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = localStorage.getItem("lang");
    return saved === "kg" ? "kg" : "ru";
  });

  const setLang = (l: Lang) => {
    localStorage.setItem("lang", l);
    setLangState(l);
  };

  useEffect(() => {
    document.documentElement.lang = lang === "kg" ? "ky" : "ru";
  }, [lang]);

  return (
    <LangContext.Provider value={{ lang, setLang, t: dicts[lang] }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  return useContext(LangContext);
}

/** Выбор переведённого поля: KG с фолбэком на RU */
export function loc(
  lang: Lang,
  ruValue: string | null | undefined,
  kgValue?: string | null | undefined,
): string {
  if (lang === "kg" && kgValue && kgValue.trim().length > 0) return kgValue;
  return ruValue ?? "";
}
