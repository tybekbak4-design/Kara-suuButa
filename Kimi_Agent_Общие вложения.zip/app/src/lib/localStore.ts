// Избранное, сравнение и история просмотров — localStorage (без регистрации)
import { useSyncExternalStore } from "react";

type StoreName = "favorites" | "compare" | "history";

function read(name: StoreName): number[] {
  try {
    const raw = localStorage.getItem(`shop_${name}`);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((x) => Number.isInteger(x)) : [];
  } catch {
    return [];
  }
}

// Кэш снапшотов: getSnapshot обязан возвращать стабильную ссылку,
// иначе useSyncExternalStore уходит в бесконечный цикл.
const cache = new Map<StoreName, number[]>();

function getCached(name: StoreName): number[] {
  if (!cache.has(name)) cache.set(name, read(name));
  return cache.get(name)!;
}

function write(name: StoreName, ids: number[]) {
  cache.set(name, ids);
  localStorage.setItem(`shop_${name}`, JSON.stringify(ids));
  window.dispatchEvent(new CustomEvent(`shop:${name}`));
}

export function getIds(name: StoreName): number[] {
  return getCached(name);
}

export function toggleId(name: StoreName, id: number): boolean {
  const ids = [...getCached(name)];
  const idx = ids.indexOf(id);
  if (idx >= 0) {
    ids.splice(idx, 1);
    write(name, ids);
    return false;
  }
  ids.unshift(id);
  write(name, ids.slice(0, 50));
  return true;
}

export function clearStore(name: StoreName) {
  write(name, []);
}

export function pushHistory(id: number) {
  const ids = getCached("history").filter((x) => x !== id);
  ids.unshift(id);
  write("history", ids.slice(0, 20));
}

export function useStoreIds(name: StoreName): number[] {
  return useSyncExternalStore(
    (cb) => {
      const handler = () => {
        // Перечитываем localStorage: событие могло прийти из другой вкладки
        cache.set(name, read(name));
        cb();
      };
      window.addEventListener(`shop:${name}`, handler);
      window.addEventListener("storage", handler);
      return () => {
        window.removeEventListener(`shop:${name}`, handler);
        window.removeEventListener("storage", handler);
      };
    },
    () => getCached(name),
  );
}
