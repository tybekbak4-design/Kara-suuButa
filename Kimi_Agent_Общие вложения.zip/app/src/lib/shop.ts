// Форматирование, контакты, статистика
import { trpc } from "@/providers/trpc";
import type { SettingsMap } from "@contracts/types";

export function formatPrice(price: number, currency = "сом"): string {
  return `${price.toLocaleString("ru-RU")} ${currency}`;
}

export function digitsOnly(phone: string): string {
  return phone.replace(/[^\d]/g, "");
}

export function phoneHref(phone: string): string {
  return `tel:+${digitsOnly(phone)}`;
}

export function whatsappHref(whatsapp: string, message?: string): string {
  const base = `https://wa.me/${digitsOnly(whatsapp)}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export function productUrl(slug: string): string {
  return `${window.location.origin}/product/${slug}`;
}

export function productMessage(
  name: string,
  price: string,
  slug: string,
  lang: "ru" | "kg",
): string {
  const url = productUrl(slug);
  return lang === "kg"
    ? `Саламатсызбы! Мени бул товар кызыктырат: ${name}. Баасы: ${price}. Шилтеме: ${url}`
    : `Здравствуйте! Интересует товар: ${name}. Цена: ${price}. Ссылка: ${url}`;
}

export function trackEvent(
  type: "visit" | "product_view" | "whatsapp_click" | "phone_click",
  productId?: number,
) {
  // Не блокируем UI, ошибки молча игнорируем
  void fetch("/api/trpc/catalog.track", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ json: { type, productId } }),
  }).catch(() => {});
}

export function trackVisitOnce() {
  if (sessionStorage.getItem("visit_tracked")) return;
  sessionStorage.setItem("visit_tracked", "1");
  trackEvent("visit");
}

export type PublicSettings = SettingsMap & { logo_resolved: string };

export function useSettings() {
  const query = trpc.catalog.settings.useQuery(undefined, {
    staleTime: 60_000,
  });
  return query;
}
