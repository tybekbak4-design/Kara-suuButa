import { Link } from "react-router";
import { useLang } from "@/i18n";

export default function NotFound() {
  const { t } = useLang();
  return (
    <div className="mx-auto flex max-w-7xl flex-col items-center px-4 py-24 text-center">
      <div className="text-6xl font-extrabold text-neutral-200">404</div>
      <h1 className="mt-4 text-xl font-extrabold text-neutral-900">{t.notFoundTitle}</h1>
      <p className="mt-2 max-w-sm text-sm text-neutral-500">{t.notFoundHint}</p>
      <Link to="/" className="mt-6 flex h-11 items-center bg-[var(--brand)] px-6 text-sm font-bold text-white">
        {t.toHome}
      </Link>
    </div>
  );
}
