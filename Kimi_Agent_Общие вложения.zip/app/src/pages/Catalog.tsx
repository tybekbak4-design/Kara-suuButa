import { useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router";
import { SlidersHorizontal, X, ChevronRight } from "lucide-react";
import { useLang, loc } from "@/i18n";
import { trpc } from "@/providers/trpc";
import type { CardProduct, FilterDef } from "@/types";
import { ProductCard } from "@/components/ProductCard";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 24;

export default function Catalog() {
  const { lang, t } = useLang();
  const { categorySlug } = useParams<{ categorySlug: string }>();
  const [params, setParams] = useSearchParams();
  const [filtersOpen, setFiltersOpen] = useState(false);

  const q = params.get("q") ?? "";
  const sort = (params.get("sort") ?? "popular") as "popular" | "price_asc" | "price_desc" | "new";
  const brandsSel = useMemo(() => (params.get("brand") ?? "").split(",").filter(Boolean), [params]);
  const minPrice = params.get("min") ? Number(params.get("min")) : undefined;
  const maxPrice = params.get("max") ? Number(params.get("max")) : undefined;
  const inStock = params.get("stock") === "1";
  const onSale = params.get("sale") === "1";
  const page = params.get("page") ? Number(params.get("page")) : 1;
  const specSel = useMemo(() => {
    const out: Record<string, string[]> = {};
    for (const [k, v] of params.entries()) {
      if (k.startsWith("f_")) out[k.slice(2)] = v.split("~").filter(Boolean);
    }
    return out;
  }, [params]);

  const patchParams = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v == null || v === "") next.delete(k);
      else next.set(k, v);
    }
    if (!("page" in patch)) next.delete("page");
    setParams(next, { preventScrollReset: false });
  };

  const { data: categories } = trpc.catalog.categories.useQuery(undefined, { staleTime: 60_000 });
  const { data: brands } = trpc.catalog.brands.useQuery(undefined, { staleTime: 60_000 });
  const { data: filterDefs } = trpc.catalog.categoryFilters.useQuery(
    { categorySlug: categorySlug ?? "" },
    { enabled: Boolean(categorySlug), staleTime: 60_000 },
  );

  const queryInput = {
    q: q || undefined,
    categorySlug: categorySlug || undefined,
    brandSlugs: brandsSel.length > 0 ? brandsSel : undefined,
    minPrice,
    maxPrice,
    inStock: inStock || undefined,
    onSale: onSale || undefined,
    sort,
    specFilters: Object.keys(specSel).length > 0 ? specSel : undefined,
    page,
    limit: PAGE_SIZE,
  };
  const { data, isLoading } = trpc.catalog.products.useQuery(queryInput);

  const currentCategory = categories?.find((c) => c.slug === categorySlug);

  const toggleBrand = (slug: string) => {
    const next = brandsSel.includes(slug)
      ? brandsSel.filter((b) => b !== slug)
      : [...brandsSel, slug];
    patchParams({ brand: next.join(",") || null });
  };

  const toggleSpec = (keySlug: string, value: string) => {
    const current = specSel[keySlug] ?? [];
    const next = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];
    patchParams({ [`f_${keySlug}`]: next.join("~") || null });
  };

  const [minInput, setMinInput] = useState(params.get("min") ?? "");
  const [maxInput, setMaxInput] = useState(params.get("max") ?? "");

  const filtersBody = (
    <div className="space-y-6">
      {/* Категории */}
      <FilterBlock title={t.category}>
        <Link
          to="/catalog"
          className={cn(
            "block px-2 py-1.5 text-sm transition-colors",
            !categorySlug ? "font-bold text-[var(--accent)]" : "text-neutral-700 hover:text-neutral-900",
          )}
        >
          {t.allCategories}
        </Link>
        {(categories ?? []).map((c) => (
          <Link
            key={c.id}
            to={`/catalog/${c.slug}`}
            className={cn(
              "flex items-center justify-between px-2 py-1.5 text-sm transition-colors",
              c.slug === categorySlug
                ? "font-bold text-[var(--accent)]"
                : "text-neutral-700 hover:text-neutral-900",
            )}
          >
            {loc(lang, c.nameRu, c.nameKg)}
            <span className="text-xs text-neutral-400">{c.productCount}</span>
          </Link>
        ))}
      </FilterBlock>

      {/* Цена */}
      <FilterBlock title={t.price}>
        <div className="flex items-center gap-2 px-2">
          <input
            type="number"
            inputMode="numeric"
            min={0}
            value={minInput}
            onChange={(e) => setMinInput(e.target.value)}
            placeholder={t.priceFrom}
            aria-label={t.priceFrom}
            className="h-9 w-full border border-neutral-300 px-2 text-sm outline-none focus:border-neutral-900"
          />
          <span className="text-xs text-neutral-400">{t.priceTo}</span>
          <input
            type="number"
            inputMode="numeric"
            min={0}
            value={maxInput}
            onChange={(e) => setMaxInput(e.target.value)}
            placeholder="∞"
            aria-label={t.priceTo}
            className="h-9 w-full border border-neutral-300 px-2 text-sm outline-none focus:border-neutral-900"
          />
          <button
            type="button"
            onClick={() => patchParams({ min: minInput || null, max: maxInput || null })}
            className="h-9 shrink-0 cursor-pointer bg-[var(--brand)] px-3 text-xs font-bold text-white"
          >
            OK
          </button>
        </div>
      </FilterBlock>

      {/* Бренды */}
      <FilterBlock title={t.brand}>
        {(brands ?? []).map((b) => (
          <label key={b.id} className="flex cursor-pointer items-center gap-2 px-2 py-1.5 text-sm text-neutral-700">
            <input
              type="checkbox"
              checked={brandsSel.includes(b.slug)}
              onChange={() => toggleBrand(b.slug)}
              className="h-4 w-4 accent-[var(--accent)]"
            />
            {b.name}
          </label>
        ))}
      </FilterBlock>

      {/* Наличие */}
      <FilterBlock title={t.filters}>
        <label className="flex cursor-pointer items-center gap-2 px-2 py-1.5 text-sm text-neutral-700">
          <input
            type="checkbox"
            checked={inStock}
            onChange={(e) => patchParams({ stock: e.target.checked ? "1" : null })}
            className="h-4 w-4 accent-[var(--accent)]"
          />
          {t.onlyInStock}
        </label>
      </FilterBlock>

      {/* Фильтры характеристик категории */}
      {((filterDefs ?? []) as FilterDef[]).map((def) => (
        <FilterBlock key={def.id} title={loc(lang, def.labelRu, def.labelKg)}>
          {def.values.map((v) => (
            <label
              key={v.valueRu}
              className="flex cursor-pointer items-center gap-2 px-2 py-1.5 text-sm text-neutral-700"
            >
              <input
                type="checkbox"
                checked={(specSel[def.keySlug] ?? []).includes(v.valueRu)}
                onChange={() => toggleSpec(def.keySlug, v.valueRu)}
                className="h-4 w-4 accent-[var(--accent)]"
              />
              {loc(lang, v.valueRu, v.valueKg)}
            </label>
          ))}
        </FilterBlock>
      ))}
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Хлебные крошки */}
      <nav className="mb-4 flex items-center gap-1 text-xs text-neutral-500" aria-label="breadcrumbs">
        <Link to="/" className="hover:text-neutral-900">{t.home}</Link>
        <ChevronRight size={12} />
        <Link to="/catalog" className={categorySlug ? "hover:text-neutral-900" : "font-semibold text-neutral-900"}>
          {t.catalog}
        </Link>
        {currentCategory && (
          <>
            <ChevronRight size={12} />
            <span className="font-semibold text-neutral-900">
              {loc(lang, currentCategory.nameRu, currentCategory.nameKg)}
            </span>
          </>
        )}
        {q && (
          <>
            <ChevronRight size={12} />
            <span className="font-semibold text-neutral-900">«{q}»</span>
          </>
        )}
      </nav>

      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
          {q
            ? `${t.search}: «${q}»`
            : currentCategory
              ? loc(lang, currentCategory.nameRu, currentCategory.nameKg)
              : t.catalog}
          {data && (
            <span className="ml-2 text-sm font-normal text-neutral-400">
              {t.found}: {data.total}
            </span>
          )}
        </h1>
        <div className="flex items-center gap-2">
          {/* Мобильные фильтры */}
          <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                className="flex h-10 cursor-pointer items-center gap-2 border border-neutral-300 bg-white px-3 text-sm font-semibold text-neutral-800 lg:hidden"
              >
                <SlidersHorizontal size={16} />
                {t.filters}
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 overflow-y-auto">
              <SheetHeader className="text-left">
                <SheetTitle>{t.filters}</SheetTitle>
              </SheetHeader>
              <div className="p-4 pt-0" onClick={(e) => {
                if ((e.target as HTMLElement).closest("a")) setFiltersOpen(false);
              }}>
                {filtersBody}
              </div>
            </SheetContent>
          </Sheet>

          <select
            value={sort}
            onChange={(e) => patchParams({ sort: e.target.value })}
            aria-label={t.sort}
            className="h-10 cursor-pointer border border-neutral-300 bg-white px-2 text-sm font-medium text-neutral-800 outline-none"
          >
            <option value="popular">{t.sortPopular}</option>
            <option value="price_asc">{t.sortPriceAsc}</option>
            <option value="price_desc">{t.sortPriceDesc}</option>
            <option value="new">{t.sortNew}</option>
          </select>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[250px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-32 border border-neutral-200 bg-white p-4">{filtersBody}</div>
        </aside>

        <div>
          {isLoading ? (
            <div className="py-20 text-center text-sm text-neutral-400">{t.loading}</div>
          ) : data && data.items.length > 0 ? (
            <>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
                {(data.items as CardProduct[]).map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
              {data.pages > 1 && (
                <nav className="mt-8 flex items-center justify-center gap-1" aria-label="pagination">
                  {Array.from({ length: data.pages }, (_, i) => i + 1)
                    .filter((p) => p === 1 || p === data.pages || Math.abs(p - data.page) <= 2)
                    .map((p, idx, arr) => (
                      <span key={p} className="flex items-center">
                        {idx > 0 && arr[idx - 1] !== p - 1 && (
                          <span className="px-1 text-neutral-400">…</span>
                        )}
                        <button
                          type="button"
                          onClick={() => patchParams({ page: String(p) })}
                          aria-current={p === data.page ? "page" : undefined}
                          className={cn(
                            "h-10 min-w-10 cursor-pointer border px-2 text-sm font-semibold transition-colors",
                            p === data.page
                              ? "border-[var(--accent)] bg-[var(--accent)] text-white"
                              : "border-neutral-200 bg-white text-neutral-700 hover:border-neutral-900",
                          )}
                        >
                          {p}
                        </button>
                      </span>
                    ))}
                </nav>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center gap-2 border border-dashed border-neutral-300 bg-white py-20 text-center">
              <div className="text-lg font-bold text-neutral-800">{t.nothingFound}</div>
              <div className="text-sm text-neutral-500">{t.nothingFoundHint}</div>
              <button
                type="button"
                onClick={() => setParams(new URLSearchParams())}
                className="mt-3 flex h-10 cursor-pointer items-center gap-2 bg-[var(--brand)] px-4 text-sm font-bold text-white"
              >
                <X size={15} /> {t.reset}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 px-2 text-xs font-bold uppercase tracking-wider text-neutral-500">
        {title}
      </div>
      <div className="max-h-56 overflow-y-auto">{children}</div>
    </div>
  );
}
