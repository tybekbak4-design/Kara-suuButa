import { useEffect, useState } from "react";
import { Link } from "react-router";
import { Eye, Users, Phone, MessageSquare, Package } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi } from "@/lib/adminApi";
import { PageTitle, Card } from "./ui";
import { WhatsAppIcon } from "@/components/WhatsAppIcon";

type Stats = Awaited<ReturnType<typeof adminApi.admin.statsSummary.query>>;

export default function AdminDashboard() {
  const { t } = useLang();
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    adminApi.admin.statsSummary.query().then(setStats).catch(() => {});
  }, []);

  if (!stats) return <div className="text-sm text-neutral-400">{t.loading}</div>;

  const cards = [
    { label: t.adminStatsVisits, value: stats.totals.visit, icon: Users },
    { label: t.adminStatsViews, value: stats.totals.product_view, icon: Eye },
    { label: t.adminStatsWhatsapp, value: stats.totals.whatsapp_click, icon: MessageSquare },
    { label: t.adminStatsPhone, value: stats.totals.phone_click, icon: Phone },
  ];
  const maxDaily = Math.max(1, ...stats.dailyVisits.map((d) => d.count));

  return (
    <div>
      <PageTitle>{t.adminDashboard}</PageTitle>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center bg-[var(--accent)]/10 text-[var(--accent)]">
                <c.icon size={20} />
              </span>
              <div>
                <div className="text-2xl font-extrabold text-neutral-900">{c.value}</div>
                <div className="text-xs text-neutral-500">{c.label}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title={t.adminStatsDaily}>
          {stats.dailyVisits.length === 0 ? (
            <div className="py-6 text-center text-sm text-neutral-400">—</div>
          ) : (
            <div className="flex h-36 items-end gap-1.5">
              {stats.dailyVisits.map((d) => (
                <div key={d.day} className="flex min-w-0 flex-1 flex-col items-center gap-1">
                  <span className="text-[10px] font-semibold text-neutral-500">{d.count}</span>
                  <div
                    className="w-full bg-[var(--accent)]/80"
                    style={{ height: `${Math.max(4, (d.count / maxDaily) * 100)}%` }}
                    title={`${d.day}: ${d.count}`}
                  />
                  <span className="text-[9px] text-neutral-400">{d.day.slice(5)}</span>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card title={t.adminStatsTop}>
          <table className="w-full text-sm">
            <tbody>
              {stats.topProducts.map((p, i) => (
                <tr key={p.id} className="border-b border-neutral-100 last:border-0">
                  <td className="py-2 pr-2 text-neutral-400">{i + 1}</td>
                  <td className="py-2">
                    <Link to={`/product/${p.slug}`} className="font-medium text-neutral-800 hover:text-[var(--accent)]">
                      {p.name}
                    </Link>
                  </td>
                  <td className="py-2 text-right font-semibold text-neutral-600">
                    {p.views} <span className="text-xs font-normal text-neutral-400">{t.adminViews}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        <Card>
          <div className="flex items-center gap-3">
            <Package size={20} className="text-neutral-400" />
            <div>
              <div className="text-xl font-extrabold">{stats.productsCount}</div>
              <div className="text-xs text-neutral-500">{t.adminProducts}</div>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <MessageSquare size={20} className="text-neutral-400" />
            <div>
              <div className="text-xl font-extrabold">{stats.pendingReviews}</div>
              <div className="text-xs text-neutral-500">{t.adminPending}</div>
            </div>
            {stats.pendingReviews > 0 && (
              <Link to="/admin/reviews" className="ml-auto text-xs font-bold text-[var(--accent)] hover:underline">
                →
              </Link>
            )}
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <WhatsAppIcon size={20} className="text-neutral-400" />
            <div>
              <div className="text-xl font-extrabold">{stats.totals.whatsapp_click}</div>
              <div className="text-xs text-neutral-500">{t.adminStatsWhatsapp}</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
