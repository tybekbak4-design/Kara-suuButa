import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router";
import { Check, X, Trash2 } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi } from "@/lib/adminApi";
import { PageTitle, Card, Confirm, useToast } from "./ui";
import { RatingStars } from "@/components/RatingStars";
import { cn } from "@/lib/utils";

type Row = Awaited<ReturnType<typeof adminApi.admin.reviewsList.query>>[number];
type Status = "pending" | "approved" | "rejected";

export default function AdminReviews() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const [status, setStatus] = useState<Status>("pending");
  const [rows, setRows] = useState<Row[]>([]);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setRows(await adminApi.admin.reviewsList.query({ status }));
  }, [status]);

  useEffect(() => {
    void load();
  }, [load]);

  const setReviewStatus = async (id: number, s: "approved" | "rejected") => {
    await adminApi.admin.reviewSetStatus.mutate({ id, status: s });
    toast.ok();
    void load();
  };

  const doDelete = async () => {
    if (deleteId == null) return;
    await adminApi.admin.reviewDelete.mutate({ id: deleteId });
    setDeleteId(null);
    toast.ok(t.adminDeletedOk);
    void load();
  };

  const tabs: { key: Status; label: string }[] = [
    { key: "pending", label: t.adminPending },
    { key: "approved", label: t.adminApproved },
    { key: "rejected", label: t.adminRejected },
  ];

  return (
    <div>
      {toastNode}
      <PageTitle>{t.adminReviews}</PageTitle>
      <div className="mb-4 flex gap-1 border-b border-neutral-200">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setStatus(tab.key)}
            className={cn(
              "-mb-px cursor-pointer border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors",
              status === tab.key
                ? "border-[var(--accent)] text-[var(--accent)]"
                : "border-transparent text-neutral-500 hover:text-neutral-900",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {rows.length === 0 ? (
        <Card>
          <div className="py-8 text-center text-sm text-neutral-400">—</div>
        </Card>
      ) : (
        <div className="grid gap-3">
          {rows.map((r) => (
            <Card key={r.review.id}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold text-neutral-900">{r.review.authorName}</span>
                    <RatingStars value={r.review.rating} size={14} />
                    <span className="text-xs text-neutral-400">
                      {new Date(r.review.createdAt).toLocaleString("ru-RU")}
                    </span>
                  </div>
                  <p className="mt-2 text-sm leading-6 text-neutral-700">{r.review.text}</p>
                  <Link to={`/product/${r.productSlug}`} className="mt-1 inline-block text-xs font-semibold text-[var(--accent)] hover:underline">
                    {r.productName}
                  </Link>
                </div>
                <div className="flex gap-1.5">
                  {status !== "approved" && (
                    <button
                      type="button"
                      onClick={() => setReviewStatus(r.review.id, "approved")}
                      title={t.adminApprove}
                      className="flex h-9 cursor-pointer items-center gap-1.5 border border-emerald-200 px-3 text-sm font-semibold text-emerald-600 hover:bg-emerald-50"
                    >
                      <Check size={15} /> {t.adminApprove}
                    </button>
                  )}
                  {status !== "rejected" && (
                    <button
                      type="button"
                      onClick={() => setReviewStatus(r.review.id, "rejected")}
                      title={t.adminReject}
                      className="flex h-9 cursor-pointer items-center gap-1.5 border border-amber-200 px-3 text-sm font-semibold text-amber-600 hover:bg-amber-50"
                    >
                      <X size={15} /> {t.adminReject}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setDeleteId(r.review.id)}
                    title={t.adminDelete}
                    className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Confirm open={deleteId != null} text={t.adminConfirmDeleteText} onConfirm={doDelete} onCancel={() => setDeleteId(null)} />
    </div>
  );
}
