import { useEffect, useRef, useState } from "react";
import { FileSpreadsheet, Upload, Save, Trash2, AlertTriangle, CheckCircle2 } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi, fileToBase64 } from "@/lib/adminApi";
import { PageTitle, Card, Field, btnAccent, btnOutline, useToast } from "./ui";
import type { ImportField } from "@contracts/types";

type Preview = Awaited<ReturnType<typeof adminApi.excel.preview.mutate>>;
type Report = Awaited<ReturnType<typeof adminApi.excel.import.mutate>>;
type Mapping = Awaited<ReturnType<typeof adminApi.admin.importMappingsList.query>>[number];

const FIELD_LABELS: Record<ImportField, string> = {
  nameRu: "Название товара RU",
  nameKg: "Название товара KG",
  slug: "Slug (ЧПУ)",
  category: "Категория",
  brand: "Бренд",
  price: "Цена",
  oldPrice: "Старая цена",
  warranty: "Гарантия",
  inStock: "Наличие",
  descriptionRu: "Описание RU",
  descriptionKg: "Описание KG",
  specs: "Характеристики",
  imageUrl: "Ссылка на фотографию",
  additionalImages: "Дополнительные фотографии",
  isPopular: "Популярный",
  isNew: "Новинка",
};

export default function AdminImport() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<{ name: string; base64: string } | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [dupMode, setDupMode] = useState<"skip" | "update">("skip");
  const [report, setReport] = useState<Report | null>(null);
  const [busy, setBusy] = useState(false);
  const [mappings, setMappings] = useState<Mapping[]>([]);
  const [mappingName, setMappingName] = useState("");

  useEffect(() => {
    adminApi.admin.importMappingsList.query().then(setMappings).catch(() => {});
  }, []);

  const pickFile = async (files: FileList | null) => {
    const f = files?.[0];
    if (!f) return;
    if (!/\.(xlsx|xls)$/i.test(f.name)) {
      toast.err("Поддерживаются только .xlsx и .xls");
      return;
    }
    setBusy(true);
    setReport(null);
    try {
      const base64 = await fileToBase64(f);
      setFile({ name: f.name, base64 });
      const pv = await adminApi.excel.preview.mutate({ fileName: f.name, contentBase64: base64 });
      setPreview(pv);
      setMapping(pv.suggestedMapping as Record<string, string>);
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка чтения файла");
      setFile(null);
      setPreview(null);
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const runImport = async () => {
    if (!file) return;
    setBusy(true);
    setReport(null);
    try {
      const res = await adminApi.excel.import.mutate({
        fileName: file.name,
        contentBase64: file.base64,
        mapping,
        duplicateMode: dupMode,
      });
      setReport(res);
      toast.ok();
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка импорта");
    } finally {
      setBusy(false);
    }
  };

  const saveMapping = async () => {
    if (!mappingName.trim()) return;
    await adminApi.admin.importMappingSave.mutate({ name: mappingName.trim(), mapping });
    setMappingName("");
    setMappings(await adminApi.admin.importMappingsList.query());
    toast.ok();
  };

  const required = preview?.requiredFields ?? [];
  const mappedFields = new Set(Object.values(mapping).filter(Boolean));
  const missingRequired = required.filter((f) => !mappedFields.has(f));

  return (
    <div>
      {toastNode}
      <PageTitle>{t.adminImportTitle}</PageTitle>

      <div className="grid gap-4">
        {/* Шаг 1: файл */}
        <Card title={t.adminImportStep1}>
          <div className="flex flex-wrap items-center gap-3">
            <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => pickFile(e.target.files)} />
            <button type="button" onClick={() => fileRef.current?.click()} disabled={busy} className={btnOutline}>
              <Upload size={15} /> {file ? file.name : ".xlsx / .xls"}
            </button>
            {busy && <span className="text-sm text-neutral-400">{t.loading}</span>}
            {file && preview && (
              <span className="flex items-center gap-1.5 text-sm text-emerald-600">
                <FileSpreadsheet size={15} /> {file.name} — {preview.totalRows} строк
              </span>
            )}
          </div>
        </Card>

        {preview && (
          <>
            {/* Шаг 2: сопоставление */}
            <Card title={t.adminImportStep2}>
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {preview.headers.map((h) => (
                  <div key={h} className="flex items-center gap-2 border border-neutral-200 p-2">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-xs font-semibold text-neutral-700" title={h}>{h}</div>
                      <select
                        value={mapping[h] ?? ""}
                        onChange={(e) => setMapping((m) => ({ ...m, [h]: e.target.value }))}
                        className="mt-1 h-8 w-full border border-neutral-300 text-xs outline-none"
                      >
                        <option value="">{t.adminImportIgnore}</option>
                        {preview.fields.map((f) => (
                          <option key={f} value={f}>
                            {FIELD_LABELS[f as ImportField] ?? f}
                            {required.includes(f as never) ? " *" : ""}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                ))}
              </div>
              {missingRequired.length > 0 && (
                <div className="mt-3 flex items-center gap-2 border border-amber-200 bg-amber-50 p-3 text-sm text-amber-700">
                  <AlertTriangle size={15} />
                  Не сопоставлены обязательные поля: {missingRequired.map((f) => FIELD_LABELS[f as ImportField]).join(", ")}
                </div>
              )}

              {/* Сохранённые маппинги */}
              <div className="mt-4 border-t border-neutral-100 pt-4">
                <div className="mb-2 text-xs font-bold text-neutral-500">{t.adminImportMappings}</div>
                <div className="flex flex-wrap items-center gap-2">
                  {mappings.map((m) => (
                    <span key={m.id} className="flex items-center gap-1 border border-neutral-200 px-2 py-1 text-xs">
                      <button
                        type="button"
                        onClick={() => setMapping(JSON.parse(m.mapping))}
                        className="cursor-pointer font-semibold text-neutral-700 hover:text-[var(--accent)]"
                      >
                        {m.name}
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await adminApi.admin.importMappingDelete.mutate({ id: m.id });
                          setMappings(await adminApi.admin.importMappingsList.query());
                        }}
                        className="cursor-pointer text-red-400 hover:text-red-600"
                        aria-label={t.adminDelete}
                      >
                        <Trash2 size={12} />
                      </button>
                    </span>
                  ))}
                  <input
                    value={mappingName}
                    onChange={(e) => setMappingName(e.target.value)}
                    placeholder={t.adminName}
                    className="h-8 w-40 border border-neutral-300 px-2 text-xs outline-none"
                  />
                  <button type="button" onClick={saveMapping} className="flex h-8 cursor-pointer items-center gap-1 border border-neutral-300 px-2 text-xs font-semibold hover:border-neutral-900">
                    <Save size={12} /> {t.adminImportSaveMapping}
                  </button>
                </div>
              </div>
            </Card>

            {/* Превью таблицы */}
            <Card title={`${t.adminImportPreview} (${preview.previewRows.length} / ${preview.totalRows})`}>
              <div className="max-h-80 overflow-auto">
                <table className="w-full min-w-[600px] border-collapse text-xs">
                  <thead>
                    <tr>
                      <th className="border border-neutral-200 bg-neutral-50 px-2 py-1.5 text-left text-neutral-500">#</th>
                      {preview.headers.map((h) => (
                        <th key={h} className="border border-neutral-200 bg-neutral-50 px-2 py-1.5 text-left font-semibold text-neutral-700">
                          {h}
                          {mapping[h] && (
                            <div className="font-normal text-[var(--accent)]">→ {FIELD_LABELS[mapping[h] as ImportField] ?? mapping[h]}</div>
                          )}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.previewRows.map((row, i) => (
                      <tr key={i}>
                        <td className="border border-neutral-100 px-2 py-1 text-neutral-400">{i + 2}</td>
                        {preview.headers.map((h) => (
                          <td key={h} className="max-w-48 truncate border border-neutral-100 px-2 py-1 text-neutral-700">
                            {String(row[h] ?? "")}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            {/* Шаг 3: запуск */}
            <Card title={t.adminImportStep3}>
              <div className="flex flex-wrap items-center gap-4">
                <Field label={t.adminImportDuplicates}>
                  <div className="flex gap-3">
                    {(["skip", "update"] as const).map((mode) => (
                      <label key={mode} className="flex cursor-pointer items-center gap-2 text-sm text-neutral-700">
                        <input
                          type="radio"
                          name="dupmode"
                          checked={dupMode === mode}
                          onChange={() => setDupMode(mode)}
                          className="h-4 w-4 accent-[var(--accent)]"
                        />
                        {mode === "skip" ? t.adminDupSkip : t.adminDupUpdate}
                      </label>
                    ))}
                  </div>
                </Field>
                <button
                  type="button"
                  onClick={runImport}
                  disabled={busy || missingRequired.length > 0}
                  className={btnAccent}
                >
                  <FileSpreadsheet size={15} /> {t.adminImportRun}
                </button>
              </div>
            </Card>
          </>
        )}

        {/* Отчёт */}
        {report && (
          <Card title={t.adminImportResult}>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label={t.adminImportCreated} value={report.created} />
              <Stat label={t.adminImportUpdated} value={report.updated} />
              <Stat label={t.adminImportSkipped} value={report.skipped} />
              <Stat label={t.adminImportErrors} value={report.errors.length} danger={report.errors.length > 0} />
            </div>
            {(report.createdBrands.length > 0 || report.createdCategories.length > 0) && (
              <div className="mt-3 flex items-start gap-2 border border-sky-200 bg-sky-50 p-3 text-sm text-sky-700">
                <CheckCircle2 size={15} className="mt-0.5 shrink-0" />
                <div>
                  {report.createdCategories.length > 0 && (
                    <div>Новые категории: {report.createdCategories.join(", ")}</div>
                  )}
                  {report.createdBrands.length > 0 && (
                    <div>Новые бренды: {report.createdBrands.join(", ")}</div>
                  )}
                </div>
              </div>
            )}
            {report.errors.length > 0 && (
              <div className="mt-3 max-h-64 overflow-y-auto border border-red-100">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-red-50 text-left">
                      <th className="px-2 py-1.5 text-red-700">{t.adminImportRow}</th>
                      <th className="px-2 py-1.5 text-red-700">{t.adminImportErrors}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {report.errors.map((e, i) => (
                      <tr key={i} className="border-t border-red-100">
                        <td className="px-2 py-1.5 font-semibold text-red-700">{e.row}</td>
                        <td className="px-2 py-1.5 text-neutral-700">{e.message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, danger }: { label: string; value: number; danger?: boolean }) {
  return (
    <div className={`border p-3 text-center ${danger ? "border-red-200 bg-red-50" : "border-neutral-200 bg-neutral-50"}`}>
      <div className={`text-2xl font-extrabold ${danger ? "text-red-600" : "text-neutral-900"}`}>{value}</div>
      <div className="text-xs text-neutral-500">{label}</div>
    </div>
  );
}
