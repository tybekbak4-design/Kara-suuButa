import { useRef, useState } from "react";
import { Pencil, Trash2, Upload } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi, fileToBase64 } from "@/lib/adminApi";
import { trpc } from "@/providers/trpc";
import { PageTitle, Card, Field, Confirm, inputCls, btnAccent, btnOutline, useToast } from "./ui";
import { Img } from "@/components/Img";

export default function AdminBrands() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const { data: brands, refetch } = trpc.catalog.brands.useQuery();
  const fileRef = useRef<HTMLInputElement>(null);

  const [editId, setEditId] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [logoKey, setLogoKey] = useState("");
  const [logoPreview, setLogoPreview] = useState("");
  const [sortOrder, setSortOrder] = useState(0);
  const [isPopular, setIsPopular] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const resetForm = () => {
    setEditId(null);
    setName("");
    setLogoUrl("");
    setLogoKey("");
    setLogoPreview("");
    setSortOrder(0);
    setIsPopular(false);
  };

  const uploadLogo = async (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    const base64 = await fileToBase64(file);
    const res = await adminApi.admin.uploadImage.mutate({
      name: file.name,
      contentBase64: base64,
      contentType: file.type || undefined,
    });
    const { url } = await adminApi.admin.imageUrl.query({ key: res.key });
    setLogoKey(res.key);
    setLogoUrl("");
    setLogoPreview(url);
    if (fileRef.current) fileRef.current.value = "";
  };

  const save = async () => {
    if (!name.trim()) return;
    const payload = {
      name: name.trim(),
      logoUrl: logoUrl.trim() || null,
      logoKey: logoKey || null,
      sortOrder,
      isPopular,
    };
    if (editId) {
      await adminApi.admin.brandUpdate.mutate({ id: editId, ...payload });
    } else {
      await adminApi.admin.brandCreate.mutate(payload);
    }
    toast.ok();
    resetForm();
    void refetch();
  };

  const doDelete = async () => {
    if (deleteId == null) return;
    try {
      await adminApi.admin.brandDelete.mutate({ id: deleteId });
      toast.ok(t.adminDeletedOk);
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка");
    }
    setDeleteId(null);
    void refetch();
  };

  return (
    <div>
      {toastNode}
      <PageTitle>{t.adminBrands}</PageTitle>
      <div className="grid gap-4 lg:grid-cols-[380px_1fr]">
        <Card title={editId ? t.adminEdit : t.adminCreate}>
          <div className="grid gap-4">
            <Field label={`${t.adminName} *`}>
              <input value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
            </Field>
            <Field label={t.adminLogo}>
              <div className="flex items-center gap-2">
                {logoPreview && <Img src={logoPreview} alt="" className="h-10 w-16 border border-neutral-200 object-contain" />}
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => uploadLogo(e.target.files)} />
                <button type="button" onClick={() => fileRef.current?.click()} className={btnOutline}>
                  <Upload size={14} />
                </button>
              </div>
              <input
                value={logoUrl}
                onChange={(e) => {
                  setLogoUrl(e.target.value);
                  setLogoKey("");
                  setLogoPreview(e.target.value);
                }}
                placeholder="https://…"
                className={`${inputCls} mt-2`}
              />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label={t.sort}>
                <input type="number" value={sortOrder} onChange={(e) => setSortOrder(Number(e.target.value))} className={inputCls} />
              </Field>
              <label className="mt-6 flex cursor-pointer items-center gap-2 text-sm text-neutral-700">
                <input type="checkbox" checked={isPopular} onChange={(e) => setIsPopular(e.target.checked)} className="h-4 w-4 accent-[var(--accent)]" />
                {t.adminPopular}
              </label>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={save} className={btnAccent}>
                {editId ? t.adminSave : t.adminCreate}
              </button>
              {editId && <button type="button" onClick={resetForm} className={btnOutline}>{t.adminCancel}</button>}
            </div>
          </div>
        </Card>

        <Card>
          <div className="divide-y divide-neutral-100">
            {(brands ?? []).map((b) => (
              <div key={b.id} className="flex items-center gap-3 py-2.5">
                {b.logo ? (
                  <Img src={b.logo} alt={b.name} className="h-9 w-14 border border-neutral-100 object-contain" />
                ) : (
                  <span className="flex h-9 w-14 items-center justify-center border border-neutral-100 text-xs font-bold text-neutral-400">
                    {b.name.slice(0, 2).toUpperCase()}
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-neutral-900">{b.name}</div>
                  <div className="text-xs text-neutral-400">{b.slug}{b.isPopular && ` · ${t.adminPopular}`}</div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEditId(b.id);
                    setName(b.name);
                    setLogoUrl(b.logoUrl ?? "");
                    setLogoKey(b.logoKey ?? "");
                    setLogoPreview(b.logo ?? "");
                    setSortOrder(b.sortOrder);
                    setIsPopular(b.isPopular);
                  }}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center border border-neutral-200 text-neutral-500 hover:border-neutral-900"
                >
                  <Pencil size={15} />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteId(b.id)}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <Confirm open={deleteId != null} text={t.adminConfirmDeleteText} onConfirm={doDelete} onCancel={() => setDeleteId(null)} />
    </div>
  );
}
