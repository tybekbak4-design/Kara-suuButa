import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router";
import {
  LayoutDashboard,
  Package,
  FolderTree,
  Tag,
  Image,
  MessageSquare,
  FileSpreadsheet,
  Settings,
  LogOut,
  ExternalLink,
  Menu,
} from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi, getAdminToken, setAdminToken } from "@/lib/adminApi";
import { cn } from "@/lib/utils";

export default function AdminLayout() {
  const { t } = useLang();
  const navigate = useNavigate();
  const [checked, setChecked] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!getAdminToken()) {
      navigate("/admin/login", { replace: true });
      return;
    }
    adminApi.admin.me
      .query()
      .then(() => setChecked(true))
      .catch(() => {
        setAdminToken(null);
        navigate("/admin/login", { replace: true });
      });
  }, [navigate]);

  if (!checked) {
    return <div className="flex min-h-dvh items-center justify-center text-sm text-neutral-400">{t.loading}</div>;
  }

  const nav = [
    { to: "/admin", icon: LayoutDashboard, label: t.adminDashboard, end: true },
    { to: "/admin/products", icon: Package, label: t.adminProducts },
    { to: "/admin/categories", icon: FolderTree, label: t.adminCategories },
    { to: "/admin/brands", icon: Tag, label: t.adminBrands },
    { to: "/admin/banners", icon: Image, label: t.adminBanners },
    { to: "/admin/reviews", icon: MessageSquare, label: t.adminReviews },
    { to: "/admin/import", icon: FileSpreadsheet, label: t.adminImport },
    { to: "/admin/settings", icon: Settings, label: t.adminSettings },
  ];

  const logout = async () => {
    try {
      await adminApi.admin.logout.mutate();
    } catch {
      // сессия уже недействительна
    }
    setAdminToken(null);
    navigate("/admin/login", { replace: true });
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="border-b border-white/10 p-4 text-sm font-extrabold text-white">
        {t.adminSettings} — CMS
      </div>
      <nav className="flex-1 overflow-y-auto p-2">
        {nav.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={() => setMenuOpen(false)}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2.5 px-3 py-2.5 text-sm font-medium transition-colors",
                isActive ? "bg-[var(--accent)] text-white" : "text-white/70 hover:bg-white/10 hover:text-white",
              )
            }
          >
            <item.icon size={17} />
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-white/10 p-2">
        <Link
          to="/"
          className="flex items-center gap-2.5 px-3 py-2.5 text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white"
        >
          <ExternalLink size={16} /> {t.adminBackToSite}
        </Link>
        <button
          type="button"
          onClick={logout}
          className="flex w-full cursor-pointer items-center gap-2.5 px-3 py-2.5 text-left text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white"
        >
          <LogOut size={16} /> {t.adminLogout}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-dvh bg-neutral-100">
      {/* Десктоп-сайдбар */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 bg-[var(--brand)] lg:block">
        {sidebar}
      </aside>
      {/* Мобильный сайдбар */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMenuOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-64 bg-[var(--brand)]">{sidebar}</aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col lg:ml-60">
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-neutral-200 bg-white px-4 lg:hidden">
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            aria-label={t.menu}
            className="flex h-10 w-10 cursor-pointer items-center justify-center border border-neutral-200 text-neutral-700"
          >
            <Menu size={18} />
          </button>
          <span className="text-sm font-bold text-neutral-900">CMS</span>
        </header>
        <main className="min-w-0 flex-1 p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
