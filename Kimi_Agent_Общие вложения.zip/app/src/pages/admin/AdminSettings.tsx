import { useEffect, useRef, useState } from "react";
import { Upload, Trash2 } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi, fileToBase64 } from "@/lib/adminApi";
import { PageTitle, Card, Field, inputCls, textareaCls, btnAccent, btnOutline, useToast } from "./ui";
import { Img } from "@/components/Img";
import type { SettingsMap } from "@contracts/types";

export default function AdminSettings() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const [form, setForm] = useState<SettingsMap | null>(null);
  const [logoPreview, setLogoPreview] = useState("");
  const [saving, setSaving] = useState(false);
  const [pw, setPw] = useState({ current: "", next: "" });
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    adminApi.admin.settingsGet.query().then(async (s) => {
      setForm(s);
      if (s.logo_key) {
        try {
          const { url } = await adminApi.admin.imageUrl.query({ key: s.logo_key });
          setLogoPreview(url);
        } catch {
          /* ignore */
        }
      } else if (s.logo_url) {
        setLogoPreview(s.logo_url);
      }
    });
  }, []);

  if (!form) return <div className="text-sm text-neutral-400">{t.loading}</div>;

  const set = (key: keyof SettingsMap, value: string) => setForm((f) => (f ? { ...f, [key]: value } : f));

  const uploadLogo = async (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    const base64 = await fileToBase64(file);
    const res = await adminApi.admin.uploadImage.mutate({
      name: file.name,
      contentBase64: base64,
      contentType: file.type || undefined,
    });
    const { url } = await adminApi.admin.imageUrl.query({ key: res.key });
    set("logo_key", res.key);
    set("logo_url", "");
    setLogoPreview(url);
    if (fileRef.current) fileRef.current.value = "";
  };

  const save = async () => {
    setSaving(true);
    try {
      await adminApi.admin.settingsUpdate.mutate(form);
      toast.ok();
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка");
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async () => {
    try {
      await adminApi.admin.changePassword.mutate({ current: pw.current, next: pw.next });
      setPw({ current: "", next: "" });
      toast.ok(t.adminPasswordChanged);
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка");
    }
  };

  return (
    <div>
      {toastNode}
      <PageTitle
        actions={
          <button type="button" onClick={save} disabled={saving} className={btnAccent}>
            {t.adminSave}
          </button>
        }
      >
        {t.adminSiteSettings}
      </PageTitle>

      <div className="grid gap-4 xl:grid-cols-2">
        <div className="space-y-4">
          <Card title={t.adminSiteName}>
            <div className="grid gap-4">
              <Field label={`${t.adminSiteName} (RU)`}>
                <input value={form.site_name_ru} onChange={(e) => set("site_name_ru", e.target.value)} className={inputCls} />
              </Field>
              <Field label={`${t.adminSiteName} (KG)`}>
                <input value={form.site_name_kg} onChange={(e) => set("site_name_kg", e.target.value)} className={inputCls} />
              </Field>
              <Field label={t.adminCurrency}>
                <input value={form.currency} onChange={(e) => set("currency", e.target.value)} className={inputCls} />
              </Field>
            </div>
          </Card>

          <Card title={t.adminDesignSettings}>
            <div className="grid gap-4">
              <Field label={t.adminLogo}>
                <div className="flex items-center gap-3">
                  {logoPreview && <Img src={logoPreview} alt="logo" className="h-12 w-auto max-w-36 border border-neutral-200 object-contain p-1" />}
                  <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => uploadLogo(e.target.files)} />
                  <button type="button" onClick={() => fileRef.current?.click()} className={btnOutline}>
                    <Upload size={14} /> {t.adminUploadImage}
                  </button>
                  {(logoPreview || form.logo_url) && (
                    <button
                      type="button"
                      onClick={() => {
                        set("logo_key", "");
                        set("logo_url", "");
                        setLogoPreview("");
                      }}
                      className="flex h-10 w-10 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                      aria-label={t.adminDelete}
                    >
                      <Trash2 size={15} />
                    </button>
                  )}
                </div>
                <input
                  value={form.logo_url}
                  onChange={(e) => {
                    set("logo_url", e.target.value);
                    set("logo_key", "");
                    setLogoPreview(e.target.value);
                  }}
                  placeholder="https://…"
                  className={`${inputCls} mt-2`}
                />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label={t.adminPrimaryColor}>
                  <div className="flex items-center gap-2">
                    <input type="color" value={form.primary_color} onChange={(e) => set("primary_color", e.target.value)} className="h-10 w-14 cursor-pointer border border-neutral-300" />
                    <input value={form.primary_color} onChange={(e) => set("primary_color", e.target.value)} className={inputCls} />
                  </div>
                </Field>
                <Field label={t.adminAccentColor}>
                  <div className="flex items-center gap-2">
                    <input type="color" value={form.accent_color} onChange={(e) => set("accent_color", e.target.value)} className="h-10 w-14 cursor-pointer border border-neutral-300" />
                    <input value={form.accent_color} onChange={(e) => set("accent_color", e.target.value)} className={inputCls} />
                  </div>
                </Field>
              </div>
              <div className="text-xs text-neutral-400">
                Цвета применятся на сайте после сохранения и обновления страницы.
              </div>
            </div>
          </Card>

          <Card title={t.adminContactsSettings}>
            <div className="grid gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={t.adminPhone}>
                  <input value={form.phone} onChange={(e) => set("phone", e.target.value)} className={inputCls} />
                </Field>
                <Field label={t.adminWhatsapp}>
                  <input value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} className={inputCls} />
                </Field>
              </div>
              <Field label={`${t.adminAddress} (RU)`}>
                <input value={form.address_ru} onChange={(e) => set("address_ru", e.target.value)} className={inputCls} />
              </Field>
              <Field label={`${t.adminAddress} (KG)`}>
                <input value={form.address_kg} onChange={(e) => set("address_kg", e.target.value)} className={inputCls} />
              </Field>
              <Field label={t.adminMapUrl} hint="Google Maps → Поделиться → Встраивание карт → скопируйте URL из src">
                <input value={form.map_embed_url} onChange={(e) => set("map_embed_url", e.target.value)} className={inputCls} />
              </Field>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title={t.adminDeliverySettings}>
            <div className="grid gap-4">
              <Field label={`${t.deliveryTitle} (RU)`}>
                <textarea rows={4} value={form.delivery_ru} onChange={(e) => set("delivery_ru", e.target.value)} className={textareaCls} />
              </Field>
              <Field label={`${t.deliveryTitle} (KG)`}>
                <textarea rows={4} value={form.delivery_kg} onChange={(e) => set("delivery_kg", e.target.value)} className={textareaCls} />
              </Field>
            </div>
          </Card>

          <Card title={t.adminSeoSettings}>
            <div className="grid gap-4">
              <Field label="Title (RU)">
                <input value={form.seo_title_ru} onChange={(e) => set("seo_title_ru", e.target.value)} className={inputCls} />
              </Field>
              <Field label="Title (KG)">
                <input value={form.seo_title_kg} onChange={(e) => set("seo_title_kg", e.target.value)} className={inputCls} />
              </Field>
              <Field label="Description (RU)">
                <textarea rows={3} value={form.seo_description_ru} onChange={(e) => set("seo_description_ru", e.target.value)} className={textareaCls} />
              </Field>
              <Field label="Description (KG)">
                <textarea rows={3} value={form.seo_description_kg} onChange={(e) => set("seo_description_kg", e.target.value)} className={textareaCls} />
              </Field>
            </div>
          </Card>

          <Card title={t.adminChangePassword}>
            <div className="grid gap-4">
              <Field label={t.adminCurrentPassword}>
                <input type="password" value={pw.current} onChange={(e) => setPw((p) => ({ ...p, current: e.target.value }))} autoComplete="current-password" className={inputCls} />
              </Field>
              <Field label={t.adminNewPassword}>
                <input type="password" value={pw.next} onChange={(e) => setPw((p) => ({ ...p, next: e.target.value }))} autoComplete="new-password" className={inputCls} />
              </Field>
              <div>
                <button type="button" onClick={changePassword} disabled={!pw.current || pw.next.length < 8} className={btnOutline}>
                  {t.adminChangePassword}
                </button>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div className="mt-4 flex justify-end">
        <button type="button" onClick={save} disabled={saving} className={btnAccent}>
          {t.adminSave}
        </button>
      </div>
    </div>
  );
}
