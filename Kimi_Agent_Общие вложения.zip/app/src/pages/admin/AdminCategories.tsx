import { useCallback, useEffect, useState } from "react";
import { Plus, Pencil, Trash2, ListFilter } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi } from "@/lib/adminApi";
import { trpc } from "@/providers/trpc";
import { PageTitle, Card, Field, Confirm, inputCls, btnAccent, btnOutline, useToast } from "./ui";

type FilterRow = { keySlug: string; labelRu: string; labelKg: string };

export default function AdminCategories() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const { data: categories, refetch } = trpc.catalog.categories.useQuery();
  const [editId, setEditId] = useState<number | null>(null);
  const [nameRu, setNameRu] = useState("");
  const [nameKg, setNameKg] = useState("");
  const [sortOrder, setSortOrder] = useState(0);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [filtersCatId, setFiltersCatId] = useState<number | null>(null);
  const [filters, setFilters] = useState<FilterRow[]>([]);

  const loadFilters = useCallback(async (catId: number) => {
    const defs = await adminApi.admin.categoryFiltersList.query({ categoryId: catId });
    setFilters(defs.map((d) => ({ keySlug: d.keySlug, labelRu: d.labelRu, labelKg: d.labelKg ?? "" })));
  }, []);

  useEffect(() => {
    if (filtersCatId != null) void loadFilters(filtersCatId);
  }, [filtersCatId, loadFilters]);

  const resetForm = () => {
    setEditId(null);
    setNameRu("");
    setNameKg("");
    setSortOrder(0);
  };

  const save = async () => {
    if (!nameRu.trim()) return;
    if (editId) {
      await adminApi.admin.categoryUpdate.mutate({ id: editId, nameRu: nameRu.trim(), nameKg: nameKg.trim() || null, sortOrder });
    } else {
      await adminApi.admin.categoryCreate.mutate({ nameRu: nameRu.trim(), nameKg: nameKg.trim() || null, sortOrder });
    }
    toast.ok();
    resetForm();
    void refetch();
  };

  const doDelete = async () => {
    if (deleteId == null) return;
    try {
      await adminApi.admin.categoryDelete.mutate({ id: deleteId });
      toast.ok(t.adminDeletedOk);
      if (filtersCatId === deleteId) setFiltersCatId(null);
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка");
    }
    setDeleteId(null);
    void refetch();
  };

  const saveFilters = async () => {
    if (filtersCatId == null) return;
    await adminApi.admin.categoryFiltersSet.mutate({
      categoryId: filtersCatId,
      filters: filters.filter((f) => f.keySlug.trim() && f.labelRu.trim()).map((f, i) => ({ ...f, sortOrder: i })),
    });
    toast.ok();
  };

  return (
    <div>
      {toastNode}
      <PageTitle>{t.adminCategories}</PageTitle>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title={editId ? t.adminEdit : t.adminCreate}>
          <div className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={`${t.adminNameRu} *`}>
                <input value={nameRu} onChange={(e) => setNameRu(e.target.value)} className={inputCls} />
              </Field>
              <Field label={t.adminNameKg}>
                <input value={nameKg} onChange={(e) => setNameKg(e.target.value)} className={inputCls} />
              </Field>
            </div>
            <Field label={t.sort}>
              <input type="number" value={sortOrder} onChange={(e) => setSortOrder(Number(e.target.value))} className={inputCls} />
            </Field>
            <div className="flex gap-2">
              <button type="button" onClick={save} className={btnAccent}>
                {editId ? t.adminSave : t.adminCreate}
              </button>
              {editId && (
                <button type="button" onClick={resetForm} className={btnOutline}>{t.adminCancel}</button>
              )}
            </div>
          </div>

          <div className="mt-6 divide-y divide-neutral-100 border-t border-neutral-200">
            {(categories ?? []).map((c) => (
              <div key={c.id} className="flex items-center gap-2 py-2.5">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold text-neutral-900">
                    {c.nameRu} {c.nameKg && <span className="font-normal text-neutral-400">/ {c.nameKg}</span>}
                  </div>
                  <div className="text-xs text-neutral-400">{c.slug} · {c.productCount} {t.pcs}</div>
                </div>
                <button
                  type="button"
                  onClick={() => setFiltersCatId(filtersCatId === c.id ? null : c.id)}
                  title={t.adminFiltersTitle}
                  className={`flex h-9 w-9 cursor-pointer items-center justify-center border ${filtersCatId === c.id ? "border-[var(--accent)] text-[var(--accent)]" : "border-neutral-200 text-neutral-500 hover:border-neutral-900"}`}
                >
                  <ListFilter size={15} />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditId(c.id);
                    setNameRu(c.nameRu);
                    setNameKg(c.nameKg ?? "");
                    setSortOrder(c.sortOrder);
                  }}
                  title={t.adminEdit}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center border border-neutral-200 text-neutral-500 hover:border-neutral-900"
                >
                  <Pencil size={15} />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteId(c.id)}
                  title={t.adminDelete}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
          </div>
        </Card>

        {filtersCatId != null && (
          <Card title={t.adminFiltersTitle}>
            <div className="mb-3 text-xs text-neutral-400">{t.adminFiltersHint}</div>
            <div className="space-y-2">
              {filters.map((f, i) => (
                <div key={i} className="grid grid-cols-[1fr_1fr_1fr_auto] items-center gap-2">
                  <input
                    value={f.keySlug}
                    onChange={(e) => setFilters((fs) => fs.map((x, j) => (j === i ? { ...x, keySlug: e.target.value } : x)))}
                    placeholder="key (напр. volume)"
                    className={inputCls}
                  />
                  <input
                    value={f.labelRu}
                    onChange={(e) => setFilters((fs) => fs.map((x, j) => (j === i ? { ...x, labelRu: e.target.value } : x)))}
                    placeholder={`${t.adminNameRu}`}
                    className={inputCls}
                  />
                  <input
                    value={f.labelKg}
                    onChange={(e) => setFilters((fs) => fs.map((x, j) => (j === i ? { ...x, labelKg: e.target.value } : x)))}
                    placeholder={`${t.adminNameKg}`}
                    className={inputCls}
                  />
                  <button
                    type="button"
                    onClick={() => setFilters((fs) => fs.filter((_, j) => j !== i))}
                    className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                    aria-label={t.adminDelete}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={() => setFilters((fs) => [...fs, { keySlug: "", labelRu: "", labelKg: "" }])}
                className={btnOutline}
              >
                <Plus size={15} /> {t.adminAddFilter}
              </button>
              <button type="button" onClick={saveFilters} className={btnAccent}>{t.adminSave}</button>
            </div>
          </Card>
        )}
      </div>

      <Confirm open={deleteId != null} text={t.adminConfirmDeleteText} onConfirm={doDelete} onCancel={() => setDeleteId(null)} />
    </div>
  );
}
