import { useCallback, useEffect, useRef, useState } from "react";
import { Pencil, Trash2, Upload, Plus } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi, fileToBase64 } from "@/lib/adminApi";
import { PageTitle, Card, Field, Confirm, inputCls, btnAccent, btnOutline, useToast } from "./ui";
import { Img } from "@/components/Img";

type Banner = Awaited<ReturnType<typeof adminApi.admin.bannersList.query>>[number];

const EMPTY = {
  titleRu: "",
  titleKg: "",
  subtitleRu: "",
  subtitleKg: "",
  buttonTextRu: "",
  buttonTextKg: "",
  imageKey: "",
  imageUrl: "",
  linkUrl: "",
  bgColor: "",
  sortOrder: 0,
  isActive: true,
};

export default function AdminBanners() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const [items, setItems] = useState<Banner[]>([]);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [preview, setPreview] = useState("");
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setItems(await adminApi.admin.bannersList.query());
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }));

  const upload = async (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    const base64 = await fileToBase64(file);
    const res = await adminApi.admin.uploadImage.mutate({
      name: file.name,
      contentBase64: base64,
      contentType: file.type || undefined,
    });
    const { url } = await adminApi.admin.imageUrl.query({ key: res.key });
    set({ imageKey: res.key, imageUrl: "" });
    setPreview(url);
    if (fileRef.current) fileRef.current.value = "";
  };

  const save = async () => {
    if (!form.titleRu.trim()) return;
    await adminApi.admin.bannerSave.mutate({
      id: editId,
      titleRu: form.titleRu.trim(),
      titleKg: form.titleKg.trim() || null,
      subtitleRu: form.subtitleRu.trim() || null,
      subtitleKg: form.subtitleKg.trim() || null,
      buttonTextRu: form.buttonTextRu.trim() || null,
      buttonTextKg: form.buttonTextKg.trim() || null,
      imageKey: form.imageKey || null,
      imageUrl: form.imageUrl.trim() || null,
      linkUrl: form.linkUrl.trim() || null,
      bgColor: form.bgColor.trim() || null,
      sortOrder: form.sortOrder,
      isActive: form.isActive,
    });
    toast.ok();
    setFormOpen(false);
    setEditId(null);
    setForm({ ...EMPTY });
    setPreview("");
    void load();
  };

  const doDelete = async () => {
    if (deleteId == null) return;
    await adminApi.admin.bannerDelete.mutate({ id: deleteId });
    setDeleteId(null);
    toast.ok(t.adminDeletedOk);
    void load();
  };

  return (
    <div>
      {toastNode}
      <PageTitle
        actions={
          <button
            type="button"
            onClick={() => {
              setEditId(null);
              setForm({ ...EMPTY });
              setPreview("");
              setFormOpen(true);
            }}
            className={btnAccent}
          >
            <Plus size={16} /> {t.adminCreate}
          </button>
        }
      >
        {t.adminBanners}
      </PageTitle>

      {formOpen && (
        <Card title={editId ? t.adminEdit : t.adminCreate}>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={`${t.adminNameRu} *`}>
              <input value={form.titleRu} onChange={(e) => set({ titleRu: e.target.value })} className={inputCls} />
            </Field>
            <Field label={t.adminNameKg}>
              <input value={form.titleKg} onChange={(e) => set({ titleKg: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Подзаголовок (RU)">
              <input value={form.subtitleRu} onChange={(e) => set({ subtitleRu: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Подзаголовок (KG)">
              <input value={form.subtitleKg} onChange={(e) => set({ subtitleKg: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Текст кнопки (RU)">
              <input value={form.buttonTextRu} onChange={(e) => set({ buttonTextRu: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Текст кнопки (KG)">
              <input value={form.buttonTextKg} onChange={(e) => set({ buttonTextKg: e.target.value })} className={inputCls} />
            </Field>
            <Field label="Ссылка кнопки" hint="Например: /catalog или /catalog/holodilniki">
              <input value={form.linkUrl} onChange={(e) => set({ linkUrl: e.target.value })} className={inputCls} />
            </Field>
            <Field label={t.sort}>
              <input type="number" value={form.sortOrder} onChange={(e) => set({ sortOrder: Number(e.target.value) })} className={inputCls} />
            </Field>
            <Field label="Изображение">
              <div className="flex items-center gap-2">
                {preview && <Img src={preview} alt="" className="h-12 w-24 border border-neutral-200 object-cover" />}
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files)} />
                <button type="button" onClick={() => fileRef.current?.click()} className={btnOutline}>
                  <Upload size={14} />
                </button>
              </div>
              <input
                value={form.imageUrl}
                onChange={(e) => {
                  set({ imageUrl: e.target.value, imageKey: "" });
                  setPreview(e.target.value);
                }}
                placeholder="https://…"
                className={`${inputCls} mt-2`}
              />
            </Field>
            <Field label="Цвет фона (если нет картинки)">
              <input type="color" value={form.bgColor || "#1a1a1a"} onChange={(e) => set({ bgColor: e.target.value })} className="h-10 w-20 cursor-pointer border border-neutral-300" />
            </Field>
          </div>
          <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm text-neutral-700">
            <input type="checkbox" checked={form.isActive} onChange={(e) => set({ isActive: e.target.checked })} className="h-4 w-4 accent-[var(--accent)]" />
            {t.adminShow}
          </label>
          <div className="mt-4 flex gap-2">
            <button type="button" onClick={save} className={btnAccent}>{t.adminSave}</button>
            <button type="button" onClick={() => setFormOpen(false)} className={btnOutline}>{t.adminCancel}</button>
          </div>
        </Card>
      )}

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {items.map((b) => (
          <Card key={b.id}>
            <div className="flex gap-3">
              {b.image && <Img src={b.image} alt="" className="h-20 w-32 shrink-0 border border-neutral-100 object-cover" />}
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-bold text-neutral-900">{b.titleRu}</div>
                <div className="truncate text-xs text-neutral-500">{b.subtitleRu}</div>
                <div className="mt-1 text-xs text-neutral-400">
                  {b.isActive ? "● Активен" : "○ Скрыт"} · {t.sort}: {b.sortOrder}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setEditId(b.id);
                    setForm({
                      titleRu: b.titleRu,
                      titleKg: b.titleKg ?? "",
                      subtitleRu: b.subtitleRu ?? "",
                      subtitleKg: b.subtitleKg ?? "",
                      buttonTextRu: b.buttonTextRu ?? "",
                      buttonTextKg: b.buttonTextKg ?? "",
                      imageKey: b.imageKey ?? "",
                      imageUrl: b.imageUrl ?? "",
                      linkUrl: b.linkUrl ?? "",
                      bgColor: b.bgColor ?? "",
                      sortOrder: b.sortOrder,
                      isActive: b.isActive,
                    });
                    setPreview(b.image ?? "");
                    setFormOpen(true);
                  }}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center border border-neutral-200 text-neutral-500 hover:border-neutral-900"
                >
                  <Pencil size={15} />
                </button>
                <button
                  type="button"
                  onClick={() => setDeleteId(b.id)}
                  className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Confirm open={deleteId != null} text={t.adminConfirmDeleteText} onConfirm={doDelete} onCancel={() => setDeleteId(null)} />
    </div>
  );
}
