import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router";
import { Plus, Pencil, Trash2, EyeOff, Eye, Search } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi } from "@/lib/adminApi";
import { formatPrice } from "@/lib/shop";
import { PageTitle, Card, Confirm, btnAccent, btnOutline, useToast, inputCls } from "./ui";
import { Img } from "@/components/Img";
import { cn } from "@/lib/utils";

type ListResult = Awaited<ReturnType<typeof adminApi.admin.productsList.query>>;

export default function AdminProducts() {
  const { t } = useLang();
  const { toast, toastNode } = useToast();
  const [data, setData] = useState<ListResult | null>(null);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const load = useCallback(async () => {
    const res = await adminApi.admin.productsList.query({ q: q || undefined, page, limit: 15 });
    setData(res);
  }, [q, page]);

  useEffect(() => {
    const timer = setTimeout(() => void load().catch(() => {}), 250);
    return () => clearTimeout(timer);
  }, [load]);

  const toggleHidden = async (id: number, hidden: boolean) => {
    await adminApi.admin.productToggleHidden.mutate({ id, hidden });
    toast.ok();
    void load();
  };

  const doDelete = async () => {
    if (deleteId == null) return;
    await adminApi.admin.productDelete.mutate({ id: deleteId });
    setDeleteId(null);
    toast.ok(t.adminDeletedOk);
    void load();
  };

  return (
    <div>
      {toastNode}
      <PageTitle
        actions={
          <Link to="/admin/products/new" className={btnAccent}>
            <Plus size={16} /> {t.adminAddProduct}
          </Link>
        }
      >
        {t.adminProducts} {data && <span className="text-sm font-normal text-neutral-400">({data.total})</span>}
      </PageTitle>

      <Card>
        <div className="mb-4 flex max-w-md">
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder={t.searchPlaceholder}
            className={inputCls}
          />
          <span className="flex h-10 w-11 shrink-0 items-center justify-center border border-l-0 border-neutral-300 text-neutral-400">
            <Search size={16} />
          </span>
        </div>

        {!data ? (
          <div className="py-10 text-center text-sm text-neutral-400">{t.loading}</div>
        ) : data.items.length === 0 ? (
          <div className="py-10 text-center text-sm text-neutral-400">{t.nothingFound}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b border-neutral-200 text-left text-xs uppercase tracking-wider text-neutral-500">
                  <th className="pb-2 pr-3"></th>
                  <th className="pb-2 pr-3">{t.adminName}</th>
                  <th className="pb-2 pr-3">{t.category}</th>
                  <th className="pb-2 pr-3">{t.brand}</th>
                  <th className="pb-2 pr-3">{t.price}</th>
                  <th className="pb-2 pr-3">{t.adminInStock}</th>
                  <th className="pb-2 text-right">{t.adminActions}</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((p) => (
                  <tr key={p.id} className={cn("border-b border-neutral-100", p.isHidden && "opacity-50")}>
                    <td className="py-2 pr-3">
                      <Img src={p.image} alt="" className="h-11 w-11 border border-neutral-100 object-contain" />
                    </td>
                    <td className="py-2 pr-3">
                      <Link to={`/admin/products/${p.id}`} className="font-semibold text-neutral-900 hover:text-[var(--accent)]">
                        {p.nameRu}
                      </Link>
                      <div className="text-xs text-neutral-400">
                        {p.isPopular && "★ "}{p.isNew && "NEW "}{p.isHidden && `(${t.adminHidden})`}
                      </div>
                    </td>
                    <td className="py-2 pr-3 text-neutral-600">{p.categoryName}</td>
                    <td className="py-2 pr-3 text-neutral-600">{p.brandName}</td>
                    <td className="py-2 pr-3 font-semibold">{formatPrice(p.price)}</td>
                    <td className="py-2 pr-3">
                      <span className={p.inStock ? "text-emerald-600" : "text-neutral-400"}>
                        {p.inStock ? t.yes : t.no}
                      </span>
                    </td>
                    <td className="py-2">
                      <div className="flex justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => toggleHidden(p.id, !p.isHidden)}
                          title={p.isHidden ? t.adminShow : t.adminHide}
                          className="flex h-9 w-9 cursor-pointer items-center justify-center border border-neutral-200 text-neutral-500 hover:border-neutral-900"
                        >
                          {p.isHidden ? <Eye size={15} /> : <EyeOff size={15} />}
                        </button>
                        <Link
                          to={`/admin/products/${p.id}`}
                          title={t.adminEdit}
                          className="flex h-9 w-9 items-center justify-center border border-neutral-200 text-neutral-500 hover:border-neutral-900"
                        >
                          <Pencil size={15} />
                        </Link>
                        <button
                          type="button"
                          onClick={() => setDeleteId(p.id)}
                          title={t.adminDelete}
                          className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {data && data.pages > 1 && (
          <div className="mt-4 flex items-center justify-center gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
              className={btnOutline}
            >
              ←
            </button>
            <span className="text-sm text-neutral-600">
              {page} / {data.pages}
            </span>
            <button
              type="button"
              disabled={page >= data.pages}
              onClick={() => setPage((p) => p + 1)}
              className={btnOutline}
            >
              →
            </button>
          </div>
        )}
      </Card>

      <Confirm
        open={deleteId != null}
        text={t.adminConfirmDeleteText}
        onConfirm={doDelete}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
