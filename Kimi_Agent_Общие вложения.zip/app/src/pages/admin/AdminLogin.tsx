import { useState, type FormEvent } from "react";
import { useNavigate, Link } from "react-router";
import { LockKeyhole } from "lucide-react";
import { useLang } from "@/i18n";
import { adminApi, setAdminToken } from "@/lib/adminApi";

export default function AdminLogin() {
  const { t } = useLang();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await adminApi.admin.login.mutate({ username: username.trim(), password });
      setAdminToken(res.token);
      navigate("/admin", { replace: true });
    } catch {
      setError(t.adminWrongCredentials);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-dvh items-center justify-center bg-neutral-100 px-4">
      <form onSubmit={submit} className="w-full max-w-sm border border-neutral-200 bg-white p-8">
        <div className="mb-6 flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center bg-[var(--brand)] text-white">
            <LockKeyhole size={20} />
          </span>
          <h1 className="text-lg font-extrabold text-neutral-900">{t.adminLogin}</h1>
        </div>
        {error && (
          <div className="mb-4 border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>
        )}
        <label className="block text-xs font-semibold text-neutral-500" htmlFor="login">
          {t.adminUsername}
        </label>
        <input
          id="login"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
          autoComplete="username"
          className="mt-1 h-11 w-full border border-neutral-300 px-3 text-sm outline-none focus:border-neutral-900"
        />
        <label className="mt-4 block text-xs font-semibold text-neutral-500" htmlFor="password">
          {t.adminPassword}
        </label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          autoComplete="current-password"
          className="mt-1 h-11 w-full border border-neutral-300 px-3 text-sm outline-none focus:border-neutral-900"
        />
        <button
          type="submit"
          disabled={loading}
          className="mt-6 h-11 w-full cursor-pointer bg-[var(--brand)] text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {t.adminSignIn}
        </button>
        <Link to="/" className="mt-4 block text-center text-xs text-neutral-500 hover:text-neutral-900">
          ← {t.adminBackToSite}
        </Link>
      </form>
    </div>
  );
}
