import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { ArrowLeft, ArrowUp, ArrowDown, Trash2, Upload, Link2, Plus } from "lucide-react";
import { useLang } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { adminApi, fileToBase64 } from "@/lib/adminApi";
import {
  PageTitle,
  Card,
  Field,
  inputCls,
  textareaCls,
  btnAccent,
  btnOutline,
  useToast,
} from "./ui";
import { Img } from "@/components/Img";

type SpecRow = {
  keySlug: string;
  keyRu: string;
  keyKg: string;
  valueRu: string;
  valueKg: string;
};

type ImageRow = {
  storageKey: string | null;
  externalUrl: string | null;
  url: string;
};

export default function AdminProductEdit() {
  const { id } = useParams<{ id: string }>();
  const isNew = !id;
  const { t } = useLang();
  const navigate = useNavigate();
  const { toast, toastNode } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: categories } = trpc.catalog.categories.useQuery(undefined, { staleTime: 60_000 });
  const { data: brands } = trpc.catalog.brands.useQuery(undefined, { staleTime: 60_000 });

  const [form, setForm] = useState({
    nameRu: "",
    nameKg: "",
    slug: "",
    descriptionRu: "",
    descriptionKg: "",
    categoryId: 0,
    brandId: 0,
    price: 0,
    oldPrice: "",
    warranty: "",
    inStock: true,
    isPopular: false,
    isNew: false,
    isHidden: false,
  });
  const [specs, setSpecs] = useState<SpecRow[]>([]);
  const [images, setImages] = useState<ImageRow[]>([]);
  const [urlInput, setUrlInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [loaded, setLoaded] = useState(isNew);

  const { data: filterDefs } = trpc.catalog.categoryFilters.useQuery(
    { categorySlug: categories?.find((c) => c.id === form.categoryId)?.slug ?? "" },
    { enabled: Boolean(form.categoryId && categories) },
  );

  useEffect(() => {
    if (isNew) return;
    adminApi.admin.productGet
      .query({ id: Number(id) })
      .then((p) => {
        setForm({
          nameRu: p.nameRu,
          nameKg: p.nameKg ?? "",
          slug: p.slug,
          descriptionRu: p.descriptionRu ?? "",
          descriptionKg: p.descriptionKg ?? "",
          categoryId: p.categoryId,
          brandId: p.brandId,
          price: p.price,
          oldPrice: p.oldPrice ? String(p.oldPrice) : "",
          warranty: p.warranty ?? "",
          inStock: p.inStock,
          isPopular: p.isPopular,
          isNew: p.isNew,
          isHidden: p.isHidden,
        });
        setSpecs(
          p.specs.map((s) => ({
            keySlug: s.keySlug ?? "",
            keyRu: s.keyRu,
            keyKg: s.keyKg ?? "",
            valueRu: s.valueRu,
            valueKg: s.valueKg ?? "",
          })),
        );
        setImages(
          p.rawImages.map((img) => ({
            storageKey: img.storageKey,
            externalUrl: img.externalUrl,
            url: img.url,
          })),
        );
        setLoaded(true);
      })
      .catch(() => navigate("/admin/products"));
  }, [id, isNew, navigate]);

  useEffect(() => {
    if (isNew && categories?.length && !form.categoryId) {
      setForm((f) => ({ ...f, categoryId: categories[0].id }));
    }
    if (isNew && brands?.length && !form.brandId) {
      setForm((f) => ({ ...f, brandId: brands[0].id }));
    }
  }, [isNew, categories, brands, form.categoryId, form.brandId]);

  const filterOptions = useMemo(
    () => (filterDefs ?? []).map((f) => ({ keySlug: f.keySlug, label: `${f.labelRu} / ${f.labelKg ?? ""}` })),
    [filterDefs],
  );

  const set = (patch: Partial<typeof form>) => setForm((f) => ({ ...f, ...patch }));

  const moveImage = (i: number, dir: number) => {
    setImages((imgs) => {
      const next = [...imgs];
      const j = i + dir;
      if (j < 0 || j >= next.length) return imgs;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  };

  const uploadFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const base64 = await fileToBase64(file);
        const res = await adminApi.admin.uploadImage.mutate({
          name: file.name,
          contentBase64: base64,
          contentType: file.type || undefined,
        });
        const { url } = await adminApi.admin.imageUrl.query({ key: res.key });
        setImages((imgs) => [...imgs, { storageKey: res.key, externalUrl: null, url }]);
      }
      toast.ok();
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка загрузки");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const addByUrl = () => {
    const url = urlInput.trim();
    if (!/^https?:\/\//.test(url)) {
      toast.err("Некорректная ссылка");
      return;
    }
    setImages((imgs) => [...imgs, { storageKey: null, externalUrl: url, url }]);
    setUrlInput("");
  };

  const save = async () => {
    if (!form.nameRu.trim() || !form.categoryId || !form.brandId) {
      toast.err("Заполните название, категорию и бренд");
      return;
    }
    setSaving(true);
    const data = {
      nameRu: form.nameRu.trim(),
      nameKg: form.nameKg.trim() || null,
      slug: form.slug.trim() || null,
      descriptionRu: form.descriptionRu || null,
      descriptionKg: form.descriptionKg || null,
      categoryId: form.categoryId,
      brandId: form.brandId,
      price: Math.round(Number(form.price) || 0),
      oldPrice: form.oldPrice ? Math.round(Number(form.oldPrice)) : null,
      warranty: form.warranty.trim() || null,
      inStock: form.inStock,
      isPopular: form.isPopular,
      isNew: form.isNew,
      isHidden: form.isHidden,
      specs: specs
        .filter((s) => s.keyRu.trim() && s.valueRu.trim())
        .map((s, i) => ({
          keySlug: s.keySlug || null,
          keyRu: s.keyRu.trim(),
          keyKg: s.keyKg.trim() || null,
          valueRu: s.valueRu.trim(),
          valueKg: s.valueKg.trim() || null,
          sortOrder: i,
        })),
      images: images.map((img, i) => ({
        storageKey: img.storageKey,
        externalUrl: img.externalUrl,
        sortOrder: i,
      })),
    };
    try {
      if (isNew) {
        const res = await adminApi.admin.productCreate.mutate(data);
        toast.ok();
        navigate(`/admin/products/${res.id}`, { replace: true });
      } else {
        await adminApi.admin.productUpdate.mutate({ id: Number(id), data });
        toast.ok();
      }
    } catch (e) {
      toast.err(e instanceof Error ? e.message : "Ошибка сохранения");
    } finally {
      setSaving(false);
    }
  };

  if (!loaded) return <div className="text-sm text-neutral-400">{t.loading}</div>;

  return (
    <div>
      {toastNode}
      <PageTitle
        actions={
          <div className="flex gap-2">
            <Link to="/admin/products" className={btnOutline}>
              <ArrowLeft size={15} /> {t.adminProducts}
            </Link>
            <button type="button" onClick={save} disabled={saving} className={btnAccent}>
              {t.adminSave}
            </button>
          </div>
        }
      >
        {isNew ? t.adminAddProduct : t.adminEdit}
      </PageTitle>

      <div className="grid gap-4 xl:grid-cols-2">
        {/* Основное */}
        <Card title={t.adminProducts}>
          <div className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={`${t.adminNameRu} *`}>
                <input value={form.nameRu} onChange={(e) => set({ nameRu: e.target.value })} className={inputCls} />
              </Field>
              <Field label={t.adminNameKg}>
                <input value={form.nameKg} onChange={(e) => set({ nameKg: e.target.value })} className={inputCls} />
              </Field>
            </div>
            <Field label="Slug (ЧПУ)" hint="Оставьте пустым — сгенерируется автоматически">
              <input value={form.slug} onChange={(e) => set({ slug: e.target.value })} className={inputCls} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={`${t.category} *`}>
                <select
                  value={form.categoryId}
                  onChange={(e) => set({ categoryId: Number(e.target.value) })}
                  className={inputCls}
                >
                  {(categories ?? []).map((c) => (
                    <option key={c.id} value={c.id}>{c.nameRu}</option>
                  ))}
                </select>
              </Field>
              <Field label={`${t.brand} *`}>
                <select
                  value={form.brandId}
                  onChange={(e) => set({ brandId: Number(e.target.value) })}
                  className={inputCls}
                >
                  {(brands ?? []).map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label={`${t.price} *`}>
                <input
                  type="number"
                  min={0}
                  value={form.price}
                  onChange={(e) => set({ price: Number(e.target.value) })}
                  className={inputCls}
                />
              </Field>
              <Field label={t.adminOldPrice}>
                <input
                  type="number"
                  min={0}
                  value={form.oldPrice}
                  onChange={(e) => set({ oldPrice: e.target.value })}
                  className={inputCls}
                />
              </Field>
              <Field label={t.warranty}>
                <input value={form.warranty} onChange={(e) => set({ warranty: e.target.value })} className={inputCls} />
              </Field>
            </div>
            <div className="flex flex-wrap gap-x-6 gap-y-2">
              {(
                [
                  ["inStock", t.adminInStock],
                  ["isPopular", t.adminPopular],
                  ["isNew", t.adminNewFlag],
                  ["isHidden", t.adminHidden],
                ] as const
              ).map(([key, label]) => (
                <label key={key} className="flex cursor-pointer items-center gap-2 text-sm text-neutral-700">
                  <input
                    type="checkbox"
                    checked={form[key]}
                    onChange={(e) => set({ [key]: e.target.checked } as Partial<typeof form>)}
                    className="h-4 w-4 accent-[var(--accent)]"
                  />
                  {label}
                </label>
              ))}
            </div>
            <Field label={t.adminDescRu}>
              <textarea
                rows={5}
                value={form.descriptionRu}
                onChange={(e) => set({ descriptionRu: e.target.value })}
                className={textareaCls}
              />
            </Field>
            <Field label={t.adminDescKg}>
              <textarea
                rows={5}
                value={form.descriptionKg}
                onChange={(e) => set({ descriptionKg: e.target.value })}
                className={textareaCls}
              />
            </Field>
          </div>
        </Card>

        {/* Фото + характеристики */}
        <div className="space-y-4">
          <Card title={t.adminImages}>
            <div className="mb-3 text-xs text-neutral-400">{t.adminMainPhoto}</div>
            <div className="mb-3 flex flex-wrap gap-2">
              {images.map((img, i) => (
                <div key={i} className="relative border border-neutral-200">
                  <Img src={img.url} alt="" className="h-24 w-24 object-contain p-1" />
                  {i === 0 && (
                    <span className="absolute left-0 top-0 bg-[var(--accent)] px-1 text-[10px] font-bold text-white">1</span>
                  )}
                  <div className="flex justify-between border-t border-neutral-100">
                    <button type="button" onClick={() => moveImage(i, -1)} className="flex h-7 w-7 cursor-pointer items-center justify-center text-neutral-500 hover:text-neutral-900" aria-label="up">
                      <ArrowUp size={13} />
                    </button>
                    <button type="button" onClick={() => moveImage(i, 1)} className="flex h-7 w-7 cursor-pointer items-center justify-center text-neutral-500 hover:text-neutral-900" aria-label="down">
                      <ArrowDown size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setImages((imgs) => imgs.filter((_, j) => j !== i))}
                      className="flex h-7 w-7 cursor-pointer items-center justify-center text-red-500 hover:bg-red-50"
                      aria-label={t.adminDelete}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => uploadFiles(e.target.files)} />
              <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading} className={btnOutline}>
                <Upload size={15} /> {uploading ? t.loading : t.adminUploadImage}
              </button>
              <div className="flex min-w-0 flex-1">
                <input
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://…"
                  className={inputCls}
                />
                <button type="button" onClick={addByUrl} className={btnOutline} style={{ borderLeft: 0 }}>
                  <Link2 size={15} />
                </button>
              </div>
            </div>
          </Card>

          <Card
            title={t.adminSpecs}
          >
            <div className="space-y-2">
              {specs.map((s, i) => (
                <div key={i} className="grid grid-cols-[1fr_1fr_auto] items-start gap-2 border border-neutral-200 p-2">
                  <div className="space-y-1.5">
                    <input
                      value={s.keyRu}
                      onChange={(e) => setSpecs((ss) => ss.map((x, j) => (j === i ? { ...x, keyRu: e.target.value } : x)))}
                      placeholder={`${t.adminSpecKey} (RU)`}
                      className={inputCls}
                    />
                    <input
                      value={s.keyKg}
                      onChange={(e) => setSpecs((ss) => ss.map((x, j) => (j === i ? { ...x, keyKg: e.target.value } : x)))}
                      placeholder={`${t.adminSpecKey} (KG)`}
                      className={inputCls}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <input
                      value={s.valueRu}
                      onChange={(e) => setSpecs((ss) => ss.map((x, j) => (j === i ? { ...x, valueRu: e.target.value } : x)))}
                      placeholder={`${t.adminSpecValue} (RU)`}
                      className={inputCls}
                    />
                    <input
                      value={s.valueKg}
                      onChange={(e) => setSpecs((ss) => ss.map((x, j) => (j === i ? { ...x, valueKg: e.target.value } : x)))}
                      placeholder={`${t.adminSpecValue} (KG)`}
                      className={inputCls}
                    />
                    <select
                      value={s.keySlug}
                      onChange={(e) => setSpecs((ss) => ss.map((x, j) => (j === i ? { ...x, keySlug: e.target.value } : x)))}
                      className={inputCls}
                    >
                      <option value="">{t.adminSpecFilterKey}: —</option>
                      {filterOptions.map((f) => (
                        <option key={f.keySlug} value={f.keySlug}>{f.label}</option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSpecs((ss) => ss.filter((_, j) => j !== i))}
                    className="flex h-9 w-9 cursor-pointer items-center justify-center border border-red-200 text-red-500 hover:bg-red-50"
                    aria-label={t.adminDelete}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setSpecs((ss) => [...ss, { keySlug: "", keyRu: "", keyKg: "", valueRu: "", valueKg: "" }])}
              className={`${btnOutline} mt-3`}
            >
              <Plus size={15} /> {t.adminAddSpec}
            </button>
          </Card>
        </div>
      </div>

      <div className="mt-4 flex justify-end gap-2">
        <Link to="/admin/products" className={btnOutline}>{t.adminCancel}</Link>
        <button type="button" onClick={save} disabled={saving} className={btnAccent}>
          {t.adminSave}
        </button>
      </div>
    </div>
  );
}
