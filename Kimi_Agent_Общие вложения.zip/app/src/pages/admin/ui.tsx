// Общие элементы админ-панели
import { useEffect, useState, type ReactNode } from "react";
import { useLang } from "@/i18n";

export function PageTitle({ children, actions }: { children: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
      <h1 className="text-xl font-extrabold tracking-tight text-neutral-900">{children}</h1>
      {actions}
    </div>
  );
}

export function Card({ children, title }: { children: ReactNode; title?: string }) {
  return (
    <div className="border border-neutral-200 bg-white p-5">
      {title && <div className="mb-4 text-sm font-bold text-neutral-900">{title}</div>}
      {children}
    </div>
  );
}

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-semibold text-neutral-500">{label}</label>
      {children}
      {hint && <div className="mt-1 text-xs text-neutral-400">{hint}</div>}
    </div>
  );
}

export const inputCls =
  "h-10 w-full border border-neutral-300 bg-white px-3 text-sm outline-none focus:border-neutral-900";
export const textareaCls =
  "w-full border border-neutral-300 bg-white p-3 text-sm outline-none focus:border-neutral-900";
export const btnPrimary =
  "inline-flex h-10 cursor-pointer items-center justify-center gap-2 bg-[var(--brand)] px-4 text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50";
export const btnAccent =
  "inline-flex h-10 cursor-pointer items-center justify-center gap-2 bg-[var(--accent)] px-4 text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50";
export const btnOutline =
  "inline-flex h-10 cursor-pointer items-center justify-center gap-2 border border-neutral-300 bg-white px-4 text-sm font-semibold text-neutral-700 transition-colors hover:border-neutral-900";
export const btnDanger =
  "inline-flex h-10 cursor-pointer items-center justify-center gap-2 border border-red-200 bg-white px-4 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50";

export function useToast() {
  const { t } = useLang();
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);
  useEffect(() => {
    if (!msg) return;
    const timer = setTimeout(() => setMsg(null), 3000);
    return () => clearTimeout(timer);
  }, [msg]);
  const toast = {
    ok: (text?: string) => setMsg({ text: text ?? t.adminSavedOk, ok: true }),
    err: (text: string) => setMsg({ text, ok: false }),
  };
  const node = msg ? (
    <div
      className={`fixed bottom-5 left-1/2 z-50 -translate-x-1/2 px-4 py-2.5 text-sm font-semibold text-white shadow-lg ${
        msg.ok ? "bg-emerald-600" : "bg-red-600"
      }`}
      role="status"
    >
      {msg.text}
    </div>
  ) : null;
  return { toast, toastNode: node };
}

export function Confirm({
  open,
  text,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  text: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const { t } = useLang();
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onCancel} />
      <div className="relative w-full max-w-sm border border-neutral-200 bg-white p-6">
        <div className="text-base font-bold text-neutral-900">{t.adminConfirmDelete}</div>
        <p className="mt-2 text-sm text-neutral-600">{text}</p>
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" onClick={onCancel} className={btnOutline}>
            {t.adminCancel}
          </button>
          <button type="button" onClick={onConfirm} className={btnDanger}>
            {t.adminDelete}
          </button>
        </div>
      </div>
    </div>
  );
}
