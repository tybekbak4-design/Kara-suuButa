import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import {
  ChevronRight,
  Heart,
  GitCompareArrows,
  Phone,
  Share2,
  ShieldCheck,
  Check,
} from "lucide-react";
import { useLang, loc } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { pushHistory, toggleId, useStoreIds } from "@/lib/localStore";
import {
  formatPrice,
  phoneHref,
  productMessage,
  productUrl,
  trackEvent,
  useSettings,
  whatsappHref,
} from "@/lib/shop";
import type { CardProduct, FullProduct } from "@/types";
import { ProductCard } from "@/components/ProductCard";
import { RatingStars } from "@/components/RatingStars";
import { WhatsAppIcon } from "@/components/WhatsAppIcon";
import { Img } from "@/components/Img";
import { cn } from "@/lib/utils";

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>();
  const { lang, t } = useLang();
  const { data: settings } = useSettings();
  const { data: product, error } = trpc.catalog.productBySlug.useQuery(
    { slug: slug ?? "" },
    { enabled: Boolean(slug) },
  );
  const favorites = useStoreIds("favorites");
  const compare = useStoreIds("compare");
  const [activeImage, setActiveImage] = useState(0);
  const [shared, setShared] = useState(false);

  const p = product as FullProduct | undefined;

  useEffect(() => {
    setActiveImage(0);
  }, [slug]);

  useEffect(() => {
    if (p) {
      pushHistory(p.id);
      trackEvent("product_view", p.id);
      document.title = `${loc(lang, p.nameRu, p.nameKg)} — ${settings ? loc(lang, settings.site_name_ru, settings.site_name_kg) : ""}`;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p?.id]);

  const { data: similar } = trpc.catalog.similarProducts.useQuery(
    { productId: p?.id ?? 0, limit: 8 },
    { enabled: Boolean(p?.id) },
  );
  const { data: reviews, refetch: refetchReviews } = trpc.catalog.productReviews.useQuery(
    { productId: p?.id ?? 0 },
    { enabled: Boolean(p?.id) },
  );

  if (error) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center">
        <div className="text-xl font-bold text-neutral-900">{t.productNotFound}</div>
        <Link to="/catalog" className="mt-4 inline-flex h-11 items-center bg-[var(--brand)] px-6 text-sm font-bold text-white">
          {t.goToCatalog}
        </Link>
      </div>
    );
  }
  if (!p) {
    return <div className="py-20 text-center text-sm text-neutral-400">{t.loading}</div>;
  }

  const name = loc(lang, p.nameRu, p.nameKg);
  const description = loc(lang, p.descriptionRu, p.descriptionKg);
  const currency = settings?.currency ?? t.som;
  const isFav = favorites.includes(p.id);
  const isCmp = compare.includes(p.id);

  const share = async () => {
    const url = productUrl(p.slug);
    const nav = navigator as Navigator & { share?: (d: { title: string; text: string; url: string }) => Promise<void> };
    if (nav.share) {
      try {
        await nav.share({ title: name, text: `${name} — ${formatPrice(p.price, currency)}`, url });
        return;
      } catch {
        return; // пользователь отменил
      }
    }
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const input = document.createElement("input");
      input.value = url;
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
    setShared(true);
    setTimeout(() => setShared(false), 2000);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {/* Хлебные крошки */}
      <nav className="mb-5 flex flex-wrap items-center gap-1 text-xs text-neutral-500" aria-label="breadcrumbs">
        <Link to="/" className="hover:text-neutral-900">{t.home}</Link>
        <ChevronRight size={12} />
        <Link to="/catalog" className="hover:text-neutral-900">{t.catalog}</Link>
        {p.category && (
          <>
            <ChevronRight size={12} />
            <Link to={`/catalog/${p.category.slug}`} className="hover:text-neutral-900">
              {loc(lang, p.category.nameRu, p.category.nameKg)}
            </Link>
          </>
        )}
        <ChevronRight size={12} />
        <span className="font-semibold text-neutral-900">{name}</span>
      </nav>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Галерея */}
        <div>
          <div className="relative aspect-square border border-neutral-200 bg-white">
            {p.discount > 0 && (
              <span className="absolute left-3 top-3 z-10 bg-[var(--accent)] px-2.5 py-1 text-sm font-bold text-white">
                −{p.discount}%
              </span>
            )}
            <Img
              src={p.images[activeImage]?.url}
              alt={name}
              eager
              className="h-full w-full object-contain p-6"
            />
          </div>
          {p.images.length > 1 && (
            <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
              {p.images.map((img, i) => (
                <button
                  key={img.id}
                  type="button"
                  onClick={() => setActiveImage(i)}
                  aria-label={`Фото ${i + 1}`}
                  className={cn(
                    "h-16 w-16 shrink-0 cursor-pointer border bg-white transition-colors",
                    i === activeImage ? "border-[var(--accent)]" : "border-neutral-200 hover:border-neutral-400",
                  )}
                >
                  <Img src={img.url} alt="" className="h-full w-full object-contain p-1" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Информация */}
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
            {p.brand && (
              <Link to={`/catalog?brand=${p.brand.slug}`} className="hover:text-[var(--accent)]">
                {p.brand.name}
              </Link>
            )}
          </div>
          <h1 className="mt-1 text-2xl font-extrabold leading-tight tracking-tight text-neutral-900">
            {name}
          </h1>

          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
            <span className={p.inStock ? "font-semibold text-emerald-600" : "font-semibold text-neutral-400"}>
              {p.inStock ? `✓ ${t.inStock}` : t.outOfStock}
            </span>
            {p.warranty && (
              <span className="flex items-center gap-1 text-neutral-500">
                <ShieldCheck size={15} /> {t.warranty}: {p.warranty}
              </span>
            )}
          </div>

          <div className="mt-5 border-y border-neutral-200 py-5">
            <div className="flex flex-wrap items-baseline gap-3">
              <span className="text-3xl font-extrabold text-neutral-900">
                {formatPrice(p.price, currency)}
              </span>
              {p.oldPrice && p.oldPrice > p.price && (
                <span className="text-lg text-neutral-400 line-through">
                  {formatPrice(p.oldPrice, currency)}
                </span>
              )}
              {p.discount > 0 && (
                <span className="bg-[var(--accent)]/10 px-2 py-0.5 text-sm font-bold text-[var(--accent)]">
                  {t.discount} −{p.discount}%
                </span>
              )}
            </div>
          </div>

          {/* Кнопки */}
          <div className="mt-5 grid grid-cols-2 gap-2">
            {settings && (
              <a
                href={whatsappHref(settings.whatsapp, productMessage(name, formatPrice(p.price, currency), p.slug, lang))}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackEvent("whatsapp_click", p.id)}
                className="flex h-12 items-center justify-center gap-2 bg-[#25D366] text-sm font-bold text-white transition-opacity hover:opacity-90"
              >
                <WhatsAppIcon size={18} /> WhatsApp
              </a>
            )}
            {settings && (
              <a
                href={phoneHref(settings.phone)}
                onClick={() => trackEvent("phone_click", p.id)}
                className="flex h-12 items-center justify-center gap-2 bg-[var(--brand)] text-sm font-bold text-white transition-opacity hover:opacity-90"
              >
                <Phone size={17} /> {t.call}
              </a>
            )}
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => toggleId("favorites", p.id)}
              className={cn(
                "flex h-11 cursor-pointer items-center justify-center gap-1.5 border text-sm font-semibold transition-colors",
                isFav
                  ? "border-[var(--accent)] bg-[var(--accent)]/5 text-[var(--accent)]"
                  : "border-neutral-300 text-neutral-700 hover:border-neutral-900",
              )}
            >
              <Heart size={16} className={isFav ? "fill-[var(--accent)]" : ""} />
              <span className="hidden sm:inline">{t.addToFavorites}</span>
            </button>
            <button
              type="button"
              onClick={() => toggleId("compare", p.id)}
              className={cn(
                "flex h-11 cursor-pointer items-center justify-center gap-1.5 border text-sm font-semibold transition-colors",
                isCmp
                  ? "border-[var(--brand)] bg-neutral-100 text-neutral-900"
                  : "border-neutral-300 text-neutral-700 hover:border-neutral-900",
              )}
            >
              <GitCompareArrows size={16} />
              <span className="hidden sm:inline">{t.addToCompare}</span>
            </button>
            <button
              type="button"
              onClick={share}
              className="flex h-11 cursor-pointer items-center justify-center gap-1.5 border border-neutral-300 text-sm font-semibold text-neutral-700 transition-colors hover:border-neutral-900"
            >
              {shared ? <Check size={16} className="text-emerald-600" /> : <Share2 size={16} />}
              <span className="hidden sm:inline">{shared ? t.linkCopied : t.share}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Описание и характеристики */}
      <div className="mt-10 grid gap-6 lg:grid-cols-2">
        {description && (
          <section>
            <h2 className="mb-3 border-b border-neutral-200 pb-2 text-lg font-extrabold text-neutral-900">
              {t.description}
            </h2>
            <p className="whitespace-pre-line text-sm leading-7 text-neutral-700">{description}</p>
          </section>
        )}
        {p.specs.length > 0 && (
          <section>
            <h2 className="mb-3 border-b border-neutral-200 pb-2 text-lg font-extrabold text-neutral-900">
              {t.specs}
            </h2>
            <dl className="divide-y divide-neutral-100 border border-neutral-200 bg-white">
              {p.specs.map((s) => (
                <div key={s.id} className="grid grid-cols-2 gap-2 px-4 py-2.5 text-sm">
                  <dt className="text-neutral-500">{loc(lang, s.keyRu, s.keyKg)}</dt>
                  <dd className="font-medium text-neutral-900">{loc(lang, s.valueRu, s.valueKg)}</dd>
                </div>
              ))}
            </dl>
          </section>
        )}
      </div>

      {/* Отзывы */}
      <section className="mt-10">
        <h2 className="mb-3 border-b border-neutral-200 pb-2 text-lg font-extrabold text-neutral-900">
          {t.reviewsTitle} {reviews && reviews.length > 0 && <span className="text-sm font-normal text-neutral-400">({reviews.length})</span>}
        </h2>
        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-3">
            {reviews && reviews.length > 0 ? (
              reviews.map((r) => (
                <div key={r.id} className="border border-neutral-200 bg-white p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold text-neutral-900">{r.authorName}</span>
                    <div className="flex items-center gap-2">
                      <RatingStars value={r.rating} size={14} />
                      <span className="text-xs text-neutral-400">
                        {new Date(r.createdAt).toLocaleDateString(lang === "kg" ? "ky-KG" : "ru-RU")}
                      </span>
                    </div>
                  </div>
                  <p className="mt-2 text-sm leading-6 text-neutral-700">{r.text}</p>
                </div>
              ))
            ) : (
              <div className="border border-dashed border-neutral-300 bg-white p-6 text-center text-sm text-neutral-500">
                {t.noReviews}
              </div>
            )}
          </div>
          <ReviewForm productId={p.id} onSent={() => refetchReviews()} />
        </div>
      </section>

      {/* Похожие */}
      {similar && similar.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 border-b border-neutral-200 pb-2 text-lg font-extrabold text-neutral-900">
            {t.similarProducts}
          </h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
            {(similar as CardProduct[]).map((sp) => (
              <ProductCard key={sp.id} product={sp} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function ReviewForm({ productId, onSent }: { productId: number; onSent: () => void }) {
  const { t } = useLang();
  const mutation = trpc.catalog.createReview.useMutation();
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [rating, setRating] = useState(5);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (name.trim().length < 2 || text.trim().length < 3) return;
    try {
      await mutation.mutateAsync({ productId, authorName: name.trim(), rating, text: text.trim() });
      setSent(true);
      setName("");
      setText("");
      setRating(5);
      onSent();
    } catch {
      setError("Ошибка отправки");
    }
  };

  return (
    <form onSubmit={submit} className="h-fit border border-neutral-200 bg-white p-5">
      <div className="text-base font-bold text-neutral-900">{t.leaveReview}</div>
      {sent && (
        <div className="mt-3 border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">
          {t.reviewSent}
        </div>
      )}
      <label className="mt-4 block text-xs font-semibold text-neutral-500">{t.rating}</label>
      <div className="mt-1">
        <RatingStars value={rating} onChange={setRating} size={22} />
      </div>
      <label className="mt-3 block text-xs font-semibold text-neutral-500" htmlFor="rv-name">{t.yourName}</label>
      <input
        id="rv-name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        minLength={2}
        maxLength={100}
        className="mt-1 h-10 w-full border border-neutral-300 px-3 text-sm outline-none focus:border-neutral-900"
      />
      <label className="mt-3 block text-xs font-semibold text-neutral-500" htmlFor="rv-text">{t.yourReview}</label>
      <textarea
        id="rv-text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        required
        minLength={3}
        maxLength={3000}
        rows={4}
        className="mt-1 w-full border border-neutral-300 p-3 text-sm outline-none focus:border-neutral-900"
      />
      {error && <div className="mt-2 text-sm text-red-600">{error}</div>}
      <button
        type="submit"
        disabled={mutation.isPending}
        className="mt-4 h-11 w-full cursor-pointer bg-[var(--accent)] text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
      >
        {t.sendReview}
      </button>
    </form>
  );
}
