import { Link } from "react-router";
import {
  Refrigerator,
  WashingMachine,
  Tv,
  Wind,
  AirVent,
  Snowflake,
  Microwave,
  Coffee,
  Package,
  ShieldCheck,
  Truck,
  BadgeCheck,
  Headset,
  Phone,
  MapPin,
  ChevronRight,
} from "lucide-react";
import { useLang, loc } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { phoneHref, trackEvent, useSettings, whatsappHref } from "@/lib/shop";
import { HeroSlider } from "@/components/HeroSlider";
import { ProductRow } from "@/components/ProductRow";
import { RatingStars } from "@/components/RatingStars";
import { WhatsAppIcon } from "@/components/WhatsAppIcon";
import { Img } from "@/components/Img";
import type { BannerItem, CardProduct } from "@/types";

const CATEGORY_ICONS = [Refrigerator, WashingMachine, Tv, Wind, AirVent, Snowflake, Microwave, Coffee];

export default function Home() {
  const { lang, t } = useLang();
  const { data: settings } = useSettings();
  const { data: banners } = trpc.catalog.banners.useQuery(undefined, { staleTime: 60_000 });
  const { data: categories } = trpc.catalog.categories.useQuery(undefined, { staleTime: 60_000 });
  const { data: popular } = trpc.catalog.products.useQuery({ isPopular: true, limit: 12 });
  const { data: news } = trpc.catalog.products.useQuery({ isNew: true, limit: 12 });
  const { data: sale } = trpc.catalog.products.useQuery({ onSale: true, limit: 12 });
  const { data: brands } = trpc.catalog.brands.useQuery(undefined, { staleTime: 60_000 });
  const { data: reviews } = trpc.catalog.recentReviews.useQuery(undefined, { staleTime: 60_000 });

  const popularBrands = (brands ?? []).filter((b) => b.isPopular);

  const advantages = [
    { icon: ShieldCheck, title: t.advWarranty, text: t.advWarrantyText },
    { icon: Truck, title: t.advDelivery, text: t.advDeliveryText },
    { icon: BadgeCheck, title: t.advChecked, text: t.advCheckedText },
    { icon: Headset, title: t.advSupport, text: t.advSupportText },
  ];

  return (
    <div>
      <HeroSlider banners={(banners ?? []) as BannerItem[]} />

      {/* Каталог категорий */}
      <section className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-4 flex items-end justify-between border-b border-neutral-200 pb-3">
          <h2 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
            {t.catalog}
          </h2>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {(categories ?? []).map((c, i) => {
            const Icon = CATEGORY_ICONS[i % CATEGORY_ICONS.length] ?? Package;
            return (
              <Link
                key={c.id}
                to={`/catalog/${c.slug}`}
                className="group flex items-center gap-3 border border-neutral-200 bg-white p-4 transition-colors hover:border-neutral-900"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center text-neutral-500 transition-colors group-hover:text-[var(--accent)]">
                  <Icon size={28} strokeWidth={1.5} />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold text-neutral-900">
                    {loc(lang, c.nameRu, c.nameKg)}
                  </span>
                  <span className="block text-xs text-neutral-400">
                    {c.productCount} {t.pcs}
                  </span>
                </span>
                <ChevronRight size={16} className="ml-auto shrink-0 text-neutral-300 transition-colors group-hover:text-[var(--accent)]" />
              </Link>
            );
          })}
        </div>
      </section>

      <ProductRow
        title={t.popularProducts}
        products={(popular?.items ?? []) as CardProduct[]}
        viewAllTo="/catalog"
        viewAllLabel={t.viewAll}
      />
      <ProductRow
        title={t.newProducts}
        products={(news?.items ?? []) as CardProduct[]}
        viewAllTo="/catalog?sort=new"
        viewAllLabel={t.viewAll}
      />
      <ProductRow
        title={t.saleProducts}
        products={(sale?.items ?? []) as CardProduct[]}
        viewAllTo="/catalog?sale=1"
        viewAllLabel={t.viewAll}
      />

      {/* Популярные производители */}
      {popularBrands.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-8">
          <div className="mb-4 border-b border-neutral-200 pb-3">
            <h2 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
              {t.popularBrands}
            </h2>
          </div>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
            {popularBrands.map((b) => (
              <Link
                key={b.id}
                to={`/catalog?brand=${b.slug}`}
                className="flex h-20 items-center justify-center border border-neutral-200 bg-white p-3 transition-colors hover:border-neutral-900"
              >
                {b.logo ? (
                  <Img src={b.logo} alt={b.name} className="max-h-12 w-auto object-contain" />
                ) : (
                  <span className="text-lg font-extrabold tracking-tight text-neutral-700">{b.name}</span>
                )}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Преимущества */}
      <section className="bg-[var(--brand)]">
        <div className="mx-auto max-w-7xl px-4 py-10">
          <h2 className="mb-6 text-xl font-extrabold tracking-tight text-white sm:text-2xl">
            {t.advantages}
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {advantages.map((a) => (
              <div key={a.title} className="border border-white/15 p-5">
                <a.icon size={28} strokeWidth={1.5} className="text-[var(--accent)]" />
                <div className="mt-3 text-base font-bold text-white">{a.title}</div>
                <div className="mt-1.5 text-sm leading-6 text-white/70">{a.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Доставка */}
      {settings && (
        <section className="mx-auto max-w-7xl px-4 py-10">
          <div className="flex flex-col items-start gap-6 border border-neutral-200 bg-white p-6 sm:p-8 md:flex-row md:items-center">
            <span className="flex h-14 w-14 shrink-0 items-center justify-center bg-[var(--accent)]/10 text-[var(--accent)]">
              <Truck size={30} strokeWidth={1.5} />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
                {t.deliveryTitle}
              </h2>
              <p className="mt-2 text-sm leading-6 text-neutral-600 sm:text-base">
                {loc(lang, settings.delivery_ru, settings.delivery_kg)}
              </p>
            </div>
            <a
              href={whatsappHref(settings.whatsapp)}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackEvent("whatsapp_click")}
              className="flex h-11 shrink-0 items-center gap-2 bg-[#25D366] px-5 text-sm font-bold text-white transition-opacity hover:opacity-90"
            >
              <WhatsAppIcon size={17} />
              {t.writeWhatsApp}
            </a>
          </div>
        </section>
      )}

      {/* Отзывы */}
      {reviews && reviews.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-8">
          <div className="mb-4 border-b border-neutral-200 pb-3">
            <h2 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
              {t.reviewsTitle}
            </h2>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {reviews.map((r) => (
              <div key={r.review.id} className="flex flex-col border border-neutral-200 bg-white p-5">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-neutral-900">{r.review.authorName}</span>
                  <RatingStars value={r.review.rating} size={14} />
                </div>
                <p className="mt-2.5 line-clamp-4 flex-1 text-sm leading-6 text-neutral-600">
                  {r.review.text}
                </p>
                <Link
                  to={`/product/${r.productSlug}`}
                  className="mt-3 text-xs font-semibold text-[var(--accent)] hover:underline"
                >
                  {r.productName}
                </Link>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Контакты и карта */}
      {settings && (
        <section className="mx-auto max-w-7xl px-4 py-10">
          <div className="mb-4 border-b border-neutral-200 pb-3">
            <h2 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
              {t.contactsTitle}
            </h2>
          </div>
          <div className="grid gap-3 lg:grid-cols-2">
            <div className="flex flex-col gap-4 border border-neutral-200 bg-white p-6">
              <a
                href={phoneHref(settings.phone)}
                onClick={() => trackEvent("phone_click")}
                className="flex items-center gap-3 text-lg font-bold text-neutral-900 hover:text-[var(--accent)]"
              >
                <Phone size={20} /> {settings.phone}
              </a>
              <a
                href={whatsappHref(settings.whatsapp)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackEvent("whatsapp_click")}
                className="flex items-center gap-3 text-lg font-bold text-neutral-900 hover:text-[#25D366]"
              >
                <WhatsAppIcon size={20} className="text-[#25D366]" /> {settings.whatsapp}
              </a>
              <div className="flex items-start gap-3 text-neutral-700">
                <MapPin size={20} className="mt-0.5 shrink-0" />
                {loc(lang, settings.address_ru, settings.address_kg)}
              </div>
              <div className="mt-auto flex gap-2 pt-2">
                <a
                  href={phoneHref(settings.phone)}
                  onClick={() => trackEvent("phone_click")}
                  className="flex h-11 flex-1 items-center justify-center gap-2 bg-[var(--brand)] text-sm font-bold text-white transition-opacity hover:opacity-90"
                >
                  <Phone size={16} /> {t.call}
                </a>
                <a
                  href={whatsappHref(settings.whatsapp)}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackEvent("whatsapp_click")}
                  className="flex h-11 flex-1 items-center justify-center gap-2 bg-[#25D366] text-sm font-bold text-white transition-opacity hover:opacity-90"
                >
                  <WhatsAppIcon size={16} /> WhatsApp
                </a>
              </div>
            </div>
            {settings.map_embed_url ? (
              <iframe
                src={settings.map_embed_url}
                title="Google Maps"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-72 w-full border border-neutral-200 lg:h-auto lg:min-h-72"
                allowFullScreen
              />
            ) : (
              <div className="flex h-72 items-center justify-center border border-dashed border-neutral-300 bg-white text-sm text-neutral-400 lg:h-auto">
                Google Maps
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
}
