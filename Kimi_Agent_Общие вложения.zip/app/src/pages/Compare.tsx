import { useMemo, useState } from "react";
import { Link } from "react-router";
import { GitCompareArrows, Trash2, X } from "lucide-react";
import { useLang, loc } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { clearStore, toggleId, useStoreIds } from "@/lib/localStore";
import { formatPrice, useSettings } from "@/lib/shop";
import type { FullProduct } from "@/types";
import { Img } from "@/components/Img";
import { cn } from "@/lib/utils";

export default function Compare() {
  const { lang, t } = useLang();
  const { data: settings } = useSettings();
  const compareIds = useStoreIds("compare");
  const [onlyDiff, setOnlyDiff] = useState(false);
  const { data } = trpc.catalog.productsFullByIds.useQuery(
    { ids: compareIds },
    { enabled: compareIds.length > 0 },
  );
  const products = useMemo(
    () =>
      ((data ?? []) as FullProduct[]).sort(
        (a, b) => compareIds.indexOf(a.id) - compareIds.indexOf(b.id),
      ),
    [data, compareIds],
  );
  const currency = settings?.currency ?? t.som;

  // Объединение характеристик
  const specRows = useMemo(() => {
    const map = new Map<string, { keyRu: string; keyKg: string | null; values: Map<number, string> }>();
    for (const p of products) {
      for (const s of p.specs) {
        const k = s.keySlug ?? s.keyRu;
        if (!map.has(k)) map.set(k, { keyRu: s.keyRu, keyKg: s.keyKg, values: new Map() });
        map.get(k)!.values.set(p.id, loc(lang, s.valueRu, s.valueKg));
      }
    }
    return [...map.entries()];
  }, [products, lang]);

  const visibleRows = onlyDiff
    ? specRows.filter(([, row]) => {
        const vals = products.map((p) => row.values.get(p.id) ?? "—");
        return new Set(vals).size > 1;
      })
    : specRows;

  if (compareIds.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-6">
        <h1 className="mb-5 flex items-center gap-2 text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
          <GitCompareArrows size={22} className="text-[var(--accent)]" />
          {t.compare}
        </h1>
        <div className="flex flex-col items-center gap-2 border border-dashed border-neutral-300 bg-white py-20 text-center">
          <GitCompareArrows size={40} className="text-neutral-300" />
          <div className="text-lg font-bold text-neutral-800">{t.compareEmpty}</div>
          <div className="max-w-sm text-sm text-neutral-500">{t.compareEmptyHint}</div>
          <Link to="/catalog" className="mt-3 flex h-11 items-center bg-[var(--brand)] px-6 text-sm font-bold text-white">
            {t.goToCatalog}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="flex items-center gap-2 text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
          <GitCompareArrows size={22} className="text-[var(--accent)]" />
          {t.compare}
          <span className="text-sm font-normal text-neutral-400">({products.length})</span>
        </h1>
        <div className="flex items-center gap-2">
          <label className="flex cursor-pointer items-center gap-2 border border-neutral-300 bg-white px-3 py-2 text-sm font-semibold text-neutral-700">
            <input
              type="checkbox"
              checked={onlyDiff}
              onChange={(e) => setOnlyDiff(e.target.checked)}
              className="h-4 w-4 accent-[var(--accent)]"
            />
            {t.compareOnlyDiff}
          </label>
          <button
            type="button"
            onClick={() => clearStore("compare")}
            className="flex h-10 cursor-pointer items-center gap-2 border border-neutral-300 bg-white px-3 text-sm font-semibold text-neutral-700 hover:border-neutral-900"
          >
            <Trash2 size={15} /> {t.clear}
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse border border-neutral-200 bg-white text-sm">
          <thead>
            <tr>
              <th className="w-40 border-b border-neutral-200 bg-neutral-50 p-3 text-left align-top text-xs font-bold uppercase tracking-wider text-neutral-500">
                {t.specs}
              </th>
              {products.map((p) => (
                <th key={p.id} className="min-w-48 border-b border-l border-neutral-200 p-3 align-top">
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => toggleId("compare", p.id)}
                      aria-label={t.removeFromCompare}
                      className="absolute -right-1 -top-1 flex h-7 w-7 cursor-pointer items-center justify-center rounded-full border border-neutral-200 bg-white text-neutral-500 hover:text-red-600"
                    >
                      <X size={14} />
                    </button>
                    <Link to={`/product/${p.slug}`}>
                      <Img src={p.images[0]?.url} alt={loc(lang, p.nameRu, p.nameKg)} className="mx-auto h-28 w-28 object-contain" />
                    </Link>
                    <Link
                      to={`/product/${p.slug}`}
                      className="mt-2 block text-left text-sm font-semibold leading-5 text-neutral-900 hover:text-[var(--accent)]"
                    >
                      {loc(lang, p.nameRu, p.nameKg)}
                    </Link>
                    <div className="mt-1 text-left text-base font-extrabold text-neutral-900">
                      {formatPrice(p.price, currency)}
                      {p.oldPrice && p.oldPrice > p.price && (
                        <span className="ml-2 text-xs font-normal text-neutral-400 line-through">
                          {formatPrice(p.oldPrice, currency)}
                        </span>
                      )}
                    </div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <SpecRow label={t.brand} values={products.map((p) => p.brand?.name ?? "—")} />
            <SpecRow
              label={t.inStock}
              values={products.map((p) => (p.inStock ? t.inStock : t.outOfStock))}
              highlight
            />
            <SpecRow label={t.warranty} values={products.map((p) => p.warranty ?? "—")} />
            {visibleRows.map(([k, row]) => (
              <SpecRow
                key={k}
                label={loc(lang, row.keyRu, row.keyKg)}
                values={products.map((p) => row.values.get(p.id) ?? "—")}
                diff={new Set(products.map((p) => row.values.get(p.id) ?? "—")).size > 1}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SpecRow({
  label,
  values,
  diff = false,
  highlight = false,
}: {
  label: string;
  values: string[];
  diff?: boolean;
  highlight?: boolean;
}) {
  return (
    <tr className={cn(diff && "bg-amber-50/50")}>
      <td className="border-b border-neutral-100 bg-neutral-50 p-3 text-xs font-semibold text-neutral-500">
        {label}
      </td>
      {values.map((v, i) => (
        <td
          key={i}
          className={cn(
            "border-b border-l border-neutral-100 p-3",
            highlight ? "font-semibold text-emerald-600" : "text-neutral-800",
          )}
        >
          {v}
        </td>
      ))}
    </tr>
  );
}
