import { Link } from "react-router";
import { Heart, Trash2 } from "lucide-react";
import { useLang } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { clearStore, useStoreIds } from "@/lib/localStore";
import type { CardProduct } from "@/types";
import { ProductCard } from "@/components/ProductCard";

export default function Favorites() {
  const { t } = useLang();
  const favorites = useStoreIds("favorites");
  const history = useStoreIds("history");
  const { data } = trpc.catalog.productsByIds.useQuery(
    { ids: favorites },
    { enabled: favorites.length > 0 },
  );
  const historyIds = history.filter((id) => !favorites.includes(id)).slice(0, 8);
  const { data: historyProducts } = trpc.catalog.productsByIds.useQuery(
    { ids: historyIds },
    { enabled: historyIds.length > 0 },
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-5 flex items-center justify-between">
        <h1 className="flex items-center gap-2 text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">
          <Heart size={22} className="text-[var(--accent)]" />
          {t.favorites}
          {favorites.length > 0 && (
            <span className="text-sm font-normal text-neutral-400">({favorites.length})</span>
          )}
        </h1>
        {favorites.length > 0 && (
          <button
            type="button"
            onClick={() => clearStore("favorites")}
            className="flex h-10 cursor-pointer items-center gap-2 border border-neutral-300 bg-white px-3 text-sm font-semibold text-neutral-700 hover:border-neutral-900"
          >
            <Trash2 size={15} /> {t.clear}
          </button>
        )}
      </div>

      {favorites.length === 0 ? (
        <div className="flex flex-col items-center gap-2 border border-dashed border-neutral-300 bg-white py-20 text-center">
          <Heart size={40} className="text-neutral-300" />
          <div className="text-lg font-bold text-neutral-800">{t.favoritesEmpty}</div>
          <div className="max-w-sm text-sm text-neutral-500">{t.favoritesEmptyHint}</div>
          <Link to="/catalog" className="mt-3 flex h-11 items-center bg-[var(--brand)] px-6 text-sm font-bold text-white">
            {t.goToCatalog}
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
          {((data ?? []) as CardProduct[]).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}

      {historyProducts && historyProducts.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 border-b border-neutral-200 pb-2 text-lg font-extrabold text-neutral-900">
            {t.recentlyViewed}
          </h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
            {(historyProducts as CardProduct[]).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
