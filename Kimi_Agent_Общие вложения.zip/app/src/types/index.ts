export interface BrandRef {
  id: number;
  name: string;
  slug: string;
}

export interface CategoryRef {
  id: number;
  slug: string;
  nameRu: string;
  nameKg: string | null;
}

export interface CardProduct {
  id: number;
  slug: string;
  nameRu: string;
  nameKg: string | null;
  price: number;
  oldPrice: number | null;
  warranty: string | null;
  inStock: boolean;
  isPopular: boolean;
  isNew: boolean;
  views: number;
  brand: BrandRef | null;
  category: CategoryRef | null;
  image: string | null;
  hoverImage: string | null;
  discount: number;
}

export interface ProductSpecItem {
  id: number;
  keySlug: string | null;
  keyRu: string;
  keyKg: string | null;
  valueRu: string;
  valueKg: string | null;
}

export interface FullProduct extends Omit<CardProduct, "image" | "hoverImage"> {
  descriptionRu: string | null;
  descriptionKg: string | null;
  images: { id: number; url: string }[];
  specs: ProductSpecItem[];
}

export interface BannerItem {
  id: number;
  titleRu: string;
  titleKg: string | null;
  subtitleRu: string | null;
  subtitleKg: string | null;
  buttonTextRu: string | null;
  buttonTextKg: string | null;
  linkUrl: string | null;
  bgColor: string | null;
  image: string;
}

export interface ReviewItem {
  id: number;
  productId: number;
  authorName: string;
  rating: number;
  text: string;
  createdAt: Date | string;
}

export interface FilterDef {
  id: number;
  keySlug: string;
  labelRu: string;
  labelKg: string | null;
  values: { valueRu: string; valueKg: string | null }[];
}
