import { Outlet } from "react-router";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { useSettings, whatsappHref } from "@/lib/shop";
import { WhatsAppIcon } from "./WhatsAppIcon";
import { useLang } from "@/i18n";

export function Layout() {
  const { data: settings } = useSettings();
  const { t } = useLang();

  return (
    <div className="flex min-h-dvh flex-col">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      {settings && (
        <a
          href={whatsappHref(settings.whatsapp)}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={t.writeWhatsApp}
          className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-black/20 transition-transform hover:scale-105"
        >
          <WhatsAppIcon size={28} />
        </a>
      )}
    </div>
  );
}
