import { useState, type FormEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";
import {
  Heart,
  GitCompareArrows,
  Search,
  Menu,
  Phone,
  Clock3,
  LayoutGrid,
} from "lucide-react";
import { useLang, loc } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { useStoreIds } from "@/lib/localStore";
import { phoneHref, trackEvent, useSettings, whatsappHref } from "@/lib/shop";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Img } from "./Img";
import { WhatsAppIcon } from "./WhatsAppIcon";

export function Header() {
  const { lang, setLang, t } = useLang();
  const { data: settings } = useSettings();
  const { data: categories } = trpc.catalog.categories.useQuery(undefined, { staleTime: 60_000 });
  const favorites = useStoreIds("favorites");
  const compare = useStoreIds("compare");
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [menuOpen, setMenuOpen] = useState(false);

  const submitSearch = (e: FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    navigate(query ? `/catalog?q=${encodeURIComponent(query)}` : "/catalog");
    setMenuOpen(false);
  };

  const siteName = settings ? loc(lang, settings.site_name_ru, settings.site_name_kg) : "…";

  const langSwitch = (
    <div className="flex items-center text-xs font-semibold" role="group" aria-label="RU / KG">
      <button
        type="button"
        onClick={() => setLang("ru")}
        className={`cursor-pointer px-1.5 py-1 transition-colors ${lang === "ru" ? "text-[var(--accent)]" : "text-neutral-400 hover:text-neutral-700"}`}
      >
        RU
      </button>
      <span className="text-neutral-300">|</span>
      <button
        type="button"
        onClick={() => setLang("kg")}
        className={`cursor-pointer px-1.5 py-1 transition-colors ${lang === "kg" ? "text-[var(--accent)]" : "text-neutral-400 hover:text-neutral-700"}`}
      >
        KG
      </button>
    </div>
  );

  return (
    <header className="sticky top-0 z-40">
      {/* Верхняя полоса */}
      <div className="bg-[var(--brand)] text-white">
        <div className="mx-auto flex h-9 max-w-7xl items-center justify-between gap-3 px-4 text-xs">
          <div className="flex min-w-0 items-center gap-4">
            {settings && (
              <a
                href={phoneHref(settings.phone)}
                onClick={() => trackEvent("phone_click")}
                className="flex items-center gap-1.5 font-medium hover:opacity-80"
              >
                <Phone size={13} />
                <span className="hidden sm:inline">{settings.phone}</span>
                <span className="sm:hidden">{t.call}</span>
              </a>
            )}
            {settings && (
              <a
                href={whatsappHref(settings.whatsapp)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackEvent("whatsapp_click")}
                className="hidden items-center gap-1.5 font-medium hover:opacity-80 sm:flex"
              >
                <WhatsAppIcon size={13} />
                {settings.whatsapp}
              </a>
            )}
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-1.5 text-white/70 md:flex">
              <Clock3 size={13} />
              {t.freeDeliveryNote}
            </span>
            {langSwitch}
          </div>
        </div>
      </div>

      {/* Основная панель */}
      <div className="border-b border-neutral-200 bg-white">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4">
          {/* Мобильное меню */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label={t.menu}
                className="flex h-10 w-10 cursor-pointer items-center justify-center border border-neutral-200 text-neutral-700 lg:hidden"
              >
                <Menu size={20} />
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 overflow-y-auto p-0">
              <SheetHeader className="border-b border-neutral-100 p-4 text-left">
                <SheetTitle className="text-base">{siteName}</SheetTitle>
              </SheetHeader>
              <nav className="flex flex-col p-2">
                <Link
                  to="/catalog"
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2 px-3 py-2.5 text-sm font-semibold text-neutral-900 hover:bg-neutral-100"
                >
                  <LayoutGrid size={16} />
                  {t.catalog}
                </Link>
                {categories?.map((c) => (
                  <Link
                    key={c.id}
                    to={`/catalog/${c.slug}`}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center justify-between px-3 py-2.5 text-sm text-neutral-700 hover:bg-neutral-100"
                  >
                    {loc(lang, c.nameRu, c.nameKg)}
                    <span className="text-xs text-neutral-400">{c.productCount}</span>
                  </Link>
                ))}
                <div className="my-2 border-t border-neutral-100" />
                <Link to="/favorites" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm text-neutral-700 hover:bg-neutral-100">
                  {t.favorites} ({favorites.length})
                </Link>
                <Link to="/compare" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm text-neutral-700 hover:bg-neutral-100">
                  {t.compare} ({compare.length})
                </Link>
                {settings && (
                  <a
                    href={whatsappHref(settings.whatsapp)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mx-3 mt-2 flex items-center justify-center gap-2 bg-[#25D366] px-3 py-2.5 text-sm font-semibold text-white"
                  >
                    <WhatsAppIcon size={16} />
                    {t.writeWhatsApp}
                  </a>
                )}
              </nav>
            </SheetContent>
          </Sheet>

          {/* Логотип */}
          <Link to="/" className="flex min-w-0 items-center gap-2">
            {settings?.logo_resolved ? (
              <Img src={settings.logo_resolved} alt={siteName} className="h-9 w-auto max-w-40 object-contain" eager />
            ) : (
              <span className="truncate text-lg font-extrabold tracking-tight text-neutral-900">
                {siteName}
              </span>
            )}
          </Link>

          {/* Поиск */}
          <form onSubmit={submitSearch} className="mx-auto hidden w-full max-w-xl md:flex" role="search">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t.searchPlaceholder}
              aria-label={t.search}
              className="h-10 w-full border border-neutral-300 bg-white px-3 text-sm outline-none focus:border-neutral-900"
            />
            <button
              type="submit"
              aria-label={t.search}
              className="flex h-10 w-12 cursor-pointer items-center justify-center bg-[var(--brand)] text-white transition-opacity hover:opacity-90"
            >
              <Search size={17} />
            </button>
          </form>

          {/* Иконки */}
          <div className="ml-auto flex items-center gap-1 md:ml-0">
            <Link
              to="/favorites"
              aria-label={t.favorites}
              className="relative flex h-10 w-10 items-center justify-center text-neutral-700 transition-colors hover:text-[var(--accent)]"
            >
              <Heart size={21} />
              {favorites.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--accent)] px-1 text-[10px] font-bold text-white">
                  {favorites.length}
                </span>
              )}
            </Link>
            <Link
              to="/compare"
              aria-label={t.compare}
              className="relative flex h-10 w-10 items-center justify-center text-neutral-700 transition-colors hover:text-[var(--accent)]"
            >
              <GitCompareArrows size={21} />
              {compare.length > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--accent)] px-1 text-[10px] font-bold text-white">
                  {compare.length}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* Мобильный поиск */}
        <form onSubmit={submitSearch} className="flex px-4 pb-3 md:hidden" role="search">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t.searchPlaceholder}
            aria-label={t.search}
            className="h-10 w-full border border-neutral-300 bg-white px-3 text-sm outline-none focus:border-neutral-900"
          />
          <button
            type="submit"
            aria-label={t.search}
            className="flex h-10 w-12 cursor-pointer items-center justify-center bg-[var(--brand)] text-white"
          >
            <Search size={17} />
          </button>
        </form>
      </div>

      {/* Навигация по категориям (десктоп) */}
      <div className="hidden border-b border-neutral-200 bg-white lg:block">
        <nav className="mx-auto flex max-w-7xl items-center gap-1 overflow-x-auto px-4" aria-label={t.allCategories}>
          <Link
            to="/catalog"
            className="flex h-11 shrink-0 items-center gap-1.5 px-3 text-sm font-semibold text-[var(--accent)] hover:opacity-80"
          >
            <LayoutGrid size={15} />
            {t.catalog}
          </Link>
          {categories?.map((c) => (
            <Link
              key={c.id}
              to={`/catalog/${c.slug}`}
              className="flex h-11 shrink-0 items-center px-3 text-sm text-neutral-700 transition-colors hover:text-[var(--accent)]"
            >
              {loc(lang, c.nameRu, c.nameKg)}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
