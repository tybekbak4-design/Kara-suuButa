import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLang, loc } from "@/i18n";
import type { BannerItem } from "@/types";
import { Img } from "./Img";
import { cn } from "@/lib/utils";

export function HeroSlider({ banners }: { banners: BannerItem[] }) {
  const { lang } = useLang();
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  const [selected, setSelected] = useState(0);

  const onSelect = useCallback(() => {
    if (emblaApi) setSelected(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    emblaApi.on("select", onSelect);
    const timer = setInterval(() => emblaApi.scrollNext(), 5000);
    return () => {
      emblaApi.off("select", onSelect);
      clearInterval(timer);
    };
  }, [emblaApi, onSelect]);

  if (banners.length === 0) return null;

  return (
    <div className="relative">
      <div className="overflow-hidden" ref={emblaRef}>
        <div className="flex">
          {banners.map((b, i) => (
            <div key={b.id} className="relative min-w-0 flex-[0_0_100%]">
              <div
                className="relative flex h-64 items-center overflow-hidden sm:h-80 lg:h-96"
                style={b.bgColor ? { backgroundColor: b.bgColor } : undefined}
              >
                {b.image && (
                  <Img
                    src={b.image}
                    alt={loc(lang, b.titleRu, b.titleKg)}
                    eager={i === 0}
                    className="absolute inset-0 h-full w-full object-cover"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
                <div className="relative z-10 mx-auto w-full max-w-7xl px-4">
                  <div className="max-w-xl text-white">
                    <h2 className="text-2xl font-extrabold leading-tight sm:text-3xl lg:text-4xl">
                      {loc(lang, b.titleRu, b.titleKg)}
                    </h2>
                    {loc(lang, b.subtitleRu, b.subtitleKg) && (
                      <p className="mt-3 text-sm leading-6 text-white/85 sm:text-base">
                        {loc(lang, b.subtitleRu, b.subtitleKg)}
                      </p>
                    )}
                    {b.linkUrl && loc(lang, b.buttonTextRu, b.buttonTextKg) && (
                      <Link
                        to={b.linkUrl}
                        className="mt-5 inline-flex h-11 items-center bg-[var(--accent)] px-6 text-sm font-bold text-white transition-opacity hover:opacity-90"
                      >
                        {loc(lang, b.buttonTextRu, b.buttonTextKg)}
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {banners.length > 1 && (
        <>
          <button
            type="button"
            aria-label="Previous"
            onClick={() => emblaApi?.scrollPrev()}
            className="absolute left-3 top-1/2 hidden h-10 w-10 -translate-y-1/2 cursor-pointer items-center justify-center bg-white/90 text-neutral-800 shadow transition hover:bg-white sm:flex"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            type="button"
            aria-label="Next"
            onClick={() => emblaApi?.scrollNext()}
            className="absolute right-3 top-1/2 hidden h-10 w-10 -translate-y-1/2 cursor-pointer items-center justify-center bg-white/90 text-neutral-800 shadow transition hover:bg-white sm:flex"
          >
            <ChevronRight size={20} />
          </button>
          <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-1.5">
            {banners.map((b, i) => (
              <button
                key={b.id}
                type="button"
                aria-label={`Slide ${i + 1}`}
                onClick={() => emblaApi?.scrollTo(i)}
                className={cn(
                  "h-1.5 cursor-pointer transition-all",
                  i === selected ? "w-6 bg-[var(--accent)]" : "w-1.5 bg-white/70",
                )}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
