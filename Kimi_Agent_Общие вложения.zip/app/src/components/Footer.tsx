import { Link } from "react-router";
import { Phone, MapPin } from "lucide-react";
import { useLang, loc } from "@/i18n";
import { trpc } from "@/providers/trpc";
import { phoneHref, trackEvent, useSettings, whatsappHref } from "@/lib/shop";
import { WhatsAppIcon } from "./WhatsAppIcon";

export function Footer() {
  const { lang, t } = useLang();
  const { data: settings } = useSettings();
  const { data: categories } = trpc.catalog.categories.useQuery(undefined, { staleTime: 60_000 });

  const siteName = settings ? loc(lang, settings.site_name_ru, settings.site_name_kg) : "";

  return (
    <footer className="mt-12 bg-[var(--brand)] text-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-3">
        <div>
          <div className="text-lg font-extrabold">{siteName}</div>
          <p className="mt-3 text-sm leading-6 text-white/70">{t.footerNote}</p>
        </div>
        <nav aria-label={t.navigation}>
          <div className="text-sm font-semibold uppercase tracking-wide text-white/50">{t.navigation}</div>
          <div className="mt-3 grid grid-cols-1 gap-2 text-sm">
            <Link to="/catalog" className="text-white/80 hover:text-white">{t.catalog}</Link>
            {categories?.slice(0, 6).map((c) => (
              <Link key={c.id} to={`/catalog/${c.slug}`} className="text-white/80 hover:text-white">
                {loc(lang, c.nameRu, c.nameKg)}
              </Link>
            ))}
            <Link to="/favorites" className="text-white/80 hover:text-white">{t.favorites}</Link>
            <Link to="/compare" className="text-white/80 hover:text-white">{t.compare}</Link>
          </div>
        </nav>
        {settings && (
          <div>
            <div className="text-sm font-semibold uppercase tracking-wide text-white/50">{t.contacts}</div>
            <div className="mt-3 space-y-2.5 text-sm">
              <a
                href={phoneHref(settings.phone)}
                onClick={() => trackEvent("phone_click")}
                className="flex items-center gap-2 text-white/80 hover:text-white"
              >
                <Phone size={15} /> {settings.phone}
              </a>
              <a
                href={whatsappHref(settings.whatsapp)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackEvent("whatsapp_click")}
                className="flex items-center gap-2 text-white/80 hover:text-white"
              >
                <WhatsAppIcon size={15} /> {settings.whatsapp}
              </a>
              <div className="flex items-start gap-2 text-white/80">
                <MapPin size={15} className="mt-0.5 shrink-0" />
                {loc(lang, settings.address_ru, settings.address_kg)}
              </div>
            </div>
          </div>
        )}
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4 py-4 text-xs text-white/50">
          © {new Date().getFullYear()} {siteName}
        </div>
      </div>
    </footer>
  );
}
