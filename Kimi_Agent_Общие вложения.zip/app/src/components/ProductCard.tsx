import { Link } from "react-router";
import { Heart, GitCompareArrows, Phone } from "lucide-react";
import { useLang, loc } from "@/i18n";
import { toggleId, useStoreIds } from "@/lib/localStore";
import { formatPrice, phoneHref, productMessage, trackEvent, useSettings, whatsappHref } from "@/lib/shop";
import { cn } from "@/lib/utils";
import type { CardProduct } from "@/types";
import { Img } from "./Img";
import { WhatsAppIcon } from "./WhatsAppIcon";

export function ProductCard({ product }: { product: CardProduct }) {
  const { lang, t } = useLang();
  const { data: settings } = useSettings();
  const favorites = useStoreIds("favorites");
  const compare = useStoreIds("compare");
  const isFav = favorites.includes(product.id);
  const isCmp = compare.includes(product.id);

  const name = loc(lang, product.nameRu, product.nameKg);
  const currency = settings?.currency ?? t.som;
  const waMessage = settings
    ? productMessage(name, formatPrice(product.price, currency), product.slug, lang)
    : undefined;

  return (
    <div className="group relative flex h-full flex-col border border-neutral-200 bg-white transition-colors duration-200 hover:border-neutral-900">
      {/* Бейджи */}
      <div className="absolute left-2 top-2 z-10 flex flex-col items-start gap-1">
        {product.discount > 0 && (
          <span className="bg-[var(--accent)] px-2 py-0.5 text-xs font-bold text-white">
            −{product.discount}%
          </span>
        )}
        {product.isNew && (
          <span className="bg-[var(--brand)] px-2 py-0.5 text-xs font-semibold text-white">
            {t.new}
          </span>
        )}
      </div>

      {/* Действия */}
      <div className="absolute right-2 top-2 z-10 flex flex-col gap-1">
        <button
          type="button"
          onClick={() => toggleId("favorites", product.id)}
          title={isFav ? t.removeFromFavorites : t.addToFavorites}
          aria-label={isFav ? t.removeFromFavorites : t.addToFavorites}
          className={cn(
            "flex h-9 w-9 cursor-pointer items-center justify-center rounded-full border bg-white transition-colors focus-visible:outline-2 focus-visible:outline-[var(--accent)]",
            isFav
              ? "border-[var(--accent)] text-[var(--accent)]"
              : "border-neutral-200 text-neutral-500 hover:text-[var(--accent)]",
          )}
        >
          <Heart size={17} className={isFav ? "fill-[var(--accent)]" : ""} />
        </button>
        <button
          type="button"
          onClick={() => toggleId("compare", product.id)}
          title={isCmp ? t.removeFromCompare : t.addToCompare}
          aria-label={isCmp ? t.removeFromCompare : t.addToCompare}
          className={cn(
            "flex h-9 w-9 cursor-pointer items-center justify-center rounded-full border bg-white transition-colors focus-visible:outline-2 focus-visible:outline-[var(--accent)]",
            isCmp
              ? "border-[var(--brand)] text-[var(--brand)]"
              : "border-neutral-200 text-neutral-500 hover:text-[var(--brand)]",
          )}
        >
          <GitCompareArrows size={17} />
        </button>
      </div>

      {/* Фото */}
      <Link to={`/product/${product.slug}`} className="relative block aspect-square overflow-hidden">
        <Img
          src={product.image}
          alt={name}
          className="h-full w-full object-contain p-4 transition-opacity duration-200 group-hover:opacity-0"
        />
        {product.hoverImage && (
          <Img
            src={product.hoverImage}
            alt=""
            className="absolute inset-0 h-full w-full object-contain p-4 opacity-0 transition-opacity duration-200 group-hover:opacity-100"
          />
        )}
      </Link>

      {/* Тело карточки */}
      <div className="flex flex-1 flex-col gap-1.5 border-t border-neutral-100 p-3">
        <div className="text-xs font-medium uppercase tracking-wide text-neutral-400">
          {product.brand?.name}
        </div>
        <Link
          to={`/product/${product.slug}`}
          className="line-clamp-2 min-h-10 text-sm font-medium leading-5 text-neutral-900 hover:text-[var(--accent)]"
        >
          {name}
        </Link>

        <div className="mt-auto space-y-1.5 pt-2">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <span className="text-lg font-bold text-neutral-900">
              {formatPrice(product.price, currency)}
            </span>
            {product.oldPrice && product.oldPrice > product.price && (
              <span className="text-sm text-neutral-400 line-through">
                {formatPrice(product.oldPrice, currency)}
              </span>
            )}
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className={product.inStock ? "font-medium text-emerald-600" : "font-medium text-neutral-400"}>
              {product.inStock ? t.inStock : t.outOfStock}
            </span>
            {product.warranty && (
              <span className="text-neutral-400">
                {t.warranty}: {product.warranty}
              </span>
            )}
          </div>
          <div className="flex gap-1.5 pt-1">
            {settings && (
              <a
                href={whatsappHref(settings.whatsapp, waMessage)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackEvent("whatsapp_click", product.id)}
                aria-label={t.writeWhatsApp}
                className="flex h-9 flex-1 items-center justify-center gap-1.5 bg-[#25D366] text-sm font-semibold text-white transition-opacity hover:opacity-90"
              >
                <WhatsAppIcon size={16} />
                WhatsApp
              </a>
            )}
            {settings && (
              <a
                href={phoneHref(settings.phone)}
                onClick={() => trackEvent("phone_click", product.id)}
                aria-label={t.call}
                className="flex h-9 w-9 items-center justify-center border border-neutral-200 text-neutral-700 transition-colors hover:border-neutral-900"
              >
                <Phone size={16} />
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
