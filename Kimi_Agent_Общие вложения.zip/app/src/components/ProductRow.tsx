import { useRef } from "react";
import { Link } from "react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { CardProduct } from "@/types";
import { ProductCard } from "./ProductCard";

export function ProductRow({
  title,
  products,
  viewAllTo,
  viewAllLabel,
}: {
  title: string;
  products: CardProduct[];
  viewAllTo?: string;
  viewAllLabel?: string;
}) {
  const trackRef = useRef<HTMLDivElement>(null);

  if (products.length === 0) return null;

  const scrollBy = (dir: number) => {
    const el = trackRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" });
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-8">
      <div className="mb-4 flex items-end justify-between gap-4 border-b border-neutral-200 pb-3">
        <h2 className="text-xl font-extrabold tracking-tight text-neutral-900 sm:text-2xl">{title}</h2>
        <div className="flex items-center gap-2">
          {viewAllTo && (
            <Link to={viewAllTo} className="text-sm font-semibold text-[var(--accent)] hover:underline">
              {viewAllLabel}
            </Link>
          )}
          <div className="hidden gap-1 sm:flex">
            <button
              type="button"
              aria-label="Previous"
              onClick={() => scrollBy(-1)}
              className="flex h-9 w-9 cursor-pointer items-center justify-center border border-neutral-200 bg-white text-neutral-700 transition-colors hover:border-neutral-900"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              type="button"
              aria-label="Next"
              onClick={() => scrollBy(1)}
              className="flex h-9 w-9 cursor-pointer items-center justify-center border border-neutral-200 bg-white text-neutral-700 transition-colors hover:border-neutral-900"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
      <div
        ref={trackRef}
        className="flex snap-x gap-3 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {products.map((p) => (
          <div key={p.id} className="w-56 shrink-0 snap-start sm:w-64">
            <ProductCard product={p} />
          </div>
        ))}
      </div>
    </section>
  );
}
