// Подхватывает настройки сайта: цвета (CSS-переменные), title и meta
import { useEffect } from "react";
import { useLang, loc } from "@/i18n";
import { useSettings, trackVisitOnce } from "@/lib/shop";

export function ThemeFromSettings() {
  const { data } = useSettings();
  const { lang } = useLang();

  useEffect(() => {
    trackVisitOnce();
  }, []);

  useEffect(() => {
    if (!data) return;
    const root = document.documentElement;
    root.style.setProperty("--brand", data.primary_color || "#1a1a1a");
    root.style.setProperty("--accent", data.accent_color || "#ff5100");
    document.title = loc(lang, data.seo_title_ru, data.seo_title_kg);
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute("content", loc(lang, data.seo_description_ru, data.seo_description_kg));
    }
  }, [data, lang]);

  return null;
}
