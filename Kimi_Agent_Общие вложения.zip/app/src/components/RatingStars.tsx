import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function RatingStars({
  value,
  onChange,
  size = 16,
}: {
  value: number;
  onChange?: (v: number) => void;
  size?: number;
}) {
  return (
    <div className="flex items-center gap-0.5" role={onChange ? "radiogroup" : undefined} aria-label="rating">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type={onChange ? "button" : undefined}
          tabIndex={onChange ? 0 : -1}
          onClick={onChange ? () => onChange(i) : undefined}
          className={cn(
            "inline-flex",
            onChange && "cursor-pointer rounded p-0.5 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-[var(--accent)]",
            !onChange && "pointer-events-none",
          )}
          aria-label={`${i}`}
        >
          <Star
            size={size}
            className={i <= value ? "fill-amber-400 text-amber-400" : "fill-neutral-200 text-neutral-200"}
          />
        </button>
      ))}
    </div>
  );
}
