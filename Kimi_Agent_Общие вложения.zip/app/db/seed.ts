// Заполнение БД начальными данными: админ, категории, бренды, фильтры,
// демонстрационные товары с изображениями (загружаются в объектное хранилище).
// Запуск: npx tsx db/seed.ts
// Пароль первого администратора: переменная ADMIN_PASSWORD или admin12345 (смените после входа!)
import "dotenv/config";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import {
  admins,
  banners,
  brands,
  categories,
  categoryFilters,
  products,
  productImages,
  productSpecs,
  reviews,
} from "./schema";
import { slugify } from "../api/utils";
import { storage } from "../api/lib/storage";

// ─── SVG-заглушки товаров (демо, можно удалить) ─────────────────────────────

const APPLIANCE_ICONS: Record<string, string> = {
  fridge: `<rect x="300" y="120" width="200" height="560" rx="18" fill="#ffffff" opacity="0.92"/><rect x="300" y="330" width="200" height="10" fill="#d7dce2"/><rect x="470" y="200" width="14" height="70" rx="7" fill="#aab4bf"/><rect x="470" y="380" width="14" height="120" rx="7" fill="#aab4bf"/>`,
  washer: `<rect x="270" y="150" width="260" height="500" rx="20" fill="#ffffff" opacity="0.92"/><circle cx="400" cy="420" r="110" fill="#e8edf2"/><circle cx="400" cy="420" r="82" fill="#c4d2e0"/><rect x="300" y="185" width="120" height="34" rx="8" fill="#d7dce2"/><circle cx="490" cy="202" r="14" fill="#aab4bf"/>`,
  tv: `<rect x="180" y="180" width="440" height="280" rx="14" fill="#1f2733"/><rect x="196" y="196" width="408" height="248" rx="8" fill="#3d5875"/><rect x="360" y="470" width="80" height="26" fill="#9aa6b2"/><rect x="300" y="496" width="200" height="14" rx="7" fill="#9aa6b2"/>`,
  vacuum: `<rect x="250" y="320" width="220" height="170" rx="40" fill="#ffffff" opacity="0.92"/><circle cx="300" cy="510" r="34" fill="#aab4bf"/><circle cx="440" cy="510" r="34" fill="#aab4bf"/><path d="M470 340 L560 200" stroke="#ffffff" stroke-width="26" stroke-linecap="round" opacity="0.92"/><rect x="540" y="170" width="40" height="90" rx="14" fill="#ffffff" opacity="0.92" transform="rotate(35 560 215)"/>`,
  ac: `<rect x="200" y="200" width="400" height="170" rx="24" fill="#ffffff" opacity="0.92"/><rect x="230" y="310" width="340" height="22" rx="11" fill="#c9d4de"/><circle cx="520" cy="245" r="12" fill="#7fd08a"/>`,
  freezer: `<rect x="280" y="130" width="240" height="540" rx="18" fill="#ffffff" opacity="0.92"/><rect x="300" y="230" width="200" height="8" fill="#d7dce2"/><rect x="300" y="330" width="200" height="8" fill="#d7dce2"/><rect x="300" y="430" width="200" height="8" fill="#d7dce2"/><rect x="480" y="170" width="14" height="60" rx="7" fill="#aab4bf"/>`,
  microwave: `<rect x="210" y="240" width="380" height="280" rx="20" fill="#ffffff" opacity="0.92"/><rect x="240" y="275" width="230" height="210" rx="10" fill="#2b3542"/><rect x="495" y="275" width="65" height="150" rx="8" fill="#d7dce2"/><circle cx="527" cy="455" r="16" fill="#aab4bf"/>`,
  small: `<rect x="300" y="200" width="200" height="180" rx="24" fill="#ffffff" opacity="0.92"/><path d="M500 240 q60 20 0 100" stroke="#ffffff" stroke-width="22" fill="none" opacity="0.92"/><rect x="330" y="380" width="140" height="200" rx="16" fill="#ffffff" opacity="0.85"/><rect x="352" y="160" width="96" height="40" rx="12" fill="#d7dce2"/>`,
};

function productSvg(icon: string, hue: number, brand: string, label: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="hsl(${hue}, 45%, 92%)"/>
      <stop offset="1" stop-color="hsl(${hue}, 40%, 82%)"/>
    </linearGradient>
  </defs>
  <rect width="800" height="800" fill="url(#bg)"/>
  <circle cx="400" cy="400" r="270" fill="hsl(${hue}, 50%, 96%)" opacity="0.6"/>
  ${icon}
  <text x="60" y="730" font-family="Arial, sans-serif" font-size="44" font-weight="bold" fill="hsl(${hue}, 25%, 30%)">${brand}</text>
  <text x="60" y="90" font-family="Arial, sans-serif" font-size="26" fill="hsl(${hue}, 20%, 45%)">${label}</text>
</svg>`;
}

function bannerSvg(): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="600" viewBox="0 0 1600 600">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#17130f"/>
      <stop offset="1" stop-color="#3a2a1a"/>
    </linearGradient>
  </defs>
  <rect width="1600" height="600" fill="url(#g)"/>
  <circle cx="1280" cy="300" r="230" fill="#ff5100" opacity="0.16"/>
  <circle cx="1280" cy="300" r="150" fill="#ff5100" opacity="0.22"/>
  <rect x="1150" y="150" width="120" height="300" rx="14" fill="#f5f2ee" opacity="0.9"/>
  <rect x="1300" y="190" width="160" height="220" rx="14" fill="#f5f2ee" opacity="0.75"/>
  <circle cx="1380" cy="300" r="55" fill="#c9d4de"/>
</svg>`;
}

async function uploadSvg(svg: string, name: string): Promise<string> {
  const saved = await storage.uploadFile({
    fileContent: new TextEncoder().encode(svg),
    fileName: `seed/${name}`,
    contentType: "image/svg+xml",
  });
  return saved.key;
}

// ─── Справочники ────────────────────────────────────────────────────────────

const CATEGORIES: { nameRu: string; nameKg: string; icon: string; hue: number }[] = [
  { nameRu: "Холодильники", nameKg: "Муздаткычтар", icon: "fridge", hue: 205 },
  { nameRu: "Стиральные машины", nameKg: "Кир жуучу машиналар", icon: "washer", hue: 215 },
  { nameRu: "Телевизоры", nameKg: "Телевизорлор", icon: "tv", hue: 230 },
  { nameRu: "Пылесосы", nameKg: "Чаң соргучтар", icon: "vacuum", hue: 20 },
  { nameRu: "Кондиционеры", nameKg: "Кондитсионерлер", icon: "ac", hue: 190 },
  { nameRu: "Морозильные камеры", nameKg: "Тоңдургуч камералар", icon: "freezer", hue: 200 },
  { nameRu: "Микроволновые печи", nameKg: "Микротолкундуу мештер", icon: "microwave", hue: 30 },
  { nameRu: "Мелкая бытовая техника", nameKg: "Майда турак үй техникасы", icon: "small", hue: 150 },
];

const BRANDS = ["LG", "Samsung", "Haier", "Hisense", "Shivaki", "AVEST", "LEVO"];

const FILTERS: Record<string, { keySlug: string; labelRu: string; labelKg: string }[]> = {
  Холодильники: [
    { keySlug: "volume", labelRu: "Объём", labelKg: "Көлөмү" },
    { keySlug: "cooling", labelRu: "Тип охлаждения", labelKg: "Муздатуу түрү" },
    { keySlug: "freezer_pos", labelRu: "Расположение морозильной камеры", labelKg: "Тоңдургучтун жайгашышы" },
    { keySlug: "chambers", labelRu: "Количество камер", labelKg: "Камералардын саны" },
    { keySlug: "energy", labelRu: "Энергоэффективность", labelKg: "Энергия үнөмдүүлүгү" },
  ],
  Телевизоры: [
    { keySlug: "diagonal", labelRu: "Диагональ", labelKg: "Диагоналы" },
    { keySlug: "resolution", labelRu: "Разрешение", labelKg: "Ажыратымдуулугу" },
    { keySlug: "smart_tv", labelRu: "Smart TV", labelKg: "Smart TV" },
    { keySlug: "screen_type", labelRu: "Тип экрана", labelKg: "Экрандын түрү" },
  ],
  "Стиральные машины": [
    { keySlug: "load", labelRu: "Максимальная загрузка", labelKg: "Максималдуу жүктөө" },
    { keySlug: "engine", labelRu: "Тип двигателя", labelKg: "Мотордун түрү" },
    { keySlug: "spin", labelRu: "Скорость отжима", labelKg: "Кыскаруу ылдамдыгы" },
    { keySlug: "load_type", labelRu: "Тип загрузки", labelKg: "Жүктөө түрү" },
  ],
  Пылесосы: [
    { keySlug: "power", labelRu: "Мощность", labelKg: "Кубаты" },
    { keySlug: "vacuum_type", labelRu: "Тип пылесоса", labelKg: "Чаң соргучтун түрү" },
    { keySlug: "container", labelRu: "Объём контейнера", labelKg: "Контейнердин көлөмү" },
  ],
};

// ─── Демо-товары ────────────────────────────────────────────────────────────

type DemoSpec = { keySlug: string | null; keyRu: string; keyKg?: string; valueRu: string; valueKg?: string };
type DemoProduct = {
  nameRu: string;
  nameKg: string;
  category: string;
  brand: string;
  price: number;
  oldPrice?: number;
  warranty: string;
  isPopular?: boolean;
  isNew?: boolean;
  descriptionRu: string;
  descriptionKg: string;
  specs: DemoSpec[];
};

const DEMO_PRODUCTS: DemoProduct[] = [
  {
    nameRu: "Холодильник LG GA-B509", nameKg: "LG GA-B509 муздаткычы", category: "Холодильники", brand: "LG",
    price: 52990, oldPrice: 58990, warranty: "3 года", isPopular: true,
    descriptionRu: "Двухкамерный холодильник с системой No Frost и инверторным компрессором. Тихая работа и низкое энергопотребление.",
    descriptionKg: "No Frost системасы жана инвертордук компрессору бар эки камералуу муздаткыч. Үнсүз иштейт жана аз энергия жумшайт.",
    specs: [
      { keySlug: "volume", keyRu: "Объём", keyKg: "Көлөмү", valueRu: "384 л" },
      { keySlug: "cooling", keyRu: "Тип охлаждения", keyKg: "Муздатуу түрү", valueRu: "No Frost" },
      { keySlug: "freezer_pos", keyRu: "Расположение морозильной камеры", keyKg: "Тоңдургучтун жайгашышы", valueRu: "Снизу", valueKg: "Төмөндө" },
      { keySlug: "chambers", keyRu: "Количество камер", keyKg: "Камералардын саны", valueRu: "2" },
      { keySlug: "energy", keyRu: "Энергоэффективность", keyKg: "Энергия үнөмдүүлүгү", valueRu: "A++" },
    ],
  },
  {
    nameRu: "Холодильник Samsung RB37", nameKg: "Samsung RB37 муздаткычы", category: "Холодильники", brand: "Samsung",
    price: 56490, warranty: "3 года", isNew: true,
    descriptionRu: "Просторный холодильник с зоной свежести и цифровым инвертором. Гарантия на компрессор — 10 лет.",
    descriptionKg: "Жаңылык зонасы жана санариптик инвертору бар кеңири муздаткыч. Компрессорго кепилдик — 10 жыл.",
    specs: [
      { keySlug: "volume", keyRu: "Объём", keyKg: "Көлөмү", valueRu: "367 л" },
      { keySlug: "cooling", keyRu: "Тип охлаждения", keyKg: "Муздатуу түрү", valueRu: "No Frost" },
      { keySlug: "freezer_pos", keyRu: "Расположение морозильной камеры", keyKg: "Тоңдургучтун жайгашышы", valueRu: "Снизу", valueKg: "Төмөндө" },
      { keySlug: "chambers", keyRu: "Количество камер", keyKg: "Камералардын саны", valueRu: "2" },
      { keySlug: "energy", keyRu: "Энергоэффективность", keyKg: "Энергия үнөмдүүлүгү", valueRu: "A+" },
    ],
  },
  {
    nameRu: "Холодильник Haier C2F636", nameKg: "Haier C2F636 муздаткычы", category: "Холодильники", brand: "Haier",
    price: 47990, oldPrice: 51990, warranty: "2 года", isPopular: true,
    descriptionRu: "Надёжный холодильник с полкой из закалённого стекла и зоной нулевой температуры.",
    descriptionKg: "Быыштырылган айнек текчеси жана нөл температура зонасы бар ишенимдүү муздаткыч.",
    specs: [
      { keySlug: "volume", keyRu: "Объём", keyKg: "Көлөмү", valueRu: "339 л" },
      { keySlug: "cooling", keyRu: "Тип охлаждения", keyKg: "Муздатуу түрү", valueRu: "No Frost" },
      { keySlug: "freezer_pos", keyRu: "Расположение морозильной камеры", keyKg: "Тоңдургучтун жайгашышы", valueRu: "Сверху", valueKg: "Жогоруда" },
      { keySlug: "chambers", keyRu: "Количество камер", keyKg: "Камералардын саны", valueRu: "2" },
      { keySlug: "energy", keyRu: "Энергоэффективность", keyKg: "Энергия үнөмдүүлүгү", valueRu: "A+" },
    ],
  },
  {
    nameRu: "Стиральная машина LG F2J3", nameKg: "LG F2J3 кир жуучу машинасы", category: "Стиральные машины", brand: "LG",
    price: 36990, oldPrice: 41990, warranty: "2 года", isPopular: true,
    descriptionRu: "Узкая стиральная машина с прямым приводом и паровой обработкой. 6 движений барабана под разные ткани.",
    descriptionKg: "Түз жетеги жана буу менен иштетүүсү бар тар кир жуучу машина. Ар кандай кездемелер үчүн барабандын 6 кыймылы.",
    specs: [
      { keySlug: "load", keyRu: "Максимальная загрузка", keyKg: "Максималдуу жүктөө", valueRu: "6.5 кг" },
      { keySlug: "engine", keyRu: "Тип двигателя", keyKg: "Мотордун түрү", valueRu: "Инверторный", valueKg: "Инвертордук" },
      { keySlug: "spin", keyRu: "Скорость отжима", keyKg: "Кыскаруу ылдамдыгы", valueRu: "1200 об/мин" },
      { keySlug: "load_type", keyRu: "Тип загрузки", keyKg: "Жүктөө түрү", valueRu: "Фронтальная", valueKg: "Фронталдык" },
    ],
  },
  {
    nameRu: "Стиральная машина Samsung WW65", nameKg: "Samsung WW65 кир жуучу машинасы", category: "Стиральные машины", brand: "Samsung",
    price: 33990, warranty: "2 года",
    descriptionRu: "Технология Eco Bubble: пена растворяет моющее средство и бережно очищает ткань даже в холодной воде.",
    descriptionKg: "Eco Bubble технологиясы: көбүк жуугуч каражатты эритип, муздак суда да кездемени аяр тазалайт.",
    specs: [
      { keySlug: "load", keyRu: "Максимальная загрузка", keyKg: "Максималдуу жүктөө", valueRu: "6.5 кг" },
      { keySlug: "engine", keyRu: "Тип двигателя", keyKg: "Мотордун түрү", valueRu: "Коллекторный", valueKg: "Коллектордук" },
      { keySlug: "spin", keyRu: "Скорость отжима", keyKg: "Кыскаруу ылдамдыгы", valueRu: "1000 об/мин" },
      { keySlug: "load_type", keyRu: "Тип загрузки", keyKg: "Жүктөө түрү", valueRu: "Фронтальная", valueKg: "Фронталдык" },
    ],
  },
  {
    nameRu: "Телевизор Samsung 55\" Crystal UHD", nameKg: "Samsung 55\" Crystal UHD телевизору", category: "Телевизоры", brand: "Samsung",
    price: 48990, oldPrice: 56990, warranty: "1 год", isPopular: true, isNew: true,
    descriptionRu: "4K-телевизор с процессором Crystal 4K и поддержкой HDR. Smart TV с популярными онлайн-кинотеатрами.",
    descriptionKg: "Crystal 4K процессору жана HDR колдоосу бар 4K телевизор. Популярдуу онлайн кинотеатрлары бар Smart TV.",
    specs: [
      { keySlug: "diagonal", keyRu: "Диагональ", keyKg: "Диагоналы", valueRu: "55\"" },
      { keySlug: "resolution", keyRu: "Разрешение", keyKg: "Ажыратымдуулугу", valueRu: "4K UHD" },
      { keySlug: "smart_tv", keyRu: "Smart TV", valueRu: "Да", valueKg: "Ооба" },
      { keySlug: "screen_type", keyRu: "Тип экрана", keyKg: "Экрандын түрү", valueRu: "LED" },
    ],
  },
  {
    nameRu: "Телевизор Hisense 43\" FHD", nameKg: "Hisense 43\" FHD телевизору", category: "Телевизоры", brand: "Hisense",
    price: 21990, warranty: "1 год", isNew: true,
    descriptionRu: "Компактный Full HD телевизор для кухни или спальни. Энергоэффективная LED-подсветка.",
    descriptionKg: "Ашкана же уктоочу бөлмө үчүн компакттуу Full HD телевизор. Энергияны үнөмдөгөн LED жарыктандыруу.",
    specs: [
      { keySlug: "diagonal", keyRu: "Диагональ", keyKg: "Диагоналы", valueRu: "43\"" },
      { keySlug: "resolution", keyRu: "Разрешение", keyKg: "Ажыратымдуулугу", valueRu: "Full HD" },
      { keySlug: "smart_tv", keyRu: "Smart TV", valueRu: "Нет", valueKg: "Жок" },
      { keySlug: "screen_type", keyRu: "Тип экрана", keyKg: "Экрандын түрү", valueRu: "LED" },
    ],
  },
  {
    nameRu: "Пылесос Samsung VC18M21", nameKg: "Samsung VC18M21 чаң соргучу", category: "Пылесосы", brand: "Samsung",
    price: 8990, oldPrice: 10990, warranty: "1 год", isPopular: true,
    descriptionRu: "Циклонный пылесос без мешка с контейнером 1.5 л. Легко моется, компактно хранится.",
    descriptionKg: "1,5 л контейнеру бар баштыксыз циклондук чаң соргуч. Оңой жуулат, ырааттуу сакталат.",
    specs: [
      { keySlug: "power", keyRu: "Мощность", keyKg: "Кубаты", valueRu: "1800 Вт" },
      { keySlug: "vacuum_type", keyRu: "Тип пылесоса", keyKg: "Чаң соргучтун түрү", valueRu: "Циклонный", valueKg: "Циклондук" },
      { keySlug: "container", keyRu: "Объём контейнера", keyKg: "Контейнердин көлөмү", valueRu: "1.5 л" },
    ],
  },
  {
    nameRu: "Кондиционер Shivaki SSH-I099BE", nameKg: "Shivaki SSH-I099BE кондиционери", category: "Кондиционеры", brand: "Shivaki",
    price: 24990, oldPrice: 27990, warranty: "2 года", isPopular: true,
    descriptionRu: "Сплит-система на площадь до 26 м². Режимы охлаждения и обогрева, ночной режим.",
    descriptionKg: "26 м² чейинки аянтка сплит-система. Муздатуу жана жылуутуу режимдери, түнкү режим.",
    specs: [
      { keySlug: null, keyRu: "Площадь помещения", keyKg: "Бөлмөнүн аянты", valueRu: "до 26 м²" },
      { keySlug: null, keyRu: "Режимы", keyKg: "Режимдер", valueRu: "Охлаждение / обогрев", valueKg: "Муздатуу / жылуутуу" },
    ],
  },
  {
    nameRu: "Морозильная камера AVEST AV-180", nameKg: "AVEST AV-180 тоңдургуч камерасы", category: "Морозильные камеры", brand: "AVEST",
    price: 18990, warranty: "1 год",
    descriptionRu: "Вертикальная морозильная камера на 180 литров с 6 отделениями. Замораживание до −24°C.",
    descriptionKg: "6 бөлүмү бар 180 литрлик вертикалдык тоңдургуч камера. −24°C чейин тоңдурат.",
    specs: [
      { keySlug: null, keyRu: "Объём", keyKg: "Көлөмү", valueRu: "180 л" },
      { keySlug: null, keyRu: "Количество отделений", keyKg: "Бөлүмдөрдүн саны", valueRu: "6" },
    ],
  },
  {
    nameRu: "Микроволновая печь LEVO LM-2001", nameKg: "LEVO LM-2001 микротолкундуу меши", category: "Микроволновые печи", brand: "LEVO",
    price: 6490, oldPrice: 7990, warranty: "1 год", isNew: true,
    descriptionRu: "Соло-микроволновка на 20 литров с механическим управлением. Быстрый разогрев и разморозка.",
    descriptionKg: "Механикалык башкаруусу бар 20 литрлик соло микротолкундуу меш. Тез жылуулаштыруу жана эритүү.",
    specs: [
      { keySlug: null, keyRu: "Объём", keyKg: "Көлөмү", valueRu: "20 л" },
      { keySlug: null, keyRu: "Мощность", keyKg: "Кубаты", valueRu: "700 Вт" },
    ],
  },
  {
    nameRu: "Чайник LEVO LK-118", nameKg: "LEVO LK-118 чайнеги", category: "Мелкая бытовая техника", brand: "LEVO",
    price: 1490, warranty: "6 месяцев",
    descriptionRu: "Электрочайник 1.8 л с автоотключением и фильтром от накипи.",
    descriptionKg: "1,8 л электр чайнек, автоөчүү жана казак чыпкасы менен.",
    specs: [
      { keySlug: null, keyRu: "Объём", keyKg: "Көлөмү", valueRu: "1.8 л" },
      { keySlug: null, keyRu: "Мощность", keyKg: "Кубаты", valueRu: "1500 Вт" },
    ],
  },
];

// ─── Seed ───────────────────────────────────────────────────────────────────

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // 1. Администратор
  const existingAdmin = await db.query.admins.findFirst();
  if (!existingAdmin) {
    const password = process.env.ADMIN_PASSWORD || "admin12345";
    await db.insert(admins).values({
      username: "admin",
      passwordHash: await bcrypt.hash(password, 10),
    });
    console.log(`Создан администратор: admin / ${process.env.ADMIN_PASSWORD ? "(из ADMIN_PASSWORD)" : "admin12345 — СМЕНИТЕ ПАРОЛЬ!"}`);
  } else {
    console.log("Администратор уже существует, пропуск.");
  }

  // 2. Справочники — только если пусто
  const existingCats = await db.select().from(categories).limit(1);
  if (existingCats.length > 0) {
    console.log("Каталог уже заполнен, seed справочников пропущен.");
    process.exit(0);
  }

  const catIds = new Map<string, number>();
  for (const [i, c] of CATEGORIES.entries()) {
    const [res] = await db.insert(categories).values({
      nameRu: c.nameRu,
      nameKg: c.nameKg,
      slug: slugify(c.nameRu),
      sortOrder: i,
    });
    catIds.set(c.nameRu, Number(res.insertId));
  }
  console.log(`Категории: ${catIds.size}`);

  const brandIds = new Map<string, number>();
  for (const [i, name] of BRANDS.entries()) {
    const [res] = await db.insert(brands).values({
      name,
      slug: slugify(name),
      sortOrder: i,
      isPopular: ["LG", "Samsung", "Haier"].includes(name),
    });
    brandIds.set(name, Number(res.insertId));
  }
  console.log(`Бренды: ${brandIds.size}`);

  for (const [catName, defs] of Object.entries(FILTERS)) {
    const catId = catIds.get(catName);
    if (!catId) continue;
    for (const [i, f] of defs.entries()) {
      await db.insert(categoryFilters).values({
        categoryId: catId,
        keySlug: f.keySlug,
        labelRu: f.labelRu,
        labelKg: f.labelKg,
        sortOrder: i,
      });
    }
  }
  console.log("Фильтры категорий созданы.");

  // 3. Демо-товары с изображениями
  const catMeta = new Map(CATEGORIES.map((c) => [c.nameRu, c]));
  for (const p of DEMO_PRODUCTS) {
    const cat = catMeta.get(p.category)!;
    const svg = productSvg(APPLIANCE_ICONS[cat.icon], cat.hue, p.brand, p.category);
    let imageKey: string | null = null;
    try {
      imageKey = await uploadSvg(svg, `${slugify(p.nameRu)}.svg`);
    } catch (e) {
      console.warn(`Не удалось загрузить изображение для "${p.nameRu}":`, e);
    }
    const [res] = await db.insert(products).values({
      nameRu: p.nameRu,
      nameKg: p.nameKg,
      slug: slugify(p.nameRu),
      descriptionRu: p.descriptionRu,
      descriptionKg: p.descriptionKg,
      categoryId: catIds.get(p.category)!,
      brandId: brandIds.get(p.brand)!,
      price: p.price,
      oldPrice: p.oldPrice ?? null,
      warranty: p.warranty,
      inStock: true,
      isPopular: p.isPopular ?? false,
      isNew: p.isNew ?? false,
    });
    const productId = Number(res.insertId);
    if (imageKey) {
      await db.insert(productImages).values({ productId, storageKey: imageKey, sortOrder: 0 });
    }
    for (const [i, s] of p.specs.entries()) {
      await db.insert(productSpecs).values({
        productId,
        keySlug: s.keySlug,
        keyRu: s.keyRu,
        keyKg: s.keyKg ?? null,
        valueRu: s.valueRu,
        valueKg: s.valueKg ?? null,
        sortOrder: i,
      });
    }
  }
  console.log(`Демо-товары: ${DEMO_PRODUCTS.length}`);

  // 4. Демо-баннер
  try {
    const key = await uploadSvg(bannerSvg(), "banner-main.svg");
    await db.insert(banners).values({
      titleRu: "Бытовая техника с доставкой по Ошу",
      titleKg: "Ош боюнча жеткирүү менен турак үй техникасы",
      subtitleRu: "Бесплатная доставка по городу Ош · Гарантия на всю технику",
      subtitleKg: "Ош шаары боюнча бекер жеткирүү · Бардык техникага кепилдик",
      buttonTextRu: "Смотреть каталог",
      buttonTextKg: "Каталогду көрүү",
      imageKey: key,
      linkUrl: "/catalog",
      sortOrder: 0,
    });
    console.log("Демо-баннер создан.");
  } catch (e) {
    console.warn("Баннер не загружен:", e);
  }

  // 5. Демо-отзывы (одобренные)
  const firstProducts = await db.select().from(products).limit(3);
  const demoReviews = [
    { authorName: "Айгерим", rating: 5, text: "Заказала холодильник, привезли на следующий день. Всё работает отлично, спасибо!" },
    { authorName: "Бакыт", rating: 5, text: "Хороший магазин, помогли с выбором стиральной машины. Цены адекватные." },
    { authorName: "Нурсултан", rating: 4, text: "Доставили вовремя, техника новая с гарантией. Рекомендую." },
  ];
  for (const [i, r] of demoReviews.entries()) {
    const product = firstProducts[i % firstProducts.length];
    if (!product) break;
    await db.insert(reviews).values({
      productId: product.id,
      authorName: r.authorName,
      rating: r.rating,
      text: r.text,
      status: "approved",
    });
  }
  console.log("Демо-отзывы созданы.");
  console.log("Done.");
  process.exit(0);
}

seed().catch((e) => {
  console.error(e);
  process.exit(1);
});
