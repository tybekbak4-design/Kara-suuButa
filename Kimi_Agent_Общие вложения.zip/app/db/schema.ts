import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  int,
  boolean,
  timestamp,
  bigint,
  uniqueIndex,
  index,
} from "drizzle-orm/mysql-core";

// ─── Администраторы и сессии ────────────────────────────────────────────────

export const admins = mysqlTable("admins", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const adminSessions = mysqlTable(
  "admin_sessions",
  {
    token: varchar("token", { length: 128 }).primaryKey(),
    adminId: bigint("admin_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => admins.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    expiresAt: timestamp("expires_at").notNull(),
  },
  (t) => [index("idx_admin_sessions_admin").on(t.adminId)],
);

// ─── Каталог ────────────────────────────────────────────────────────────────

export const categories = mysqlTable(
  "categories",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 160 }).notNull().unique(),
    nameRu: varchar("name_ru", { length: 255 }).notNull(),
    nameKg: varchar("name_kg", { length: 255 }),
    sortOrder: int("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_categories_sort").on(t.sortOrder)],
);

export const brands = mysqlTable(
  "brands",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 160 }).notNull().unique(),
    name: varchar("name", { length: 255 }).notNull(),
    logoUrl: text("logo_url"),
    logoKey: varchar("logo_key", { length: 512 }),
    sortOrder: int("sort_order").notNull().default(0),
    isPopular: boolean("is_popular").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_brands_sort").on(t.sortOrder)],
);

export const products = mysqlTable(
  "products",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 200 }).notNull().unique(),
    nameRu: varchar("name_ru", { length: 500 }).notNull(),
    nameKg: varchar("name_kg", { length: 500 }),
    descriptionRu: text("description_ru"),
    descriptionKg: text("description_kg"),
    categoryId: bigint("category_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => categories.id),
    brandId: bigint("brand_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => brands.id),
    price: int("price").notNull(), // в сомах, целое число
    oldPrice: int("old_price"),
    warranty: varchar("warranty", { length: 255 }),
    inStock: boolean("in_stock").notNull().default(true),
    isPopular: boolean("is_popular").notNull().default(false),
    isNew: boolean("is_new").notNull().default(false),
    isHidden: boolean("is_hidden").notNull().default(false),
    views: int("views").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
  },
  (t) => [
    index("idx_products_category").on(t.categoryId),
    index("idx_products_brand").on(t.brandId),
    index("idx_products_price").on(t.price),
    index("idx_products_flags").on(t.isHidden, t.inStock),
  ],
);

export const productImages = mysqlTable(
  "product_images",
  {
    id: serial("id").primaryKey(),
    productId: bigint("product_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    // Либо загруженный файл (storage key), либо внешняя ссылка
    storageKey: varchar("storage_key", { length: 512 }),
    externalUrl: text("external_url"),
    sortOrder: int("sort_order").notNull().default(0),
  },
  (t) => [index("idx_product_images_product").on(t.productId)],
);

export const productSpecs = mysqlTable(
  "product_specs",
  {
    id: serial("id").primaryKey(),
    productId: bigint("product_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    // slug ключа — для фильтров (например "volume", "diagonal"); может быть пустым
    keySlug: varchar("key_slug", { length: 120 }),
    keyRu: varchar("key_ru", { length: 255 }).notNull(),
    keyKg: varchar("key_kg", { length: 255 }),
    valueRu: varchar("value_ru", { length: 500 }).notNull(),
    valueKg: varchar("value_kg", { length: 500 }),
    sortOrder: int("sort_order").notNull().default(0),
  },
  (t) => [
    index("idx_specs_product").on(t.productId),
    index("idx_specs_key").on(t.keySlug, t.valueRu),
  ],
);

// Определения фильтров характеристик по категориям
export const categoryFilters = mysqlTable(
  "category_filters",
  {
    id: serial("id").primaryKey(),
    categoryId: bigint("category_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => categories.id, { onDelete: "cascade" }),
    keySlug: varchar("key_slug", { length: 120 }).notNull(),
    labelRu: varchar("label_ru", { length: 255 }).notNull(),
    labelKg: varchar("label_kg", { length: 255 }),
    sortOrder: int("sort_order").notNull().default(0),
  },
  (t) => [
    uniqueIndex("uq_category_filter").on(t.categoryId, t.keySlug),
  ],
);

// ─── Отзывы ─────────────────────────────────────────────────────────────────

export const reviews = mysqlTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    productId: bigint("product_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    authorName: varchar("author_name", { length: 255 }).notNull(),
    rating: int("rating").notNull(), // 1..5
    text: text("text").notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"])
      .notNull()
      .default("pending"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("idx_reviews_product").on(t.productId, t.status),
    index("idx_reviews_status").on(t.status),
  ],
);

// ─── Баннеры ────────────────────────────────────────────────────────────────

export const banners = mysqlTable(
  "banners",
  {
    id: serial("id").primaryKey(),
    titleRu: varchar("title_ru", { length: 500 }).notNull(),
    titleKg: varchar("title_kg", { length: 500 }),
    subtitleRu: varchar("subtitle_ru", { length: 500 }),
    subtitleKg: varchar("subtitle_kg", { length: 500 }),
    buttonTextRu: varchar("button_text_ru", { length: 255 }),
    buttonTextKg: varchar("button_text_kg", { length: 255 }),
    imageKey: varchar("image_key", { length: 512 }),
    imageUrl: text("image_url"),
    linkUrl: varchar("link_url", { length: 1000 }),
    bgColor: varchar("bg_color", { length: 32 }),
    sortOrder: int("sort_order").notNull().default(0),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_banners_sort").on(t.sortOrder)],
);

// ─── Настройки сайта (key-value, value = JSON) ─────────────────────────────

export const settings = mysqlTable("settings", {
  key: varchar("key", { length: 120 }).primaryKey(),
  value: text("value"),
});

// ─── Статистика ─────────────────────────────────────────────────────────────

export const statsEvents = mysqlTable(
  "stats_events",
  {
    id: serial("id").primaryKey(),
    type: mysqlEnum("type", [
      "visit",
      "product_view",
      "whatsapp_click",
      "phone_click",
    ]).notNull(),
    productId: bigint("product_id", { mode: "number", unsigned: true }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("idx_stats_type").on(t.type, t.createdAt),
    index("idx_stats_product").on(t.productId),
  ],
);

// ─── Сохранённые маппинги импорта Excel ─────────────────────────────────────

export const importMappings = mysqlTable("import_mappings", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  mapping: text("mapping").notNull(), // JSON: { excelColumn: productField }
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Типы ───────────────────────────────────────────────────────────────────

export type Admin = typeof admins.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Brand = typeof brands.$inferSelect;
export type Product = typeof products.$inferSelect;
export type ProductImage = typeof productImages.$inferSelect;
export type ProductSpec = typeof productSpecs.$inferSelect;
export type CategoryFilter = typeof categoryFilters.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Banner = typeof banners.$inferSelect;
export type StatsEvent = typeof statsEvents.$inferSelect;
export type ImportMapping = typeof importMappings.$inferSelect;
