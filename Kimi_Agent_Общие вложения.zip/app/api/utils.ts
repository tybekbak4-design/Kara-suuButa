// Вспомогательные функции backend: slugify, работа с изображениями
import { storage } from "./lib/storage";
import type { ProductImage } from "../db/schema";

const CYRILLIC_MAP: Record<string, string> = {
  а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "yo", ж: "zh",
  з: "z", и: "i", й: "j", к: "k", л: "l", м: "m", н: "n", о: "o",
  п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "h", ц: "c",
  ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu",
  я: "ya", ө: "o", ү: "u", ң: "n", ї: "i", є: "e",
};

export function slugify(text: string): string {
  const transliterated = text
    .toLowerCase()
    .split("")
    .map((ch) => CYRILLIC_MAP[ch] ?? ch)
    .join("");
  return transliterated
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 180) || "item";
}

export async function uniqueSlug(
  base: string,
  exists: (slug: string) => Promise<boolean>,
): Promise<string> {
  const root = slugify(base);
  let candidate = root;
  let i = 2;
  while (await exists(candidate)) {
    candidate = `${root}-${i}`;
    i += 1;
  }
  return candidate;
}

export function isValidHttpUrl(value: string): boolean {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

/** Превращает строки product_images в URL для браузера (presigned для storage-ключей). */
export async function resolveImageUrls(
  images: Pick<ProductImage, "id" | "storageKey" | "externalUrl" | "sortOrder">[],
): Promise<{ id: number; url: string; sortOrder: number }[]> {
  const keys = images
    .map((img) => img.storageKey)
    .filter((k): k is string => Boolean(k));
  const urlByKey = new Map<string, string>();
  if (keys.length > 0) {
    try {
      const { urls } = await storage.getPresignedUrls({ keys });
      for (const r of urls) {
        if (r?.key && r?.url) urlByKey.set(r.key, r.url);
      }
    } catch {
      // хранилище недоступно — отдаём что есть (внешние ссылки)
    }
  }
  return images
    .map((img) => ({
      id: img.id,
      sortOrder: img.sortOrder,
      url: img.storageKey
        ? (urlByKey.get(img.storageKey) ?? "")
        : (img.externalUrl ?? ""),
    }))
    .filter((img) => img.url.length > 0)
    .sort((a, b) => a.sortOrder - b.sortOrder);
}

/** Один ключ/URL → URL (для логотипов, баннеров). */
export async function resolveOne(
  storageKey: string | null,
  externalUrl: string | null,
): Promise<string> {
  if (storageKey) {
    try {
      const { url } = await storage.getPresignedUrl({ key: storageKey });
      return url;
    } catch {
      return "";
    }
  }
  return externalUrl ?? "";
}
