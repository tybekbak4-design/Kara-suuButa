// SEO-маршруты: sitemap.xml и robots.txt (динамические, из БД)
import { Hono } from "hono";
import { eq } from "drizzle-orm";
import { getDb } from "../queries/connection";
import { categories, products } from "../../db/schema";
import { getSettingsMap } from "../routers/public";

export const seoRoutes = new Hono();

function baseUrl(c: { req: { url: string; header: (n: string) => string | undefined } }): string {
  const proto = c.req.header("x-forwarded-proto") ?? "https";
  const host = c.req.header("x-forwarded-host") ?? c.req.header("host") ?? new URL(c.req.url).host;
  return `${proto}://${host}`;
}

seoRoutes.get("/sitemap.xml", async (c) => {
  const db = getDb();
  const base = baseUrl(c);
  const [cats, prods] = await Promise.all([
    db.select({ slug: categories.slug }).from(categories),
    db
      .select({ slug: products.slug, updatedAt: products.updatedAt })
      .from(products)
      .where(eq(products.isHidden, false)),
  ]);
  const urls: string[] = [
    `<url><loc>${base}/</loc><changefreq>daily</changefreq></url>`,
    `<url><loc>${base}/catalog</loc><changefreq>daily</changefreq></url>`,
  ];
  for (const cat of cats) {
    urls.push(`<url><loc>${base}/catalog/${cat.slug}</loc><changefreq>weekly</changefreq></url>`);
  }
  for (const p of prods) {
    const lastmod = p.updatedAt.toISOString().slice(0, 10);
    urls.push(`<url><loc>${base}/product/${p.slug}</loc><lastmod>${lastmod}</lastmod></url>`);
  }
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`;
  return c.body(xml, 200, { "Content-Type": "application/xml; charset=utf-8" });
});

seoRoutes.get("/robots.txt", async (c) => {
  const base = baseUrl(c);
  const body = `User-agent: *\nAllow: /\nDisallow: /admin\n\nSitemap: ${base}/sitemap.xml\n`;
  return c.body(body, 200, { "Content-Type": "text/plain; charset=utf-8" });
});

// Open Graph для страниц товара: подмена meta в index.html при продакшн-отдаче
export async function buildOgHtml(
  templateHtml: string,
  productSlug: string,
  base: string,
): Promise<string | null> {
  const db = getDb();
  const product = await db.query.products.findFirst({
    where: eq(products.slug, productSlug),
  });
  if (!product || product.isHidden) return null;
  const settings = await getSettingsMap();
  const title = `${product.nameRu} — ${settings.site_name_ru}`;
  const description =
    product.descriptionRu?.slice(0, 200) || settings.seo_description_ru;
  const url = `${base}/product/${product.slug}`;
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
  const tags = [
    `<title>${esc(title)}</title>`,
    `<meta name="description" content="${esc(description)}" data-og="1" />`,
    `<meta property="og:title" content="${esc(title)}" />`,
    `<meta property="og:description" content="${esc(description)}" />`,
    `<meta property="og:type" content="product" />`,
    `<meta property="og:url" content="${esc(url)}" />`,
    `<meta property="og:locale" content="ru_KG" />`,
    `<meta property="og:locale:alternate" content="ky_KG" />`,
  ].join("\n    ");
  return templateHtml
    .replace(/<meta name="description"[^>]*\/?>/, "")
    .replace(/<title>.*?<\/title>/s, tags);
}
