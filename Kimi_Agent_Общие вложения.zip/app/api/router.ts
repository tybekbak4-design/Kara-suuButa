import { createRouter, publicQuery } from "./middleware";
import { publicRouter } from "./routers/public";
import { adminRouter } from "./routers/admin";
import { excelRouter } from "./routers/excel";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  catalog: publicRouter,
  admin: adminRouter,
  excel: excelRouter,
});

export type AppRouter = typeof appRouter;
