// Серверная авторизация администратора: bcrypt + сессии в БД
import { TRPCError } from "@trpc/server";
import { eq, gt, and } from "drizzle-orm";
import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { getDb } from "./queries/connection";
import { admins, adminSessions } from "../db/schema";
import { publicQuery } from "./middleware";
import type { TrpcContext } from "./context";

const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14; // 14 дней

export async function verifyCredentials(
  username: string,
  password: string,
): Promise<{ id: number; username: string } | null> {
  const db = getDb();
  const admin = await db.query.admins.findFirst({
    where: eq(admins.username, username),
  });
  if (!admin) {
    // выравниваем время ответа
    await bcrypt.compare(password, "$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalid12");
    return null;
  }
  const ok = await bcrypt.compare(password, admin.passwordHash);
  if (!ok) return null;
  return { id: admin.id, username: admin.username };
}

export async function createSession(adminId: number): Promise<string> {
  const token = crypto.randomBytes(48).toString("hex");
  await getDb().insert(adminSessions).values({
    token,
    adminId,
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  });
  return token;
}

export async function destroySession(token: string): Promise<void> {
  await getDb().delete(adminSessions).where(eq(adminSessions.token, token));
}

export async function getAdminByToken(
  token: string,
): Promise<{ id: number; username: string } | null> {
  const db = getDb();
  const rows = await db
    .select({ admin: admins })
    .from(adminSessions)
    .innerJoin(admins, eq(adminSessions.adminId, admins.id))
    .where(
      and(
        eq(adminSessions.token, token),
        gt(adminSessions.expiresAt, new Date()),
      ),
    )
    .limit(1);
  return rows[0]?.admin ?? null;
}

export function tokenFromCtx(ctx: TrpcContext): string | null {
  const header = ctx.req.headers.get("authorization");
  if (!header) return null;
  const [scheme, value] = header.split(" ");
  if (scheme?.toLowerCase() !== "bearer" || !value) return null;
  return value;
}

/** Процедура, требующая авторизованного администратора. ctx.admin гарантирован. */
export const adminProcedure = publicQuery.use(async ({ ctx, next }) => {
  const token = tokenFromCtx(ctx);
  if (!token) throw new TRPCError({ code: "UNAUTHORIZED" });
  const admin = await getAdminByToken(token);
  if (!admin) throw new TRPCError({ code: "UNAUTHORIZED" });
  return next({ ctx: { ...ctx, admin, adminToken: token } });
});

export async function createAdmin(
  username: string,
  password: string,
): Promise<void> {
  const hash = await bcrypt.hash(password, 10);
  await getDb().insert(admins).values({ username, passwordHash: hash });
}
