// Импорт товаров из Excel (.xlsx/.xls): превью, валидация, дубликаты, отчёт
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as XLSX from "xlsx";
import { eq, sql } from "drizzle-orm";
import { createRouter } from "../middleware";
import { adminProcedure } from "../adminAuth";
import { getDb } from "../queries/connection";
import {
  brands,
  categories,
  categoryFilters,
  products,
  productImages,
  productSpecs,
} from "../../db/schema";
import { isValidHttpUrl, slugify, uniqueSlug } from "../utils";
import { IMPORT_FIELDS, REQUIRED_IMPORT_FIELDS, type ImportField } from "../../contracts/types";

const fileInput = z.object({
  fileName: z.string().min(1).max(300),
  contentBase64: z.string().max(30 * 1024 * 1024), // ~20 МБ
});

type Row = Record<string, unknown>;

function parseWorkbook(contentBase64: string): { headers: string[]; rows: Row[] } {
  const buf = Buffer.from(contentBase64, "base64");
  const wb = XLSX.read(buf, { type: "buffer" });
  const sheetName = wb.SheetNames[0];
  if (!sheetName) throw new TRPCError({ code: "BAD_REQUEST", message: "В файле нет листов" });
  const sheet = wb.Sheets[sheetName];
  const json = XLSX.utils.sheet_to_json<Row>(sheet, { defval: "" });
  if (json.length === 0) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Лист пустой" });
  }
  const headers = Object.keys(json[0]);
  return { headers, rows: json };
}

// Автоподбор соответствия столбцов известным полям
const FIELD_HINTS: Record<ImportField, string[]> = {
  nameRu: ["название ru", "название товара ru", "название", "наименование", "name ru", "товар"],
  nameKg: ["название kg", "название товара kg", "name kg", "название кг"],
  slug: ["slug", "чпу"],
  category: ["категория", "category"],
  brand: ["бренд", "производитель", "brand", "марка"],
  price: ["цена", "price", "стоимость"],
  oldPrice: ["старая цена", "old price", "цена до скидки", "скидка цена"],
  warranty: ["гарантия", "warranty"],
  inStock: ["наличие", "in stock", "в наличии", "остаток"],
  descriptionRu: ["описание ru", "описание", "description ru"],
  descriptionKg: ["описание kg", "description kg", "описание кг"],
  specs: ["характеристики", "specs", "свойства"],
  imageUrl: ["ссылка на фотографию", "фото", "изображение", "image", "photo", "ссылка на фото"],
  additionalImages: ["дополнительные фотографии", "доп фото", "доп. фото", "additional images", "фото 2"],
  isPopular: ["популярный", "popular", "хит"],
  isNew: ["новинка", "new", "новый"],
};

function suggestMapping(headers: string[]): Record<string, ImportField | ""> {
  const mapping: Record<string, ImportField | ""> = {};
  const used = new Set<ImportField>();
  for (const header of headers) {
    const normalized = header.trim().toLowerCase();
    let found: ImportField | "" = "";
    for (const field of IMPORT_FIELDS) {
      if (used.has(field)) continue;
      if (FIELD_HINTS[field].some((hint) => normalized === hint || normalized.includes(hint))) {
        found = field;
        used.add(field);
        break;
      }
    }
    mapping[header] = found;
  }
  return mapping;
}

const mappingSchema = z.record(z.string(), z.string());

function cell(row: Row, mapping: Record<string, string>, field: ImportField): string {
  for (const [col, f] of Object.entries(mapping)) {
    if (f === field) {
      const v = row[col];
      return v == null ? "" : String(v).trim();
    }
  }
  return "";
}

function parseBool(v: string, fallback: boolean): boolean {
  if (!v) return fallback;
  const s = v.toLowerCase();
  if (["1", "да", "yes", "true", "в наличии", "+"].includes(s)) return true;
  if (["0", "нет", "no", "false", "-"].includes(s)) return false;
  return fallback;
}

function parsePrice(v: string): number | null {
  if (!v) return null;
  const n = Number(v.replace(/[\s ]/g, "").replace(",", "."));
  if (!Number.isFinite(n) || n < 0) return null;
  return Math.round(n);
}

function splitUrls(v: string): string[] {
  return v
    .split(/[;,\n]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export const excelRouter = createRouter({
  preview: adminProcedure.input(fileInput).mutation(async ({ input }) => {
    if (!/\.(xlsx|xls)$/i.test(input.fileName)) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Поддерживаются только .xlsx и .xls" });
    }
    const { headers, rows } = parseWorkbook(input.contentBase64);
    return {
      headers,
      totalRows: rows.length,
      previewRows: rows.slice(0, 20),
      suggestedMapping: suggestMapping(headers),
      fields: IMPORT_FIELDS,
      requiredFields: REQUIRED_IMPORT_FIELDS,
    };
  }),

  import: adminProcedure
    .input(
      fileInput.extend({
        mapping: mappingSchema,
        duplicateMode: z.enum(["skip", "update"]),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { rows } = parseWorkbook(input.contentBase64);
      const mapping = input.mapping as Record<string, ImportField | "">;
      const mappedFields = new Set(Object.values(mapping).filter(Boolean));
      const missing = REQUIRED_IMPORT_FIELDS.filter((f) => !mappedFields.has(f));
      if (missing.length > 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Не сопоставлены обязательные поля: ${missing.join(", ")}`,
        });
      }

      const report = {
        created: 0,
        updated: 0,
        skipped: 0,
        createdBrands: [] as string[],
        createdCategories: [] as string[],
        errors: [] as { row: number; message: string }[],
      };

      const catRows = await db.select().from(categories);
      const brandRows = await db.select().from(brands);
      const catByName = new Map(catRows.map((c) => [c.nameRu.toLowerCase(), c]));
      for (const c of catRows) if (c.nameKg) catByName.set(c.nameKg.toLowerCase(), c);
      const brandByName = new Map(brandRows.map((b) => [b.name.toLowerCase(), b]));

      const seenInFile = new Set<string>();

      for (const [i, row] of rows.entries()) {
        const rowNum = i + 2; // Excel-строка (1 = заголовок)
        try {
          const nameRu = cell(row, mapping, "nameRu");
          if (!nameRu) throw new Error("Пустое название товара");
          const categoryName = cell(row, mapping, "category");
          if (!categoryName) throw new Error("Пустая категория");
          const price = parsePrice(cell(row, mapping, "price"));
          if (price == null) throw new Error("Некорректная цена");
          const oldPriceRaw = cell(row, mapping, "oldPrice");
          const oldPrice = oldPriceRaw ? parsePrice(oldPriceRaw) : null;
          if (oldPriceRaw && oldPrice == null) throw new Error("Некорректная старая цена");

          const brandName = cell(row, mapping, "brand") || "Без бренда";
          let brand = brandByName.get(brandName.toLowerCase());
          if (!brand) {
            const slug = await uniqueSlug(brandName, async (s) =>
              Boolean(await db.query.brands.findFirst({ where: eq(brands.slug, s) })),
            );
            const [res] = await db.insert(brands).values({ name: brandName, slug });
            brand = (await db.query.brands.findFirst({ where: eq(brands.id, Number(res.insertId)) }))!;
            brandByName.set(brandName.toLowerCase(), brand);
            report.createdBrands.push(brandName);
          }

          let category = catByName.get(categoryName.toLowerCase());
          if (!category) {
            const slug = await uniqueSlug(categoryName, async (s) =>
              Boolean(await db.query.categories.findFirst({ where: eq(categories.slug, s) })),
            );
            const [res] = await db.insert(categories).values({ nameRu: categoryName, slug });
            category = (await db.query.categories.findFirst({ where: eq(categories.id, Number(res.insertId)) }))!;
            catByName.set(categoryName.toLowerCase(), category);
            report.createdCategories.push(categoryName);
          }

          // Проверка ссылок на фото
          const mainImage = cell(row, mapping, "imageUrl");
          const extraImages = splitUrls(cell(row, mapping, "additionalImages"));
          const allImages = [mainImage, ...extraImages].filter(Boolean);
          for (const url of allImages) {
            if (!isValidHttpUrl(url)) throw new Error(`Некорректная ссылка на фото: ${url.slice(0, 80)}`);
          }

          // Дубликаты
          const dupKey = `${nameRu.toLowerCase()}|${brand.name.toLowerCase()}`;
          if (seenInFile.has(dupKey)) {
            report.skipped += 1;
            report.errors.push({ row: rowNum, message: `Дубликат внутри файла — пропущен` });
            continue;
          }
          seenInFile.add(dupKey);

          const slugRaw = cell(row, mapping, "slug");
          let existing = slugRaw
            ? await db.query.products.findFirst({ where: eq(products.slug, slugify(slugRaw)) })
            : undefined;
          if (!existing) {
            existing = await db.query.products.findFirst({
              where: sql`LOWER(${products.nameRu}) = ${nameRu.toLowerCase()} AND ${products.brandId} = ${brand.id}`,
            });
          }

          const values = {
            nameRu,
            nameKg: cell(row, mapping, "nameKg") || null,
            descriptionRu: cell(row, mapping, "descriptionRu") || null,
            descriptionKg: cell(row, mapping, "descriptionKg") || null,
            categoryId: category.id,
            brandId: brand.id,
            price,
            oldPrice: oldPrice || null,
            warranty: cell(row, mapping, "warranty") || null,
            inStock: parseBool(cell(row, mapping, "inStock"), true),
            isPopular: parseBool(cell(row, mapping, "isPopular"), false),
            isNew: parseBool(cell(row, mapping, "isNew"), false),
          };

          let productId: number;
          if (existing) {
            if (input.duplicateMode === "skip") {
              report.skipped += 1;
              continue;
            }
            await db.update(products).set(values).where(eq(products.id, existing.id));
            productId = existing.id;
            report.updated += 1;
          } else {
            const slug = await uniqueSlug(slugRaw || nameRu, async (s) =>
              Boolean(await db.query.products.findFirst({ where: eq(products.slug, s) })),
            );
            const [res] = await db.insert(products).values({ ...values, slug });
            productId = Number(res.insertId);
            report.created += 1;
          }

          // Характеристики: "Ключ: Значение; Ключ2: Значение2"
          const specsRaw = cell(row, mapping, "specs");
          if (specsRaw) {
            const filterDefs = await db
              .select()
              .from(categoryFilters)
              .where(eq(categoryFilters.categoryId, category.id));
            const slugByLabel = new Map<string, string>();
            for (const f of filterDefs) {
              slugByLabel.set(f.labelRu.toLowerCase(), f.keySlug);
              if (f.labelKg) slugByLabel.set(f.labelKg.toLowerCase(), f.keySlug);
            }
            await db.delete(productSpecs).where(eq(productSpecs.productId, productId));
            const pairs = specsRaw.split(/[;\n]+/).map((s) => s.trim()).filter(Boolean);
            for (const [j, pair] of pairs.entries()) {
              const idx = pair.indexOf(":");
              if (idx <= 0) continue;
              const key = pair.slice(0, idx).trim();
              const value = pair.slice(idx + 1).trim();
              if (!key || !value) continue;
              await db.insert(productSpecs).values({
                productId,
                keySlug: slugByLabel.get(key.toLowerCase()) ?? null,
                keyRu: key,
                valueRu: value,
                sortOrder: j,
              });
            }
          }

          // Фотографии (по ссылкам)
          if (allImages.length > 0) {
            await db.delete(productImages).where(eq(productImages.productId, productId));
            for (const [j, url] of allImages.entries()) {
              await db.insert(productImages).values({
                productId,
                externalUrl: url,
                sortOrder: j,
              });
            }
          }
        } catch (err) {
          report.errors.push({
            row: rowNum,
            message: err instanceof Error ? err.message : String(err),
          });
        }
      }

      return report;
    }),
});
