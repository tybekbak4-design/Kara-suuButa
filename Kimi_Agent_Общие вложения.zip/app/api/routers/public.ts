// Публичный каталог: товары, категории, бренды, отзывы, баннеры, настройки, статистика
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  and,
  asc,
  desc,
  eq,
  gte,
  lte,
  inArray,
  isNotNull,
  gt,
  sql,
  SQL,
} from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  banners,
  brands,
  categories,
  categoryFilters,
  products,
  productImages,
  productSpecs,
  reviews,
  settings,
  statsEvents,
} from "../../db/schema";
import { resolveImageUrls, resolveOne } from "../utils";
import {
  DEFAULT_SETTINGS,
  SETTING_KEYS,
  type SettingsMap,
} from "../../contracts/types";

export async function getSettingsMap(): Promise<SettingsMap> {
  const rows = await getDb().select().from(settings);
  const map = { ...DEFAULT_SETTINGS } as SettingsMap;
  for (const row of rows) {
    if ((SETTING_KEYS as string[]).includes(row.key) && row.value != null) {
      try {
        (map as Record<string, string>)[row.key] = JSON.parse(row.value);
      } catch {
        (map as Record<string, string>)[row.key] = row.value;
      }
    }
  }
  return map;
}

const listInput = z.object({
  q: z.string().trim().max(200).optional(),
  categorySlug: z.string().max(200).optional(),
  brandSlugs: z.array(z.string().max(200)).max(50).optional(),
  minPrice: z.number().int().min(0).optional(),
  maxPrice: z.number().int().min(0).optional(),
  inStock: z.boolean().optional(),
  onSale: z.boolean().optional(),
  isNew: z.boolean().optional(),
  isPopular: z.boolean().optional(),
  sort: z.enum(["popular", "price_asc", "price_desc", "new"]).optional(),
  specFilters: z.record(z.string(), z.array(z.string().max(300)).max(100)).optional(),
  page: z.number().int().min(1).optional(),
  limit: z.number().int().min(1).max(60).optional(),
});

export const publicRouter = createRouter({
  settings: publicQuery.query(async () => {
    const map = await getSettingsMap();
    const logoUrl = await resolveOne(map.logo_key || null, map.logo_url || null);
    return { ...map, logo_resolved: logoUrl };
  }),

  categories: publicQuery.query(async () => {
    const db = getDb();
    const cats = await db
      .select()
      .from(categories)
      .orderBy(asc(categories.sortOrder), asc(categories.id));
    const counts = await db
      .select({ categoryId: products.categoryId, n: sql<number>`count(*)` })
      .from(products)
      .where(eq(products.isHidden, false))
      .groupBy(products.categoryId);
    const countMap = new Map(counts.map((c) => [c.categoryId, Number(c.n)]));
    return cats.map((c) => ({ ...c, productCount: countMap.get(c.id) ?? 0 }));
  }),

  brands: publicQuery.query(async () => {
    const rows = await getDb()
      .select()
      .from(brands)
      .orderBy(asc(brands.sortOrder), asc(brands.name));
    return Promise.all(
      rows.map(async (b) => ({
        ...b,
        logo: await resolveOne(b.logoKey, b.logoUrl),
      })),
    );
  }),

  // Фильтры характеристик категории + доступные значения
  categoryFilters: publicQuery
    .input(z.object({ categorySlug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const cat = await db.query.categories.findFirst({
        where: eq(categories.slug, input.categorySlug),
      });
      if (!cat) return [];
      const defs = await db
        .select()
        .from(categoryFilters)
        .where(eq(categoryFilters.categoryId, cat.id))
        .orderBy(asc(categoryFilters.sortOrder), asc(categoryFilters.id));
      const result = [];
      for (const def of defs) {
        const values = await db
          .selectDistinct({
            valueRu: productSpecs.valueRu,
            valueKg: productSpecs.valueKg,
          })
          .from(productSpecs)
          .innerJoin(products, eq(productSpecs.productId, products.id))
          .where(
            and(
              eq(productSpecs.keySlug, def.keySlug),
              eq(products.categoryId, cat.id),
              eq(products.isHidden, false),
            ),
          )
          .orderBy(asc(productSpecs.valueRu));
        if (values.length > 0) {
          result.push({ ...def, values });
        }
      }
      return result;
    }),

  products: publicQuery.input(listInput).query(async ({ input }) => {
    const db = getDb();
    const conditions: SQL[] = [eq(products.isHidden, false)];

    if (input.q) {
      const q = `%${input.q}%`;
      conditions.push(
        sql`(${products.nameRu} LIKE ${q} OR ${products.nameKg} LIKE ${q} OR ${products.descriptionRu} LIKE ${q})`,
      );
    }
    if (input.categorySlug) {
      const cat = await db.query.categories.findFirst({
        where: eq(categories.slug, input.categorySlug),
      });
      if (!cat) return { items: [], total: 0, page: 1, pages: 0 };
      conditions.push(eq(products.categoryId, cat.id));
    }
    if (input.brandSlugs && input.brandSlugs.length > 0) {
      const brandRows = await db
        .select({ id: brands.id })
        .from(brands)
        .where(inArray(brands.slug, input.brandSlugs));
      if (brandRows.length === 0) return { items: [], total: 0, page: 1, pages: 0 };
      conditions.push(
        inArray(
          products.brandId,
          brandRows.map((b) => b.id),
        ),
      );
    }
    if (input.minPrice != null) conditions.push(gte(products.price, input.minPrice));
    if (input.maxPrice != null) conditions.push(lte(products.price, input.maxPrice));
    if (input.inStock) conditions.push(eq(products.inStock, true));
    if (input.onSale) {
      conditions.push(isNotNull(products.oldPrice));
      conditions.push(gt(products.oldPrice, products.price));
    }
    if (input.isNew) conditions.push(eq(products.isNew, true));
    if (input.isPopular) conditions.push(eq(products.isPopular, true));

    if (input.specFilters) {
      for (const [keySlug, values] of Object.entries(input.specFilters)) {
        if (!values || values.length === 0) continue;
        conditions.push(
          sql`EXISTS (SELECT 1 FROM product_specs ps WHERE ps.product_id = ${products.id} AND ps.key_slug = ${keySlug} AND ps.value_ru IN ${values})`,
        );
      }
    }

    const where = and(...conditions);
    const [{ n: totalRaw }] = await db
      .select({ n: sql<number>`count(*)` })
      .from(products)
      .where(where);
    const total = Number(totalRaw);

    const page = input.page ?? 1;
    const limit = input.limit ?? 24;
    const pages = Math.max(1, Math.ceil(total / limit));

    const orderBy =
      input.sort === "price_asc"
        ? [asc(products.price)]
        : input.sort === "price_desc"
          ? [desc(products.price)]
          : input.sort === "new"
            ? [desc(products.createdAt)]
            : [desc(products.views), desc(products.createdAt)];

    const rows = await db
      .select()
      .from(products)
      .where(where)
      .orderBy(...orderBy)
      .limit(limit)
      .offset((page - 1) * limit);

    const items = await attachCardData(rows);
    return { items, total, page, pages };
  }),

  productBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const product = await db.query.products.findFirst({
        where: and(eq(products.slug, input.slug), eq(products.isHidden, false)),
      });
      if (!product) throw new TRPCError({ code: "NOT_FOUND" });
      await db
        .update(products)
        .set({ views: sql`${products.views} + 1` })
        .where(eq(products.id, product.id));
      const full = await getProductFull(product.id);
      return full;
    }),

  productsByIds: publicQuery
    .input(z.object({ ids: z.array(z.number().int()).max(100) }))
    .query(async ({ input }) => {
      if (input.ids.length === 0) return [];
      const db = getDb();
      const rows = await db
        .select()
        .from(products)
        .where(and(inArray(products.id, input.ids), eq(products.isHidden, false)));
      return attachCardData(rows);
    }),

  productsFullByIds: publicQuery
    .input(z.object({ ids: z.array(z.number().int()).max(10) }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(products)
        .where(and(inArray(products.id, input.ids), eq(products.isHidden, false)));
      return Promise.all(rows.map((r) => getProductFull(r.id)));
    }),

  similarProducts: publicQuery
    .input(z.object({ productId: z.number().int(), limit: z.number().int().max(12).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const product = await db.query.products.findFirst({
        where: eq(products.id, input.productId),
      });
      if (!product) return [];
      const rows = await db
        .select()
        .from(products)
        .where(
          and(
            eq(products.categoryId, product.categoryId),
            eq(products.isHidden, false),
            sql`${products.id} != ${product.id}`,
          ),
        )
        .orderBy(desc(products.views))
        .limit(input.limit ?? 8);
      return attachCardData(rows);
    }),

  banners: publicQuery.query(async () => {
    const rows = await getDb()
      .select()
      .from(banners)
      .where(eq(banners.isActive, true))
      .orderBy(asc(banners.sortOrder), asc(banners.id));
    return Promise.all(
      rows.map(async (b) => ({
        ...b,
        image: await resolveOne(b.imageKey, b.imageUrl),
      })),
    );
  }),

  productReviews: publicQuery
    .input(z.object({ productId: z.number().int() }))
    .query(async ({ input }) => {
      return getDb()
        .select()
        .from(reviews)
        .where(and(eq(reviews.productId, input.productId), eq(reviews.status, "approved")))
        .orderBy(desc(reviews.createdAt))
        .limit(100);
    }),

  recentReviews: publicQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ review: reviews, productName: products.nameRu, productSlug: products.slug })
      .from(reviews)
      .innerJoin(products, eq(reviews.productId, products.id))
      .where(and(eq(reviews.status, "approved"), eq(products.isHidden, false)))
      .orderBy(desc(reviews.createdAt))
      .limit(6);
    return rows;
  }),

  createReview: publicQuery
    .input(
      z.object({
        productId: z.number().int(),
        authorName: z.string().trim().min(2).max(100),
        rating: z.number().int().min(1).max(5),
        text: z.string().trim().min(3).max(3000),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const product = await db.query.products.findFirst({
        where: eq(products.id, input.productId),
      });
      if (!product) throw new TRPCError({ code: "NOT_FOUND" });
      await db.insert(reviews).values({ ...input, status: "pending" });
      return { ok: true };
    }),

  track: publicQuery
    .input(
      z.object({
        type: z.enum(["visit", "product_view", "whatsapp_click", "phone_click"]),
        productId: z.number().int().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb().insert(statsEvents).values({
        type: input.type,
        productId: input.productId ?? null,
      });
      return { ok: true };
    }),
});

// ─── Сборка карточек и полных товаров ───────────────────────────────────────

type ProductRow = typeof products.$inferSelect;

async function attachCardData(rows: ProductRow[]) {
  if (rows.length === 0) return [];
  const db = getDb();
  const ids = rows.map((r) => r.id);
  const [brandRows, categoryRows, imageRows] = await Promise.all([
    db.select().from(brands).where(
      inArray(brands.id, [...new Set(rows.map((r) => r.brandId))]),
    ),
    db.select().from(categories).where(
      inArray(categories.id, [...new Set(rows.map((r) => r.categoryId))]),
    ),
    db.select().from(productImages).where(inArray(productImages.productId, ids)),
  ]);
  const brandMap = new Map(brandRows.map((b) => [b.id, b]));
  const catMap = new Map(categoryRows.map((c) => [c.id, c]));
  const urls = await resolveImageUrls(imageRows);
  const imagesByProduct = new Map<number, string[]>();
  for (const img of imageRows) {
    const u = urls.find((x) => x.id === img.id);
    if (!u) continue;
    const list = imagesByProduct.get(img.productId) ?? [];
    list.push(u.url);
    imagesByProduct.set(img.productId, list);
  }
  return rows.map((p) => {
    const images = imagesByProduct.get(p.id) ?? [];
    const discount =
      p.oldPrice && p.oldPrice > p.price
        ? Math.round((1 - p.price / p.oldPrice) * 100)
        : 0;
    return {
      ...p,
      brand: brandMap.get(p.brandId) ?? null,
      category: catMap.get(p.categoryId) ?? null,
      image: images[0] ?? null,
      hoverImage: images[1] ?? null,
      discount,
    };
  });
}

export async function getProductFull(productId: number) {
  const db = getDb();
  const product = await db.query.products.findFirst({
    where: eq(products.id, productId),
  });
  if (!product) throw new TRPCError({ code: "NOT_FOUND" });
  const [brand, category, imageRows, specRows] = await Promise.all([
    db.query.brands.findFirst({ where: eq(brands.id, product.brandId) }),
    db.query.categories.findFirst({ where: eq(categories.id, product.categoryId) }),
    db
      .select()
      .from(productImages)
      .where(eq(productImages.productId, product.id))
      .orderBy(asc(productImages.sortOrder)),
    db
      .select()
      .from(productSpecs)
      .where(eq(productSpecs.productId, product.id))
      .orderBy(asc(productSpecs.sortOrder), asc(productSpecs.id)),
  ]);
  const images = await resolveImageUrls(imageRows);
  const discount =
    product.oldPrice && product.oldPrice > product.price
      ? Math.round((1 - product.price / product.oldPrice) * 100)
      : 0;
  return {
    ...product,
    brand: brand ?? null,
    category: category ?? null,
    images,
    specs: specRows,
    discount,
  };
}
