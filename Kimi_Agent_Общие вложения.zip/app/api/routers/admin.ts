// Административный роутер: авторизация, CRUD товаров/каталога, сайт, статистика
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, asc, desc, eq, like, or, sql, gte } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { adminProcedure, verifyCredentials, createSession, destroySession } from "../adminAuth";
import { getDb } from "../queries/connection";
import {
  admins,
  banners,
  brands,
  categories,
  categoryFilters,
  importMappings,
  products,
  productImages,
  productSpecs,
  reviews,
  settings,
  statsEvents,
} from "../../db/schema";
import { isValidHttpUrl, resolveImageUrls, resolveOne, slugify, uniqueSlug } from "../utils";
import { SETTING_KEYS } from "../../contracts/types";
import { getProductFull, getSettingsMap } from "./public";
import { storage } from "../lib/storage";

const localized = (max = 500) => z.string().trim().max(max);

const specInput = z.object({
  keySlug: z.string().max(120).nullable().optional(),
  keyRu: z.string().trim().min(1).max(255),
  keyKg: z.string().trim().max(255).nullable().optional(),
  valueRu: z.string().trim().min(1).max(500),
  valueKg: z.string().trim().max(500).nullable().optional(),
  sortOrder: z.number().int().optional(),
});

const imageInput = z
  .object({
    storageKey: z.string().max(512).nullable().optional(),
    externalUrl: z.string().max(2000).nullable().optional(),
    sortOrder: z.number().int().optional(),
  })
  .refine((v) => Boolean(v.storageKey) || Boolean(v.externalUrl), {
    message: "Нужен storageKey или externalUrl",
  });

const productInput = z.object({
  nameRu: localized(500).min(1),
  nameKg: localized(500).nullable().optional(),
  slug: z.string().trim().max(200).nullable().optional(),
  descriptionRu: z.string().max(20000).nullable().optional(),
  descriptionKg: z.string().max(20000).nullable().optional(),
  categoryId: z.number().int().positive(),
  brandId: z.number().int().positive(),
  price: z.number().int().min(0),
  oldPrice: z.number().int().min(0).nullable().optional(),
  warranty: z.string().trim().max(255).nullable().optional(),
  inStock: z.boolean(),
  isPopular: z.boolean().optional(),
  isNew: z.boolean().optional(),
  isHidden: z.boolean().optional(),
  specs: z.array(specInput).max(100).optional(),
  images: z.array(imageInput).max(20).optional(),
});

async function ensureUniqueProductSlug(
  desired: string | null | undefined,
  name: string,
  ignoreId?: number,
): Promise<string> {
  const db = getDb();
  return uniqueSlug(desired && desired.length > 0 ? desired : name, async (s) => {
    const row = await db.query.products.findFirst({
      where: eq(products.slug, s),
    });
    return Boolean(row) && row!.id !== ignoreId;
  });
}

export const adminRouter = createRouter({
  // ─── Авторизация ──────────────────────────────────────────────────────────
  login: publicQuery
    .input(z.object({ username: z.string().trim().min(1).max(100), password: z.string().min(1).max(200) }))
    .mutation(async ({ input }) => {
      const admin = await verifyCredentials(input.username, input.password);
      if (!admin) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Неверный логин или пароль" });
      }
      const token = await createSession(admin.id);
      return { token, username: admin.username };
    }),

  logout: adminProcedure.mutation(async ({ ctx }) => {
    await destroySession(ctx.adminToken);
    return { ok: true };
  }),

  me: adminProcedure.query(({ ctx }) => ({ username: ctx.admin.username })),

  changePassword: adminProcedure
    .input(z.object({ current: z.string().min(1), next: z.string().min(8).max(200) }))
    .mutation(async ({ ctx, input }) => {
      const admin = await verifyCredentials(ctx.admin.username, input.current);
      if (!admin) throw new TRPCError({ code: "FORBIDDEN", message: "Текущий пароль неверен" });
      const bcrypt = (await import("bcryptjs")).default;
      await getDb()
        .update(admins)
        .set({ passwordHash: await bcrypt.hash(input.next, 10) })
        .where(eq(admins.id, ctx.admin.id));
      return { ok: true };
    }),

  // ─── Загрузка изображений ────────────────────────────────────────────────
  uploadImage: adminProcedure
    .input(
      z.object({
        name: z.string().trim().min(1).max(300),
        contentBase64: z.string().max(12 * 1024 * 1024), // ~8 МБ в base64
        contentType: z.string().max(100).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const bytes = Uint8Array.from(Buffer.from(input.contentBase64, "base64"));
      if (bytes.length > 8 * 1024 * 1024) {
        throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Файл больше 8 МБ" });
      }
      const saved = await storage.uploadFile({
        fileContent: bytes,
        fileName: `uploads/${input.name}`,
        contentType: input.contentType,
      });
      return { key: saved.key, size: saved.size };
    }),

  imageUrl: adminProcedure
    .input(z.object({ key: z.string() }))
    .query(async ({ input }) => ({
      url: (await storage.getPresignedUrl({ key: input.key })).url,
    })),

  // ─── Товары ──────────────────────────────────────────────────────────────
  productsList: adminProcedure
    .input(
      z.object({
        q: z.string().trim().max(200).optional(),
        page: z.number().int().min(1).optional(),
        limit: z.number().int().min(1).max(100).optional(),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const page = input.page ?? 1;
      const limit = input.limit ?? 20;
      const where = input.q
        ? or(like(products.nameRu, `%${input.q}%`), like(products.nameKg, `%${input.q}%`))
        : undefined;
      const [{ n }] = await db
        .select({ n: sql<number>`count(*)` })
        .from(products)
        .where(where);
      const rows = await db
        .select()
        .from(products)
        .where(where)
        .orderBy(desc(products.updatedAt))
        .limit(limit)
        .offset((page - 1) * limit);
      const brandRows = await db.select().from(brands);
      const catRows = await db.select().from(categories);
      const brandMap = new Map(brandRows.map((b) => [b.id, b.name]));
      const catMap = new Map(catRows.map((c) => [c.id, c.nameRu]));
      const imgRows = await db.select().from(productImages);
      const urls = await resolveImageUrls(imgRows);
      const firstImage = new Map<number, string>();
      for (const img of imgRows) {
        if (firstImage.has(img.productId)) continue;
        const u = urls.find((x) => x.id === img.id);
        if (u) firstImage.set(img.productId, u.url);
      }
      return {
        total: Number(n),
        page,
        pages: Math.max(1, Math.ceil(Number(n) / limit)),
        items: rows.map((p) => ({
          ...p,
          brandName: brandMap.get(p.brandId) ?? "",
          categoryName: catMap.get(p.categoryId) ?? "",
          image: firstImage.get(p.id) ?? null,
        })),
      };
    }),

  productGet: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .query(async ({ input }) => {
      // Для редактирования нужны «сырые» storageKey/externalUrl, а не presigned URL
      const db = getDb();
      const full = await getProductFull(input.id);
      const rawImages = await db
        .select()
        .from(productImages)
        .where(eq(productImages.productId, input.id))
        .orderBy(asc(productImages.sortOrder));
      return {
        ...full,
        rawImages: rawImages.map((img) => ({
          id: img.id,
          storageKey: img.storageKey,
          externalUrl: img.externalUrl,
          sortOrder: img.sortOrder,
          url: full.images.find((u) => u.id === img.id)?.url ?? "",
        })),
      };
    }),

  productCreate: adminProcedure.input(productInput).mutation(async ({ input }) => {
    const db = getDb();
    const slug = await ensureUniqueProductSlug(input.slug, input.nameRu);
    const [res] = await db.insert(products).values({
      nameRu: input.nameRu,
      nameKg: input.nameKg || null,
      slug,
      descriptionRu: input.descriptionRu || null,
      descriptionKg: input.descriptionKg || null,
      categoryId: input.categoryId,
      brandId: input.brandId,
      price: input.price,
      oldPrice: input.oldPrice || null,
      warranty: input.warranty || null,
      inStock: input.inStock,
      isPopular: input.isPopular ?? false,
      isNew: input.isNew ?? false,
      isHidden: input.isHidden ?? false,
    });
    const productId = Number(res.insertId);
    await saveChildren(productId, input.specs, input.images);
    return { id: productId, slug };
  }),

  productUpdate: adminProcedure
    .input(z.object({ id: z.number().int(), data: productInput }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.query.products.findFirst({
        where: eq(products.id, input.id),
      });
      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });
      const slug = await ensureUniqueProductSlug(
        input.data.slug ?? existing.slug,
        input.data.nameRu,
        input.id,
      );
      await db
        .update(products)
        .set({
          nameRu: input.data.nameRu,
          nameKg: input.data.nameKg || null,
          slug,
          descriptionRu: input.data.descriptionRu || null,
          descriptionKg: input.data.descriptionKg || null,
          categoryId: input.data.categoryId,
          brandId: input.data.brandId,
          price: input.data.price,
          oldPrice: input.data.oldPrice || null,
          warranty: input.data.warranty || null,
          inStock: input.data.inStock,
          isPopular: input.data.isPopular ?? false,
          isNew: input.data.isNew ?? false,
          isHidden: input.data.isHidden ?? false,
        })
        .where(eq(products.id, input.id));
      await saveChildren(input.id, input.data.specs, input.data.images);
      return { id: input.id, slug };
    }),

  productDelete: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      await getDb().delete(products).where(eq(products.id, input.id));
      return { ok: true };
    }),

  productToggleHidden: adminProcedure
    .input(z.object({ id: z.number().int(), hidden: z.boolean() }))
    .mutation(async ({ input }) => {
      await getDb()
        .update(products)
        .set({ isHidden: input.hidden })
        .where(eq(products.id, input.id));
      return { ok: true };
    }),

  // ─── Категории и фильтры ─────────────────────────────────────────────────
  categoryCreate: adminProcedure
    .input(
      z.object({
        nameRu: localized().min(1),
        nameKg: localized().nullable().optional(),
        slug: z.string().max(160).nullable().optional(),
        sortOrder: z.number().int().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const slug = await uniqueSlug(input.slug || input.nameRu, async (s) =>
        Boolean(await db.query.categories.findFirst({ where: eq(categories.slug, s) })),
      );
      const [res] = await db.insert(categories).values({
        nameRu: input.nameRu,
        nameKg: input.nameKg || null,
        slug,
        sortOrder: input.sortOrder ?? 0,
      });
      return { id: Number(res.insertId), slug };
    }),

  categoryUpdate: adminProcedure
    .input(
      z.object({
        id: z.number().int(),
        nameRu: localized().min(1),
        nameKg: localized().nullable().optional(),
        sortOrder: z.number().int().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb()
        .update(categories)
        .set({ nameRu: input.nameRu, nameKg: input.nameKg || null, sortOrder: input.sortOrder ?? 0 })
        .where(eq(categories.id, input.id));
      return { ok: true };
    }),

  categoryDelete: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [{ n }] = await db
        .select({ n: sql<number>`count(*)` })
        .from(products)
        .where(eq(products.categoryId, input.id));
      if (Number(n) > 0) {
        throw new TRPCError({
          code: "CONFLICT",
          message: `В категории есть товары (${n}). Сначала переместите или удалите их.`,
        });
      }
      await db.delete(categories).where(eq(categories.id, input.id));
      return { ok: true };
    }),

  categoryFiltersSet: adminProcedure
    .input(
      z.object({
        categoryId: z.number().int(),
        filters: z.array(
          z.object({
            keySlug: z.string().trim().min(1).max(120),
            labelRu: z.string().trim().min(1).max(255),
            labelKg: z.string().trim().max(255).nullable().optional(),
            sortOrder: z.number().int().optional(),
          }),
        ),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(categoryFilters).where(eq(categoryFilters.categoryId, input.categoryId));
      for (const [i, f] of input.filters.entries()) {
        await db.insert(categoryFilters).values({
          categoryId: input.categoryId,
          keySlug: slugify(f.keySlug),
          labelRu: f.labelRu,
          labelKg: f.labelKg || null,
          sortOrder: f.sortOrder ?? i,
        });
      }
      return { ok: true };
    }),

  categoryFiltersList: adminProcedure
    .input(z.object({ categoryId: z.number().int() }))
    .query(async ({ input }) =>
      getDb()
        .select()
        .from(categoryFilters)
        .where(eq(categoryFilters.categoryId, input.categoryId))
        .orderBy(asc(categoryFilters.sortOrder)),
    ),

  // ─── Бренды ──────────────────────────────────────────────────────────────
  brandCreate: adminProcedure
    .input(
      z.object({
        name: localized().min(1),
        logoUrl: z.string().max(2000).nullable().optional(),
        logoKey: z.string().max(512).nullable().optional(),
        sortOrder: z.number().int().optional(),
        isPopular: z.boolean().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const slug = await uniqueSlug(input.name, async (s) =>
        Boolean(await db.query.brands.findFirst({ where: eq(brands.slug, s) })),
      );
      const [res] = await db.insert(brands).values({
        name: input.name,
        slug,
        logoUrl: input.logoUrl || null,
        logoKey: input.logoKey || null,
        sortOrder: input.sortOrder ?? 0,
        isPopular: input.isPopular ?? false,
      });
      return { id: Number(res.insertId), slug };
    }),

  brandUpdate: adminProcedure
    .input(
      z.object({
        id: z.number().int(),
        name: localized().min(1),
        logoUrl: z.string().max(2000).nullable().optional(),
        logoKey: z.string().max(512).nullable().optional(),
        sortOrder: z.number().int().optional(),
        isPopular: z.boolean().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb()
        .update(brands)
        .set({
          name: input.name,
          logoUrl: input.logoUrl || null,
          logoKey: input.logoKey || null,
          sortOrder: input.sortOrder ?? 0,
          isPopular: input.isPopular ?? false,
        })
        .where(eq(brands.id, input.id));
      return { ok: true };
    }),

  brandDelete: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [{ n }] = await db
        .select({ n: sql<number>`count(*)` })
        .from(products)
        .where(eq(products.brandId, input.id));
      if (Number(n) > 0) {
        throw new TRPCError({
          code: "CONFLICT",
          message: `У бренда есть товары (${n}). Сначала удалите или переназначьте их.`,
        });
      }
      await db.delete(brands).where(eq(brands.id, input.id));
      return { ok: true };
    }),

  // ─── Баннеры ─────────────────────────────────────────────────────────────
  bannersList: adminProcedure.query(async () => {
    const rows = await getDb()
      .select()
      .from(banners)
      .orderBy(asc(banners.sortOrder), asc(banners.id));
    return Promise.all(
      rows.map(async (b) => ({ ...b, image: await resolveOne(b.imageKey, b.imageUrl) })),
    );
  }),

  bannerSave: adminProcedure
    .input(
      z.object({
        id: z.number().int().nullable().optional(),
        titleRu: localized().min(1),
        titleKg: localized().nullable().optional(),
        subtitleRu: localized().nullable().optional(),
        subtitleKg: localized().nullable().optional(),
        buttonTextRu: localized().nullable().optional(),
        buttonTextKg: localized().nullable().optional(),
        imageKey: z.string().max(512).nullable().optional(),
        imageUrl: z.string().max(2000).nullable().optional(),
        linkUrl: z.string().max(1000).nullable().optional(),
        bgColor: z.string().max(32).nullable().optional(),
        sortOrder: z.number().int().optional(),
        isActive: z.boolean().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const data = {
        titleRu: input.titleRu,
        titleKg: input.titleKg || null,
        subtitleRu: input.subtitleRu || null,
        subtitleKg: input.subtitleKg || null,
        buttonTextRu: input.buttonTextRu || null,
        buttonTextKg: input.buttonTextKg || null,
        imageKey: input.imageKey || null,
        imageUrl: input.imageUrl || null,
        linkUrl: input.linkUrl || null,
        bgColor: input.bgColor || null,
        sortOrder: input.sortOrder ?? 0,
        isActive: input.isActive ?? true,
      };
      if (input.id) {
        await db.update(banners).set(data).where(eq(banners.id, input.id));
        return { id: input.id };
      }
      const [res] = await db.insert(banners).values(data);
      return { id: Number(res.insertId) };
    }),

  bannerDelete: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      await getDb().delete(banners).where(eq(banners.id, input.id));
      return { ok: true };
    }),

  // ─── Отзывы ──────────────────────────────────────────────────────────────
  reviewsList: adminProcedure
    .input(z.object({ status: z.enum(["pending", "approved", "rejected"]).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const where = input.status ? eq(reviews.status, input.status) : undefined;
      return db
        .select({ review: reviews, productName: products.nameRu, productSlug: products.slug })
        .from(reviews)
        .innerJoin(products, eq(reviews.productId, products.id))
        .where(where)
        .orderBy(desc(reviews.createdAt))
        .limit(500);
    }),

  reviewSetStatus: adminProcedure
    .input(z.object({ id: z.number().int(), status: z.enum(["approved", "rejected"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(reviews).set({ status: input.status }).where(eq(reviews.id, input.id));
      return { ok: true };
    }),

  reviewDelete: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      await getDb().delete(reviews).where(eq(reviews.id, input.id));
      return { ok: true };
    }),

  // ─── Настройки сайта ─────────────────────────────────────────────────────
  settingsGet: adminProcedure.query(async () => getSettingsMap()),

  settingsUpdate: adminProcedure
    .input(z.record(z.string(), z.string()))
    .mutation(async ({ input }) => {
      const db = getDb();
      for (const key of SETTING_KEYS) {
        if (input[key] === undefined) continue;
        const value = JSON.stringify(input[key]);
        await db
          .insert(settings)
          .values({ key, value })
          .onDuplicateKeyUpdate({ set: { value } });
      }
      return { ok: true };
    }),

  // ─── Статистика ──────────────────────────────────────────────────────────
  statsSummary: adminProcedure.query(async () => {
    const db = getDb();
    const totals = await db
      .select({ type: statsEvents.type, n: sql<number>`count(*)` })
      .from(statsEvents)
      .groupBy(statsEvents.type);
    const totalMap: Record<string, number> = {
      visit: 0,
      product_view: 0,
      whatsapp_click: 0,
      phone_click: 0,
    };
    for (const t of totals) totalMap[t.type] = Number(t.n);

    const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
    const visitRows = await db
      .select({ createdAt: statsEvents.createdAt })
      .from(statsEvents)
      .where(and(eq(statsEvents.type, "visit"), gte(statsEvents.createdAt, since)))
      .orderBy(asc(statsEvents.createdAt));
    const byDay = new Map<string, number>();
    for (const r of visitRows) {
      const day = r.createdAt.toISOString().slice(0, 10);
      byDay.set(day, (byDay.get(day) ?? 0) + 1);
    }
    const daily = [...byDay.entries()].map(([day, n]) => ({ day, n }));

    const top = await db
      .select({
        id: products.id,
        name: products.nameRu,
        slug: products.slug,
        views: products.views,
      })
      .from(products)
      .orderBy(desc(products.views))
      .limit(10);

    const waTop = await db
      .select({ productId: statsEvents.productId, n: sql<number>`count(*)` })
      .from(statsEvents)
      .where(eq(statsEvents.type, "whatsapp_click"))
      .groupBy(statsEvents.productId)
      .orderBy(desc(sql`count(*)`))
      .limit(10);

    const [productsCount] = await db.select({ n: sql<number>`count(*)` }).from(products);
    const [reviewsPending] = await db
      .select({ n: sql<number>`count(*)` })
      .from(reviews)
      .where(eq(reviews.status, "pending"));

    return {
      totals: totalMap,
      dailyVisits: daily.map((d) => ({ day: d.day, count: Number(d.n) })),
      topProducts: top,
      whatsappTop: waTop.map((w) => ({ productId: w.productId, count: Number(w.n) })),
      productsCount: Number(productsCount.n),
      pendingReviews: Number(reviewsPending.n),
    };
  }),

  // ─── Маппинги импорта ────────────────────────────────────────────────────
  importMappingsList: adminProcedure.query(async () =>
    getDb().select().from(importMappings).orderBy(desc(importMappings.createdAt)),
  ),

  importMappingSave: adminProcedure
    .input(z.object({ name: z.string().trim().min(1).max(255), mapping: z.record(z.string(), z.string()) }))
    .mutation(async ({ input }) => {
      const [res] = await getDb()
        .insert(importMappings)
        .values({ name: input.name, mapping: JSON.stringify(input.mapping) });
      return { id: Number(res.insertId) };
    }),

  importMappingDelete: adminProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      await getDb().delete(importMappings).where(eq(importMappings.id, input.id));
      return { ok: true };
    }),
});

async function saveChildren(
  productId: number,
  specs?: z.infer<typeof specInput>[],
  images?: z.infer<typeof imageInput>[],
) {
  const db = getDb();
  if (specs !== undefined) {
    await db.delete(productSpecs).where(eq(productSpecs.productId, productId));
    for (const [i, s] of specs.entries()) {
      await db.insert(productSpecs).values({
        productId,
        keySlug: s.keySlug ? slugify(s.keySlug) : null,
        keyRu: s.keyRu,
        keyKg: s.keyKg || null,
        valueRu: s.valueRu,
        valueKg: s.valueKg || null,
        sortOrder: s.sortOrder ?? i,
      });
    }
  }
  if (images !== undefined) {
    for (const img of images) {
      if (img.externalUrl && !isValidHttpUrl(img.externalUrl)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Некорректная ссылка на фото: ${img.externalUrl}` });
      }
    }
    await db.delete(productImages).where(eq(productImages.productId, productId));
    for (const [i, img] of images.entries()) {
      await db.insert(productImages).values({
        productId,
        storageKey: img.storageKey || null,
        externalUrl: img.externalUrl || null,
        sortOrder: img.sortOrder ?? i,
      });
    }
  }
}
