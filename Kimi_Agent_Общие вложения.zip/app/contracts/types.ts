// Общие константы и типы для frontend и backend

export const DEFAULT_SETTINGS = {
  site_name_ru: "Магазин бытовой техники",
  site_name_kg: "Турак үй техникасы дүкөнү",
  logo_key: "",
  logo_url: "",
  primary_color: "#1a1a1a",
  accent_color: "#ff5100",
  phone: "+996 770 14-91-91",
  whatsapp: "+996 771 11-51-81",
  address_ru: "г. Ош (адрес настраивается в админ-панели)",
  address_kg: "Ош шаары (дарек админ-панелден туураланат)",
  map_embed_url: "",
  delivery_ru:
    "По городу Ош доставка бесплатная. В другие города и регионы Кыргызстана доставка платная — стоимость уточняется индивидуально.",
  delivery_kg:
    "Ош шаары боюнча жеткирүү бекер. Кыргызстандын башка шаарларына жана аймактарына жеткирүү акы төлөнүүчү — баасы жекече такталат.",
  currency: "сом",
  seo_title_ru: "Бытовая техника в Оше — каталог магазина",
  seo_title_kg: "Ошто турак үй техникасы — дүкөн каталогу",
  seo_description_ru:
    "Холодильники, стиральные машины, телевизоры и другая бытовая техника с доставкой по Ошу и Кыргызстану.",
  seo_description_kg:
    "Муздаткычтар, кир жуучу машиналар, телевизорлор жана башка турак үй техникасы Ош жана Кыргызстан боюнча жеткирүү менен.",
} as const;

export type SettingKey = keyof typeof DEFAULT_SETTINGS;

export type SettingsMap = Record<SettingKey, string>;

export const SETTING_KEYS = Object.keys(DEFAULT_SETTINGS) as SettingKey[];

/** Поля товара, доступные для сопоставления при импорте Excel */
export const IMPORT_FIELDS = [
  "nameRu",
  "nameKg",
  "slug",
  "category",
  "brand",
  "price",
  "oldPrice",
  "warranty",
  "inStock",
  "descriptionRu",
  "descriptionKg",
  "specs",
  "imageUrl",
  "additionalImages",
  "isPopular",
  "isNew",
] as const;

export type ImportField = (typeof IMPORT_FIELDS)[number];

export const REQUIRED_IMPORT_FIELDS: ImportField[] = ["nameRu", "category", "price"];

export type ProductSort = "popular" | "price_asc" | "price_desc" | "new";

export type ProductListQuery = {
  q?: string;
  categorySlug?: string;
  brandSlugs?: string[];
  minPrice?: number;
  maxPrice?: number;
  inStock?: boolean;
  onSale?: boolean;
  isNew?: boolean;
  isPopular?: boolean;
  sort?: ProductSort;
  specFilters?: Record<string, string[]>;
  page?: number;
  limit?: number;
};

export type StatsEventType =
  | "visit"
  | "product_view"
  | "whatsapp_click"
  | "phone_click";
